import 'package:flutter/material.dart';

/// VERIQ tokens (packages/design-tokens/tokens.json). Gold marks evidence-backed verification only.
class VeriqColors {
  static const forest950 = Color(0xFF06140F);
  static const forest900 = Color(0xFF0A1F17);
  static const forest800 = Color(0xFF0F2E22);
  static const forest700 = Color(0xFF174333);
  static const sage400 = Color(0xFF93AD9F);
  static const gold500 = Color(0xFFC9A24A);
  static const gold600 = Color(0xFFA8842F);
  static const ivory50 = Color(0xFFF5F1E6);
  static const ok = Color(0xFF5FBF8F);
  static const stop = Color(0xFFE2735E);
}

ThemeData veriqTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final scheme = ColorScheme(
    brightness: b,
    primary: dark ? VeriqColors.gold500 : VeriqColors.gold600,
    onPrimary: dark ? VeriqColors.forest950 : Colors.white,
    secondary: VeriqColors.forest700,
    onSecondary: VeriqColors.ivory50,
    error: VeriqColors.stop,
    onError: VeriqColors.forest950,
    surface: dark ? VeriqColors.forest950 : VeriqColors.ivory50,
    onSurface: dark ? VeriqColors.ivory50 : VeriqColors.forest950,
    surfaceContainerHighest: dark ? VeriqColors.forest900 : Colors.white,
    outline: dark ? VeriqColors.forest700 : const Color(0xFFD8D0BC),
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    fontFamilyFallback: const ['Noto Sans Ethiopic'],
    textTheme: const TextTheme(
      headlineMedium: TextStyle(fontWeight: FontWeight.w600, letterSpacing: -0.2),
      bodyMedium: TextStyle(fontFeatures: [FontFeature.tabularFigures()]),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
    ),
    cardTheme: CardThemeData(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: scheme.outline)), elevation: 0),
  );
}
