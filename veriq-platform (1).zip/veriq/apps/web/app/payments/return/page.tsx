"use client";
import { useEffect, useState } from "react";
import { API, ENTITY } from "@/lib/api";

// Chapa sends the payer back here. The URL is NOT proof of payment: we ask the VERIQ API, which verifies with Chapa.
export default function PaymentReturn() {
  const [state, setState] = useState<"checking" | "paid" | "pending" | "failed" | "error">("checking");
  useEffect(() => {
    const ref = new URLSearchParams(window.location.search).get("tx_ref") ?? "";
    if (!/^VQ-[A-F0-9]{24}$/.test(ref)) { setState("error"); return; }
    let tries = 0;
    const check = async () => {
      try {
        const r = await fetch(`${API}/v1/payments/chapa/callback/${ENTITY}?trx_ref=${ref}`, { cache: "no-store" });
        const d = await r.json();
        if (d.state === "CONFIRMED" || d.disposition === "ALREADY_CONFIRMED") return setState("paid");
        if (d.state === "FAILED") return setState("failed");
        if (++tries < 10) setTimeout(check, 3000); else setState("pending");
      } catch { setState("error"); }
    };
    void check();
  }, []);
  const text = { checking: "Confirming your payment with Chapa…", paid: "Payment confirmed. Thank you.",
    pending: "Chapa has not confirmed yet. We will update your invoice automatically; you do not need to pay again.",
    failed: "The payment did not go through. You were not charged; you can try again.", error: "We could not read this payment reference." }[state];
  return <><h1>Payment</h1><div className={`panel ${state === "paid" ? "ok" : ""}`} role="status"><p>{text}</p></div></>;
}
