import type { NextConfig } from "next";
const config: NextConfig = {
  poweredByHeader: false,
  reactStrictMode: true,
  // Same-origin API: the browser calls /v1/* on the portal, which proxies over Railway's private network.
  // One site => SameSite=Strict session cookies work and no CORS is needed.
  async rewrites() {
    const core = process.env.VERIQ_CORE_INTERNAL_URL;
    return core ? [
      { source: "/v1/:path*", destination: `${core}/v1/:path*` },
      { source: "/health", destination: `${core}/health` },
      { source: "/ready", destination: `${core}/ready` },
    ] : [];
  },
  async headers() {
    return [{ source: "/(.*)", headers: [
      { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "Referrer-Policy", value: "no-referrer" },
      { key: "X-Frame-Options", value: "DENY" },
      { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), publickey-credentials-get=(self), publickey-credentials-create=(self)" },
    ] }];
  },
};
export default config;
