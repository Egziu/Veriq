-- VERIQ 0006 — Chapa payment gateway, sponsor invoices, dual-control refunds, and the admin commands the audit
-- found missing (authorizations, chart of accounts, sponsors, staff, provider state) so nothing requires superuser SQL.
SET ROLE veriq_owner;
SET search_path = veriq, public;

-- Chapa starts SUSPENDED and NOT accepted for gaming. Only a CFO command can change either flag.
RESET ROLE;
INSERT INTO veriq.payment_providers(code, state, gaming_model_accepted) VALUES ('chapa', 'SUSPENDED', false) ON CONFLICT DO NOTHING;
SET ROLE veriq_owner;

-- ---------- Sponsor invoices (B2B: the first lawful use of Chapa — sponsors paying VERIQ) ----------
CREATE TABLE sponsor_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL, sponsor_id uuid NOT NULL,
  number text NOT NULL, description text NOT NULL,
  amount_minor bigint NOT NULL CHECK (amount_minor > 0), currency char(3) NOT NULL DEFAULT 'ETB',
  state text NOT NULL DEFAULT 'ISSUED' CHECK (state IN ('ISSUED','PAID','VOID')),
  issued_by uuid NOT NULL, issued_at timestamptz NOT NULL DEFAULT clock_timestamp(), paid_at timestamptz,
  FOREIGN KEY (sponsor_id, legal_entity_id) REFERENCES sponsors(id, legal_entity_id),
  UNIQUE (legal_entity_id, number), UNIQUE (id, legal_entity_id));

-- ---------- Payment intents: purpose-bound, created only through a gated command ----------
ALTER TABLE payment_intents ALTER COLUMN customer_id DROP NOT NULL;
ALTER TABLE payment_intents
  ADD COLUMN purpose text NOT NULL DEFAULT 'ENTRY_FEE' CHECK (purpose IN ('ENTRY_FEE','SPONSOR_INVOICE')),
  ADD COLUMN competition_id uuid, ADD COLUMN sponsor_invoice_id uuid,
  ADD COLUMN provider_reference text, ADD COLUMN checkout_url text,
  ADD COLUMN mode text CHECK (mode IN ('test','live')), ADD COLUMN fee_minor bigint, ADD COLUMN verified_at timestamptz,
  ADD COLUMN refunded_minor bigint NOT NULL DEFAULT 0,
  ADD CONSTRAINT intent_purpose_shape CHECK ((purpose = 'ENTRY_FEE' AND customer_id IS NOT NULL AND competition_id IS NOT NULL)
                                          OR (purpose = 'SPONSOR_INVOICE' AND sponsor_invoice_id IS NOT NULL)),
  ADD CONSTRAINT intent_invoice_fk FOREIGN KEY (sponsor_invoice_id, legal_entity_id) REFERENCES sponsor_invoices(id, legal_entity_id),
  ADD CONSTRAINT intent_competition_fk FOREIGN KEY (competition_id, legal_entity_id) REFERENCES competitions(id, legal_entity_id),
  ADD CONSTRAINT intent_refund_bound CHECK (refunded_minor >= 0 AND refunded_minor <= amount_minor);
CREATE UNIQUE INDEX one_open_intent_per_invoice ON payment_intents(sponsor_invoice_id)
  WHERE sponsor_invoice_id IS NOT NULL AND state IN ('INITIATED','PENDING','CONFIRMED','RECONCILED','APPLIED');
REVOKE INSERT ON payment_intents FROM veriq_app;    -- intents now exist only via create_payment_intent()

CREATE TABLE payment_refunds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL, payment_intent_id uuid NOT NULL,
  amount_minor bigint NOT NULL CHECK (amount_minor > 0), reason text NOT NULL,
  state text NOT NULL DEFAULT 'REQUESTED' CHECK (state IN ('REQUESTED','APPROVED','SUBMITTED','REFUNDED','REVERSED','REJECTED')),
  requested_by uuid NOT NULL, approved_by uuid, provider_ref_id text UNIQUE, merchant_reference text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(), settled_at timestamptz,
  CHECK (approved_by IS NULL OR approved_by <> requested_by),
  FOREIGN KEY (payment_intent_id, legal_entity_id) REFERENCES payment_intents(id, legal_entity_id));

-- ---------- Admin commands found missing by the audit ----------
CREATE FUNCTION create_authorization(p_country char(2), p_product text, p_channel text, p_license_scope text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid;
BEGIN
  IF NOT staff_has('COMPLIANCE') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  INSERT INTO country_product_authorizations(legal_entity_id, country_code, product_type, channel, license_scope, created_by)
    VALUES (current_entity(), p_country, p_product, p_channel, p_license_scope, current_actor()) RETURNING id INTO v;  -- always BLOCKED
  PERFORM audit(current_entity(), 'authorization.created', v, jsonb_build_object('country', p_country, 'product', p_product, 'channel', p_channel));
  RETURN v;
END $$;

CREATE FUNCTION bootstrap_chart_of_accounts(p_currency char(3)) RETURNS int
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE n int;
BEGIN
  IF NOT staff_has('CFO') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  INSERT INTO accounts(legal_entity_id, code, currency, kind, name)
  SELECT current_entity(), c, p_currency, k, nm FROM (VALUES
    ('1000-BANK','ASSET','Operating bank'), ('1100-PROVIDER-CLEARING','ASSET','Generic provider clearing'),
    ('1110-CHAPA-CLEARING','ASSET','Chapa balance awaiting settlement'), ('1200-SPONSOR-RECEIVABLE','ASSET','Sponsor receivables'),
    ('1300-PRIZE-INVENTORY','ASSET','Prize inventory'), ('2100-CUSTOMER-LIABILITY','LIABILITY','Customer funds held'),
    ('2200-PRIZE-OBLIGATION','LIABILITY','Prize obligations'), ('2300-SPONSOR-DEFERRED-REVENUE','LIABILITY','Sponsor fees not yet recognised'),
    ('4000-SPONSOR-REVENUE','REVENUE','Sponsor revenue (recognised per approved policy)'), ('5200-PAYMENT-FEES','EXPENSE','Payment gateway fees')
  ) AS x(c, k, nm) ON CONFLICT DO NOTHING;
  GET DIAGNOSTICS n = ROW_COUNT;
  PERFORM audit(current_entity(), 'accounts.bootstrapped', NULL, jsonb_build_object('currency', p_currency, 'created', n));
  RETURN n;
END $$;

CREATE FUNCTION create_sponsor(p_name text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid;
BEGIN
  IF NOT staff_has('COMP_OPS') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  INSERT INTO sponsors(legal_entity_id, name) VALUES (current_entity(), p_name) RETURNING id INTO v;
  PERFORM audit(current_entity(), 'sponsor.created', v, jsonb_build_object('name', p_name));
  RETURN v;
END $$;

-- Staff: INFRA_ADMIN proposes (inactive); a CEO who is a different person activates. No one can mint an approver alone.
CREATE FUNCTION propose_staff(p_name text, p_roles text[], p_sponsor uuid DEFAULT NULL) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid;
BEGIN
  IF NOT staff_has('INFRA_ADMIN') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  IF p_sponsor IS NOT NULL AND p_roles <> ARRAY['SPONSOR'] THEN RAISE EXCEPTION 'SPONSOR_USERS_ONLY_SPONSOR_ROLE' USING ERRCODE='VQ906'; END IF;
  INSERT INTO staff_users(legal_entity_id, display_name, roles, active) VALUES (current_entity(), p_name, p_roles, false) RETURNING id INTO v;
  IF p_sponsor IS NOT NULL THEN
    INSERT INTO sponsor_members(sponsor_id, staff_id, legal_entity_id) VALUES (p_sponsor, v, current_entity());
  END IF;
  PERFORM audit(current_entity(), 'staff.proposed', v, jsonb_build_object('roles', p_roles));
  RETURN v;
END $$;

CREATE FUNCTION activate_staff(p_staff uuid) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE proposer uuid;
BEGIN
  IF NOT staff_has('CEO') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  SELECT actor_id INTO proposer FROM audit_log WHERE legal_entity_id=current_entity() AND action='staff.proposed' AND object_id=p_staff ORDER BY id DESC LIMIT 1;
  IF proposer IS NULL THEN RETURN 'NOT_PROPOSED'; END IF;
  IF proposer = current_actor() OR p_staff = current_actor() THEN RETURN 'DUAL_CONTROL_REQUIRED'; END IF;
  UPDATE staff_users SET active = true WHERE id=p_staff AND legal_entity_id=current_entity() AND NOT active;
  IF NOT FOUND THEN RETURN 'NOT_FOUND'; END IF;
  PERFORM audit(current_entity(), 'staff.activated', p_staff, '{}');
  RETURN 'OK';
END $$;

CREATE FUNCTION deactivate_staff(p_staff uuid) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
BEGIN
  IF NOT (staff_has('CEO') OR staff_has('INFRA_ADMIN')) THEN RETURN 'ROLE_NOT_HELD'; END IF;
  UPDATE staff_users SET active = false WHERE id=p_staff AND legal_entity_id=current_entity();
  UPDATE sessions SET revoked_at = clock_timestamp() WHERE principal_id=p_staff AND legal_entity_id=current_entity() AND revoked_at IS NULL;
  PERFORM audit(current_entity(), 'staff.deactivated', p_staff, '{}');
  RETURN 'OK';
END $$;

-- Provider state is a CFO decision; gaming acceptance additionally needs recorded evidence of the provider's written acceptance.
CREATE FUNCTION set_provider_state(p_code text, p_state text, p_gaming_accepted boolean, p_evidence_sha256 char(64)) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
BEGIN
  IF NOT staff_has('CFO') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  IF p_gaming_accepted AND (p_evidence_sha256 IS NULL OR p_evidence_sha256 !~ '^[0-9a-f]{64}$') THEN RETURN 'EVIDENCE_REQUIRED'; END IF;
  UPDATE payment_providers SET state=p_state, gaming_model_accepted=p_gaming_accepted WHERE code=p_code;
  IF NOT FOUND THEN RETURN 'NOT_FOUND'; END IF;
  PERFORM audit(current_entity(), 'provider.state', NULL, jsonb_build_object('provider', p_code, 'state', p_state,
                'gaming_accepted', p_gaming_accepted, 'evidence', p_evidence_sha256));
  RETURN 'OK';
END $$;

-- ---------- Invoices ----------
CREATE FUNCTION issue_sponsor_invoice(p_sponsor uuid, p_number text, p_description text, p_amount bigint, p_currency char(3)) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid;
BEGIN
  IF NOT staff_has('FINANCE') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  INSERT INTO sponsor_invoices(legal_entity_id, sponsor_id, number, description, amount_minor, currency, issued_by)
    VALUES (current_entity(), p_sponsor, p_number, p_description, p_amount, p_currency, current_actor()) RETURNING id INTO v;
  -- Revenue recognition timing needs the signed accounting memo: book as deferred until policy says otherwise.
  PERFORM post_journal('sponsor.invoice', v::text, 'Sponsor invoice ' || p_number,
    jsonb_build_array(jsonb_build_object('account','1200-SPONSOR-RECEIVABLE','currency',p_currency,'amount_minor',p_amount),
                      jsonb_build_object('account','2300-SPONSOR-DEFERRED-REVENUE','currency',p_currency,'amount_minor',-p_amount)));
  RETURN v;
END $$;

-- ---------- Intents ----------
CREATE FUNCTION create_payment_intent(p_purpose text, p_provider text, p_merchant_ref text, p_customer uuid, p_competition uuid,
                                      p_invoice uuid, p_channel text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE pr record; c record; inv record; v uuid; v_gate text;
BEGIN
  SELECT * INTO pr FROM payment_providers WHERE code=p_provider;
  IF NOT FOUND OR pr.state <> 'ACTIVE' THEN RETURN jsonb_build_object('ok', false, 'code', 'PROVIDER_SUSPENDED'); END IF;
  IF p_purpose = 'ENTRY_FEE' THEN
    SELECT * INTO c FROM competitions WHERE id=p_competition AND legal_entity_id=current_entity();
    IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'NOT_FOUND'); END IF;
    IF c.product_type <> 'PAID_COMPETITION' THEN RETURN jsonb_build_object('ok', false, 'code', 'FREE_ENTRY_MUST_NOT_CHARGE'); END IF;
    v_gate := authz_check(current_entity(), c.country_code, c.product_type, p_channel);
    IF v_gate <> 'OK' THEN RETURN jsonb_build_object('ok', false, 'code', v_gate); END IF;
    IF NOT pr.gaming_model_accepted THEN RETURN jsonb_build_object('ok', false, 'code', 'PROVIDER_SUSPENDED'); END IF;
    IF c.state <> 'OPEN' OR clock_timestamp() >= c.closes_at THEN RETURN jsonb_build_object('ok', false, 'code', 'COMPETITION_NOT_OPEN'); END IF;
    IF NOT EXISTS (SELECT 1 FROM customers WHERE id=p_customer AND legal_entity_id=current_entity()) THEN
      RETURN jsonb_build_object('ok', false, 'code', 'CUSTOMER_NOT_FOUND'); END IF;
    INSERT INTO payment_intents(legal_entity_id, customer_id, provider, merchant_ref, amount_minor, currency, purpose, competition_id)
      VALUES (current_entity(), p_customer, p_provider, p_merchant_ref, c.entry_fee_minor, c.currency, 'ENTRY_FEE', p_competition) RETURNING id INTO v;
    RETURN jsonb_build_object('ok', true, 'intent_id', v, 'amount_minor', c.entry_fee_minor, 'currency', c.currency, 'title', c.title);
  ELSIF p_purpose = 'SPONSOR_INVOICE' THEN
    IF NOT staff_has('SPONSOR') THEN RETURN jsonb_build_object('ok', false, 'code', 'ROLE_NOT_HELD'); END IF;
    SELECT i.* INTO inv FROM sponsor_invoices i JOIN sponsor_members m ON m.sponsor_id=i.sponsor_id AND m.staff_id=current_actor()
     WHERE i.id=p_invoice AND i.legal_entity_id=current_entity() FOR UPDATE OF i;
    IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'NOT_FOUND'); END IF;
    IF inv.state <> 'ISSUED' THEN RETURN jsonb_build_object('ok', false, 'code', 'INVOICE_NOT_PAYABLE'); END IF;
    -- A new checkout supersedes an abandoned one (Chapa checkout links expire); a confirmed one blocks.
    IF EXISTS (SELECT 1 FROM payment_intents WHERE sponsor_invoice_id=p_invoice AND state IN ('CONFIRMED','RECONCILED','APPLIED')) THEN
      RETURN jsonb_build_object('ok', false, 'code', 'INVOICE_NOT_PAYABLE'); END IF;
    UPDATE payment_intents SET state='EXPIRED' WHERE sponsor_invoice_id=p_invoice AND state IN ('INITIATED','PENDING');
    INSERT INTO payment_intents(legal_entity_id, provider, merchant_ref, amount_minor, currency, purpose, sponsor_invoice_id)
      VALUES (current_entity(), p_provider, p_merchant_ref, inv.amount_minor, inv.currency, 'SPONSOR_INVOICE', p_invoice) RETURNING id INTO v;
    RETURN jsonb_build_object('ok', true, 'intent_id', v, 'amount_minor', inv.amount_minor, 'currency', inv.currency, 'title', 'Invoice ' || inv.number);
  END IF;
  RETURN jsonb_build_object('ok', false, 'code', 'BAD_PURPOSE');
END $$;

CREATE FUNCTION set_checkout(p_intent uuid, p_checkout_url text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
BEGIN
  IF p_checkout_url !~ '^https://' THEN RETURN 'BAD_URL'; END IF;
  UPDATE payment_intents SET checkout_url=p_checkout_url, state='PENDING' WHERE id=p_intent AND legal_entity_id=current_entity() AND state='INITIATED';
  RETURN CASE WHEN FOUND THEN 'OK' ELSE 'NOT_INITIATED' END;
END $$;

-- The ONLY way money is recognised: called with data from Chapa's verify API (never from webhook bodies or clients).
-- Idempotent by (provider, event_key). Posts fees separately: Chapa charges are non-refundable.
CREATE FUNCTION apply_verified_payment(p_provider text, p_event_key text, p_merchant_ref text, p_status text, p_amount bigint,
     p_currency char(3), p_fee bigint, p_provider_reference text, p_mode text, p_expected_mode text, p_raw_digest char(64)) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE pi record; v_disp text; v_to text; v_credit text; v_lines jsonb;
BEGIN
  IF EXISTS (SELECT 1 FROM payment_events WHERE provider=p_provider AND provider_event_id=p_event_key) THEN
    RETURN jsonb_build_object('applied', false, 'disposition', 'DUPLICATE'); END IF;
  SELECT * INTO pi FROM payment_intents WHERE merchant_ref=p_merchant_ref AND provider=p_provider AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('applied', false, 'disposition', 'UNKNOWN_MERCHANT_REF'); END IF;

  IF p_mode IS DISTINCT FROM p_expected_mode THEN v_disp := 'MODE_MISMATCH'; v_to := 'EXCEPTION';
  ELSIF p_status = 'success' AND (p_amount <> pi.amount_minor OR p_currency <> pi.currency) THEN v_disp := 'AMOUNT_MISMATCH_EXCEPTION'; v_to := 'EXCEPTION';
  ELSIF p_status = 'success' AND (coalesce(p_fee,0) < 0 OR coalesce(p_fee,0) > p_amount) THEN v_disp := 'FEE_INVALID_EXCEPTION'; v_to := 'EXCEPTION';
  ELSIF p_status = 'success' AND pi.state IN ('INITIATED','PENDING') THEN v_disp := 'APPLIED'; v_to := 'CONFIRMED';
  ELSIF p_status = 'success' AND pi.state = 'EXPIRED' THEN v_disp := 'LATE_PAYMENT_REFUND_REQUIRED'; v_to := 'EXCEPTION';
  ELSIF p_status = 'success' THEN v_disp := 'ALREADY_CONFIRMED'; v_to := NULL;
  ELSIF p_status IN ('failed','cancelled') AND pi.state IN ('INITIATED','PENDING') THEN v_disp := 'FAILED'; v_to := 'FAILED';
  ELSIF p_status = 'pending' THEN v_disp := 'STILL_PENDING'; v_to := NULL;
  ELSE v_disp := 'IGNORED_' || upper(p_status); v_to := NULL; END IF;

  INSERT INTO payment_events(legal_entity_id, provider, provider_event_id, payment_intent_id, kind, amount_minor, currency, raw_digest, applied, disposition)
    VALUES (current_entity(), p_provider, p_event_key, pi.id,
            CASE p_status WHEN 'success' THEN 'CONFIRMED' WHEN 'pending' THEN 'PENDING' ELSE 'FAILED' END,
            coalesce(p_amount, 0), coalesce(p_currency, pi.currency), p_raw_digest, v_to IS NOT NULL, v_disp);
  IF v_to IS NULL THEN RETURN jsonb_build_object('applied', false, 'disposition', v_disp, 'state', pi.state); END IF;

  UPDATE payment_intents SET state=v_to, provider_reference=coalesce(p_provider_reference, provider_reference), mode=p_mode,
         fee_minor=CASE WHEN v_to='CONFIRMED' THEN p_fee ELSE fee_minor END,
         verified_at=CASE WHEN v_to='CONFIRMED' THEN clock_timestamp() ELSE verified_at END WHERE id=pi.id;
  IF v_to = 'CONFIRMED' THEN
    v_credit := CASE pi.purpose WHEN 'ENTRY_FEE' THEN '2100-CUSTOMER-LIABILITY' ELSE '1200-SPONSOR-RECEIVABLE' END;
    v_lines := jsonb_build_array(
      jsonb_build_object('account','1110-CHAPA-CLEARING','currency',pi.currency,'amount_minor',pi.amount_minor - coalesce(p_fee,0)),
      jsonb_build_object('account',v_credit,'currency',pi.currency,'amount_minor',-pi.amount_minor));
    IF coalesce(p_fee,0) > 0 THEN
      v_lines := v_lines || jsonb_build_array(jsonb_build_object('account','5200-PAYMENT-FEES','currency',pi.currency,'amount_minor',p_fee));
    END IF;
    PERFORM post_journal('chapa.payment', p_merchant_ref, 'Chapa payment ' || coalesce(p_provider_reference,''), v_lines);
    IF pi.purpose = 'SPONSOR_INVOICE' THEN
      UPDATE sponsor_invoices SET state='PAID', paid_at=clock_timestamp() WHERE id=pi.sponsor_invoice_id;
    END IF;
    INSERT INTO outbox(legal_entity_id,aggregate_type,aggregate_id,event_type,payload,classification)
      VALUES (current_entity(),'payment',pi.id,'payment.confirmed.v1',jsonb_build_object('amount_minor',pi.amount_minor,'purpose',pi.purpose),'NO_PII');
  END IF;
  RETURN jsonb_build_object('applied', true, 'disposition', v_disp, 'state', v_to, 'intent_id', pi.id);
END $$;

-- ---------- Refunds: FINANCE requests, a different CFO approves ----------
CREATE FUNCTION request_refund(p_intent uuid, p_amount bigint, p_reason text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE pi record; open_amt bigint; v uuid;
BEGIN
  IF NOT staff_has('FINANCE') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  SELECT * INTO pi FROM payment_intents WHERE id=p_intent AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND OR pi.state NOT IN ('CONFIRMED','RECONCILED','APPLIED','EXCEPTION') OR pi.provider_reference IS NULL THEN
    RAISE EXCEPTION 'NOT_REFUNDABLE' USING ERRCODE='VQ911'; END IF;
  SELECT coalesce(sum(amount_minor),0) INTO open_amt FROM payment_refunds WHERE payment_intent_id=p_intent AND state NOT IN ('REJECTED','REVERSED');
  IF pi.refunded_minor + open_amt + p_amount > pi.amount_minor THEN RAISE EXCEPTION 'REFUND_EXCEEDS_PAYMENT' USING ERRCODE='VQ911'; END IF;
  INSERT INTO payment_refunds(legal_entity_id, payment_intent_id, amount_minor, reason, requested_by, merchant_reference)
    VALUES (current_entity(), p_intent, p_amount, p_reason, current_actor(), 'VQR-' || replace(gen_random_uuid()::text,'-','')) RETURNING id INTO v;
  PERFORM audit(current_entity(), 'refund.requested', v, jsonb_build_object('amount', p_amount, 'reason', p_reason));
  RETURN v;
END $$;

CREATE FUNCTION approve_refund(p_refund uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE r record; pi record;
BEGIN
  IF NOT staff_has('CFO') THEN RETURN jsonb_build_object('ok', false, 'code', 'ROLE_NOT_HELD'); END IF;
  SELECT * INTO r FROM payment_refunds WHERE id=p_refund AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND OR r.state <> 'REQUESTED' THEN RETURN jsonb_build_object('ok', false, 'code', 'NOT_PENDING'); END IF;
  IF r.requested_by = current_actor() THEN RETURN jsonb_build_object('ok', false, 'code', 'DUAL_CONTROL_REQUIRED'); END IF;
  SELECT * INTO pi FROM payment_intents WHERE id=r.payment_intent_id;
  UPDATE payment_refunds SET state='APPROVED', approved_by=current_actor() WHERE id=p_refund;
  PERFORM audit(current_entity(), 'refund.approved', p_refund, '{}');
  RETURN jsonb_build_object('ok', true, 'provider_reference', pi.provider_reference, 'amount_minor', r.amount_minor,
                            'currency', pi.currency, 'reason', r.reason, 'merchant_reference', r.merchant_reference);
END $$;

CREATE FUNCTION mark_refund_submitted(p_refund uuid, p_provider_ref_id text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
BEGIN
  UPDATE payment_refunds SET state='SUBMITTED', provider_ref_id=p_provider_ref_id WHERE id=p_refund AND legal_entity_id=current_entity() AND state='APPROVED';
  RETURN CASE WHEN FOUND THEN 'OK' ELSE 'NOT_APPROVED' END;
END $$;

-- Settlement comes from Chapa's refund-verify API. 'refunded' moves money back; 'reversed' means it never left.
CREATE FUNCTION settle_refund(p_provider_ref_id text, p_status text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE r record; pi record; v_debit text;
BEGIN
  SELECT * INTO r FROM payment_refunds WHERE provider_ref_id=p_provider_ref_id AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND THEN RETURN 'UNKNOWN_REFUND'; END IF;
  IF r.state IN ('REFUNDED','REVERSED') THEN RETURN 'ALREADY_SETTLED'; END IF;
  IF p_status IN ('initiated','processing') THEN RETURN 'STILL_PROCESSING'; END IF;
  SELECT * INTO pi FROM payment_intents WHERE id=r.payment_intent_id FOR UPDATE;
  IF p_status = 'refunded' THEN
    v_debit := CASE pi.purpose WHEN 'ENTRY_FEE' THEN '2100-CUSTOMER-LIABILITY' ELSE '1200-SPONSOR-RECEIVABLE' END;
    PERFORM post_journal('chapa.refund', r.id::text, 'Chapa refund ' || p_provider_ref_id,
      jsonb_build_array(jsonb_build_object('account',v_debit,'currency',pi.currency,'amount_minor',r.amount_minor),
                        jsonb_build_object('account','1110-CHAPA-CLEARING','currency',pi.currency,'amount_minor',-r.amount_minor)));
    UPDATE payment_intents SET refunded_minor = refunded_minor + r.amount_minor,
           state = CASE WHEN refunded_minor + r.amount_minor = amount_minor THEN 'REFUNDED' ELSE state END WHERE id=pi.id;
    UPDATE payment_refunds SET state='REFUNDED', settled_at=clock_timestamp() WHERE id=r.id;
    INSERT INTO outbox(legal_entity_id,aggregate_type,aggregate_id,event_type,payload,classification)
      VALUES (current_entity(),'refund',r.id,'refund.posted.v1',jsonb_build_object('amount_minor',r.amount_minor),'NO_PII');
    RETURN 'REFUNDED';
  ELSIF p_status = 'reversed' THEN
    UPDATE payment_refunds SET state='REVERSED', settled_at=clock_timestamp() WHERE id=r.id;
    RETURN 'REVERSED';
  END IF;
  RETURN 'UNKNOWN_STATUS';
END $$;

-- ---------- A paid entry must use a payment made for THAT competition (audit finding) ----------
CREATE FUNCTION entry_payment_binding() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.payment_intent_id IS NOT NULL AND NOT EXISTS (
     SELECT 1 FROM payment_intents WHERE id = NEW.payment_intent_id AND purpose = 'ENTRY_FEE'
        AND competition_id = NEW.competition_id AND customer_id = NEW.customer_id) THEN
    RAISE EXCEPTION 'PAYMENT_NOT_FOR_THIS_COMPETITION' USING ERRCODE='VQ912';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER entries_payment_binding BEFORE INSERT ON entries FOR EACH ROW EXECUTE FUNCTION entry_payment_binding();

-- ---------- RLS + grants ----------
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['sponsor_invoices','payment_refunds'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_scope ON %I AS PERMISSIVE USING (legal_entity_id = veriq.current_entity()) WITH CHECK (legal_entity_id = veriq.current_entity())', t);
    EXECUTE format('CREATE POLICY tenant_guard ON %I AS RESTRICTIVE USING (veriq.current_entity() IS NOT NULL) WITH CHECK (veriq.current_entity() IS NOT NULL)', t);
    EXECUTE format('GRANT SELECT ON %I TO veriq_app, veriq_auditor', t);
  END LOOP;
END $$;
DO $$ DECLARE f record; BEGIN
  FOR f IN SELECT p.oid::regprocedure AS sig FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='veriq' LOOP
    EXECUTE format('ALTER FUNCTION %s SET search_path = veriq, pg_temp', f.sig);
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', f.sig);
  END LOOP;
END $$;
GRANT EXECUTE ON FUNCTION create_authorization(char,text,text,text), bootstrap_chart_of_accounts(char), create_sponsor(text),
  propose_staff(text,text[],uuid), activate_staff(uuid), deactivate_staff(uuid), set_provider_state(text,text,boolean,char),
  issue_sponsor_invoice(uuid,text,text,bigint,char), create_payment_intent(text,text,text,uuid,uuid,uuid,text), set_checkout(uuid,text),
  apply_verified_payment(text,text,text,text,bigint,char,bigint,text,text,text,char), request_refund(uuid,bigint,text),
  approve_refund(uuid), mark_refund_submitted(uuid,text), settle_refund(text,text) TO veriq_app;
RESET ROLE;
