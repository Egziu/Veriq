# Deploy VERIQ to Railway (checking / staging environment)

Rehearsed locally on 15 Oct 2026 with the same commands Railway runs: migrations via `DATABASE_URL`, the image's
start command, seed, portal proxy — **18/18 smoke checks passed**. This environment is for checking: development
keyring (no HSM), development tokens, Chapa test mode. It is NOT a production deployment.

## Architecture on Railway
```
Internet ──HTTPS──► portal (Next.js, public domain)
                       │  /v1/*, /health, /ready proxied over the private network (same site: cookies + CSP work)
                       ▼
                    core (FastAPI, NO public domain) ──► Postgres (Railway)
                    worker (outbox, claim expiry, Chapa reconciliation) ──► Postgres
```
Keeping `core` private means the API is reachable only through the portal.

## 1. Create the project
1. New project → **Deploy from GitHub repo** → `Egziu/Veriq` (repo must contain the unpacked source, not the zip).
2. Add **PostgreSQL** (Railway template).
3. Create three services from the same repo and set each one's *Config file path* (Settings → Config-as-code):
   `core` → `infra/railway/core.json` · `worker` → `infra/railway/worker.json` · `portal` → `infra/railway/portal.json`

## 2. Variables
Generate secrets with `openssl rand -hex 32`. Put shared ones in **Shared Variables**.

**Shared:** `VERIQ_APP_DB_PASSWORD`, `VERIQ_DEV_TOKEN_KEY`, `VERIQ_DEV_KEY_SEED` (all random, 32+ chars), `VERIQ_ENV=development`

**core**
```
PORT=8080
DATABASE_URL=${{Postgres.DATABASE_URL}}
VERIQ_APP_DB_PASSWORD=${{shared.VERIQ_APP_DB_PASSWORD}}
VERIQ_APP_DSN=host=${{Postgres.PGHOST}} port=${{Postgres.PGPORT}} dbname=${{Postgres.PGDATABASE}} user=veriq_app password=${{shared.VERIQ_APP_DB_PASSWORD}}
VERIQ_ENV=${{shared.VERIQ_ENV}}
VERIQ_DEV_TOKEN_KEY=${{shared.VERIQ_DEV_TOKEN_KEY}}
VERIQ_DEV_KEY_SEED=${{shared.VERIQ_DEV_KEY_SEED}}
VERIQ_RP_ID=<portal-host>.up.railway.app
VERIQ_ORIGINS=https://<portal-host>.up.railway.app
# optional, Chapa TEST mode:
VERIQ_CHAPA_SECRET_KEY=CHASECK_TEST-...
VERIQ_CHAPA_WEBHOOK_SECRET=<random>
VERIQ_CHAPA_CALLBACK_BASE=https://<portal-host>.up.railway.app/v1/payments/chapa/callback
VERIQ_CHAPA_RETURN_URL=https://<portal-host>.up.railway.app/payments/return
```
**worker:** same `VERIQ_APP_DSN`, `VERIQ_ENV`, `VERIQ_DEV_KEY_SEED`, and the Chapa variables if used.

**portal**
```
VERIQ_CORE_INTERNAL_URL=http://${{core.RAILWAY_PRIVATE_DOMAIN}}:8080
NEXT_PUBLIC_VERIQ_ENTITY=<legal_entity_id from step 4>
```
Then **Settings → Networking → Generate Domain** on `portal` only.

## 3. Deploy
Deploy `core` first: its pre-deploy step runs `scripts/migrate_apply.sh "$DATABASE_URL"` (transactional, idempotent,
refuses edited migrations, sets the `veriq_app` password). `/ready` must return `{"ready": true}`. It returns 503 with
`UNSAFE_DB_ROLE` if `VERIQ_APP_DSN` points at the superuser, and the app refuses to start in that case.

## 4. Seed synthetic checking data
```
railway ssh --service core -- python scripts/railway/seed_demo.py > seed.json
```
Copy `legal_entity_id` into the portal's `NEXT_PUBLIC_VERIQ_ENTITY` and redeploy `portal`.

## 5. Check it
```
python scripts/railway/smoke.py https://<portal-host>.up.railway.app seed.json
```
Expect `18/18 checks passed`. The portal pages are at `/sponsor`, `/fulfillment`, `/claims`. Staff use the tokens in
`seed.json` as `Authorization: Bearer …` with any HTTP client. Interactive API docs are not exposed publicly because
`core` has no public domain.

## What this environment does not have
No HSM (seeded development keys), no RFC 3161 witnesses (publication allowed without them outside production),
passkey login needs `VERIQ_RP_ID`/`VERIQ_ORIGINS` set to the portal host, no Telegram bot unless you add its token.
Never put real customer data here.
