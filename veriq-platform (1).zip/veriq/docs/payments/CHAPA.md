# Chapa payment gateway — integration and go-live guide

Based on developer.chapa.co (read 15 Oct 2026): initialize, verify, webhooks, refunds, high-risk businesses.

## What is built (15 tests in `tests/integration/test_chapa.py`)
| Flow | Endpoint | Gate |
|---|---|---|
| Finance issues a sponsor invoice | `POST /v1/staff/sponsor-invoices` | FINANCE |
| Sponsor pays it on Chapa | `POST /v1/sponsor/invoices/{id}/pay` → `checkout_url` | SPONSOR member of that sponsor; Chapa ACTIVE |
| Paid competition entry fee | `POST /v1/payments/chapa/entry` → `checkout_url`, then `POST /v1/competitions/{id}/entries` with `payment_intent_id` | Country gate LIVE/PILOT for PAID + Chapa ACTIVE + **gaming acceptance recorded by CFO with evidence** |
| Return from Chapa | web `/payments/return?tx_ref=…` → `GET /v1/payments/chapa/callback/{entity}` | Always re-verifies |
| Webhook | `POST /v1/webhooks/chapa/{entity}` | `x-chapa-signature` HMAC, then re-verify |
| Missed webhooks / abandoned checkouts | worker, or `POST /v1/staff/payments/reconcile` | FINANCE/CFO |
| Refund | `POST /v1/staff/payments/{intent}/refunds` (FINANCE) → `POST /v1/staff/refunds/{id}/approve` (a **different** CFO) | two people |
| Provider switch | `POST /v1/staff/providers/chapa` | CFO; gaming acceptance needs evidence hash |

## Security decisions (and why)
1. **Money moves only on Chapa's verify API**, never on a webhook body, callback `status`, or the browser.
2. **`chapa-signature` alone is rejected.** Chapa documents it as HMAC(secret, secret) — the same value every time,
   so anyone who sees one request can replay it forever. We require `x-chapa-signature` (HMAC of the payload).
3. Chapa's docs and SDK disagree on the signed bytes; we accept raw body, compact JSON or spaced JSON, constant-time.
4. No timestamp in Chapa webhooks → replay is neutralised by idempotent event keys and re-verification.
5. `mode` mismatch (test result with live key or vice versa) → EXCEPTION, never applied. Test keys refused in production.
6. Amount/currency mismatch or fee > amount → EXCEPTION, nothing posted.
7. A Chapa 5xx means "unknown", never "unpaid": we never discard a checkout we cannot verify.
8. Checkout URLs are accepted only on `checkout.chapa.co` (server and browser both check).
9. The secret key is only ever sent as the Authorization header to Chapa (tested).

## Ledger (integer cents, ETB)
- Invoice issued: Dr 1200 Sponsor receivable / Cr 2300 Deferred sponsor revenue
- Payment confirmed: Dr 1110 Chapa clearing (amount − fee) + Dr 5200 Payment fees (fee) / Cr 1200 (invoice) or 2100 Customer liability (entry)
- Refund settled: Dr 1200 or 2100 / Cr 1110. **Chapa fees are not refunded** and stay in 5200.

## Go-live checklist (owner: you)
1. Chapa merchant account for each legal entity; complete KYB.
2. **For paid entries only:** written confirmation from Chapa that the exact VERIQ paid model is accepted
   (Chapa lists *gambling* and *online auctions* as high-risk). Hash the letter and record it with
   `POST /v1/staff/providers/chapa {"state":"ACTIVE","gaming_model_accepted":true,"evidence_sha256":...}`.
   Sponsor invoices do not need this.
3. Secrets manager: `VERIQ_CHAPA_SECRET_KEY` (CHASECK-… live), `VERIQ_CHAPA_WEBHOOK_SECRET` (long random).
4. Chapa dashboard → Webhooks: URL `https://api.veriq.et/v1/webhooks/chapa/<legal-entity-uuid>`, same secret.
5. Env: `VERIQ_CHAPA_CALLBACK_BASE=https://api.veriq.et/v1/payments/chapa/callback`, `VERIQ_CHAPA_RETURN_URL=https://portal.veriq.et/payments/return`.
6. Test mode first with Chapa's test cards/mobile numbers: one invoice paid, one failed, one refund, one missed webhook (stop the webhook, run reconcile).
7. Run the worker (`scripts/jobs/run_worker.sh`) so reconciliation runs every minute.
8. Pentest the webhook and callback endpoints specifically.
