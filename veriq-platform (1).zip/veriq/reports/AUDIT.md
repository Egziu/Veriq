# VERIQ deep audit — 15 October 2026 (round 3)

Method: automated audit (`scripts/audit/audit.py`: DB commands vs callers, API routes vs clients, tables vs write
paths, placeholders, job runners) plus file-by-file review, plus 122 automated tests on PostgreSQL 16 + SoftHSM2.

## A. Defects found and FIXED in this round (each has a regression test)

| # | Severity | Defect | Fix |
|---|---|---|---|
| 1 | Critical (operability) | 12 database commands had no API: competitions, rules, country authorizations, KYC verification, prize security, journal reversal could only be done with superuser SQL | 22 staff endpoints; `tests/e2e/test_admin_api_no_sql.py` runs a whole campaign through the API |
| 2 | High (money) | A payment made for competition A could fund an entry in competition B at the same price | DB trigger binds paid entry to its intent's competition and customer |
| 3 | High (money) | Retrying "Pay" expired an open checkout even if the sponsor had already paid on it | Verify the open checkout with Chapa first; reuse or apply it |
| 4 | High (money) | A Chapa 5xx was treated as "rejected", so a retry during an outage discarded a possibly-paid checkout | 5xx/429 = unknown outcome; only a definite 404 counts as unpaid |
| 5 | Medium (money) | A fee larger than the payment posted a negative clearing balance | `FEE_INVALID_EXCEPTION`, nothing posted |
| 6 | Medium (privacy) | Any staff account — including sponsor users — could read any entry receipt | Restricted to SUPPORT / COMP_OPS / AUDITOR / FRAUD |
| 7 | Medium (ops) | Outbox events never published; claims never expired; no reconciliation | `veriq_core/worker.py` + tests |
| 8 | Medium (deploy) | Docker build could never succeed (`--require-hashes` with an unhashed lock) | 47 packages pinned with 1,327 hashes; clean install verified |
| 9 | Medium (deploy) | Only migration script dropped the database | `scripts/migrate_apply.sh`: transactional, idempotent, detects edited migrations |
| 10 | Medium (security) | Staff could be created only by SQL; no two-person rule | INFRA_ADMIN proposes, a different CEO activates; same person refused |
| 11 | Low | Database errors from commands surfaced as HTTP 500 | Mapped to stable problem codes (403/409/422) |
| 12 | Low | Flutter `CardTheme` likely fails to compile on Flutter ≥ 3.27 | `CardThemeData`, minimum Flutter 3.27 |

## B. NON-FUNCTIONAL or EMPTY — what is still missing

### Empty folders (scaffolded, never filled)
| Folder | Meaning | Impact | What to build |
|---|---|---|---|
| `apps/admin` | **No staff web console.** All staff operations work only through the API (curl/Postman/scripts). | **High** — operations staff cannot run a campaign without technical help | Admin UI on top of the 22 staff endpoints (country gate, rules, competitions, KYC queue, finance/refunds, staff) |
| `apps/telegram` | **No Telegram Mini App front-end.** The bot's "Enter in the app" button opens a URL that does not exist. The entry API behind it works and is tested. | High for Telegram channel | Small web page reading `Telegram.WebApp.initData`, posting to `/v1/telegram/miniapp/entry` |
| `packages/api-client` | No generated client; web and Flutter clients are hand-typed | Low | Generate TS/Dart clients from `openapi/veriq-core.v1.json` |
| `db/seeds` | No demo seed data (tests build their own) | Low | Optional |

### Features that exist only partly
| Area | What works | What does not | Impact |
|---|---|---|---|
| Flutter app | Code for sign-up, passkeys, campaigns, entry, receipts, on-device verification, settings | **Never compiled or run** (SDK blocked in build sandbox). No screen to *open a claim* or enter a delivery address. No paid-entry/Chapa screen. `passkeys` 2.4.0 API unverified. No translations. | High |
| Web portals | Login, sponsor portal (+ **Pay with Chapa**), claims/delivery console, winner claim page, payment return page | No customer sign-up on web (passkey creation only via API/mobile); no admin console (see above); prototype HTML is static, not wired | Medium |
| Competition lifecycle | Close and publish via API | **No automatic close at `closes_at`** (entries are refused after it, but someone must close and publish); worker only warns | Medium |
| Identity | Passkeys, sessions, staff two-person creation | **No lost-passkey recovery.** **No KYC provider integration** — a compliance officer verifies manually through `/v1/staff/customers/{id}/identity` | High for pilot scale |
| Telegram bot | Commands, linking, receipts, results, dedupe, escaping, limits | Language choice not persisted (in memory); `/unlink` signs the customer out of *all* devices, not just Telegram | Low |
| Finance | Double-entry, Chapa payments/fees/refunds, invoices, reversal | No trial balance / reports endpoint; sponsor revenue stays in *deferred* (no recognition job — needs the accounting memo); no invoice PDF; no cash prize payouts (Chapa transfers not used — prizes are physical) | Medium |
| Witness | RFC 3161 tokens stored and verifiable | `witness_roots.external_ref` keeps the text `pending-external-witness` even after timestamping (cosmetic; receipts are in `witness_receipts`) | Cosmetic |
| Ops | Worker, drills, runbooks | No monitoring/alerting/tracing; rate limiting is per process (not shared across servers); expired sessions are never deleted (harmless growth) | Medium |
| Platform bootstrap | `scripts/ops/bootstrap_entity.py` (tested) | Countries and legal entities are created only by the DBA (intentional) | — |

### Placeholders you must fill before go-live
- `apps/web/public/.well-known/assetlinks.json` — Android release signing fingerprint (passkeys fail without it)
- `apps/web/public/.well-known/apple-app-site-association` — Apple Team ID
- Docker base image digest (`--build-arg PYTHON_IMAGE=python:3.12-slim@sha256:…`)
- Chapa live keys, webhook secret, webhook URL in the Chapa dashboard (see `docs/payments/CHAPA.md`)
- HSM PKCS#11 library/token, two RFC 3161 TSAs, Telegram bot token + webhook secret
- `security.py` development token key — development only; refused in production

### Never built (out of scope so far)
Procurement module, AI assistants, fraud analytics, load test at pilot scale, human-reviewed Ethiopic translations,
independent penetration test, legal opinion.
