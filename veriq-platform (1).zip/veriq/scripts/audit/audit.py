"""Static + schema audit: finds unreachable DB commands, unwired API routes, tables with no write path,
placeholders, empty modules, and stubs. Run: python scripts/audit/audit.py  (needs the migrated test DB)."""
import ast, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path[:0] = [f"{ROOT}/services/core", f"{ROOT}/packages/rules", f"{ROOT}/packages/verifier"]
os.environ.setdefault("VERIQ_ENV", "development")
import psycopg

def files(exts, skip=("node_modules", ".next", ".git", "__pycache__")):
    for d, ds, fs in os.walk(ROOT):
        ds[:] = [x for x in ds if x not in skip]
        for f in fs:
            if f.endswith(exts):
                yield os.path.join(d, f)

def read(p): return open(p, encoding="utf-8", errors="ignore").read()
prod_py = [p for p in files((".py",)) if "/tests/" not in p and "/scripts/audit/" not in p]
test_py = [p for p in files((".py",)) if "/tests/" in p]
src_prod = "\n".join(read(p) for p in prod_py)
src_tests = "\n".join(read(p) for p in test_py)
clients = "\n".join(read(p) for p in files((".ts", ".tsx", ".dart", ".html")))
out = []
def section(t): out.append(f"\n## {t}")
def item(s): out.append(f"- {s}")

# 1 empty / placeholder-only directories
section("Empty or placeholder-only directories")
for d in ["apps/admin", "apps/telegram", "packages/api-client", "db/seeds", "infra", "tests/e2e", "scripts/ops", "apps/web/public"]:
    p = f"{ROOT}/{d}"; n = sum(len(fs) for _, _, fs in os.walk(p)) if os.path.isdir(p) else -1
    item(f"`{d}`: {'MISSING' if n < 0 else str(n) + ' file(s)'}")

# 2 DB functions vs callers
with psycopg.connect("host=/tmp/pg dbname=veriq_test user=postgres") as c:
    fns = [r[0] for r in c.execute("SELECT p.proname FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='veriq' ORDER BY 1")]
    tables = [r[0] for r in c.execute("SELECT tablename FROM pg_tables WHERE schemaname='veriq' ORDER BY 1")]
    app_writes = {r[0] for r in c.execute("SELECT DISTINCT table_name FROM information_schema.role_table_grants WHERE grantee='veriq_app' AND privilege_type IN ('INSERT','UPDATE') AND table_schema='veriq'")}
    app_writes |= {r[0] for r in c.execute("SELECT DISTINCT table_name FROM information_schema.column_privileges WHERE grantee='veriq_app' AND privilege_type IN ('INSERT','UPDATE') AND table_schema='veriq'")}
    bodies = "\n".join(r[0] for r in c.execute("SELECT prosrc FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='veriq'"))
trigger_or_helper = {"forbid_mutation", "rule_guard", "journal_guard", "journal_balance_check", "result_guard", "exclusion_guard", "current_entity", "current_actor", "audit", "staff_has"}
section("Database commands with NO caller in production code (only SQL, scripts, or tests)")
api_src = read(f"{ROOT}/services/core/veriq_core/api/app.py")
for f in fns:
    if f in trigger_or_helper: continue
    in_prod = re.search(rf"['\"]{f}['\"]|veriq\.{f}\(", src_prod) is not None
    in_sql = re.search(rf"\b{f}\(", bodies.replace(f"FUNCTION {f}", "")) is not None
    if not in_prod:
        item(f"`{f}()` — " + ("called inside other SQL only" if in_sql else "no API/app path" + (" (tests only)" if f in src_tests else "")))

section("Tables with no write path for the application (no command function writes them, no app grant)")
for t in tables:
    written_by_fn = re.search(rf"(INSERT INTO|UPDATE)\s+{t}\b", bodies) is not None
    if not written_by_fn and t not in app_writes:
        item(f"`{t}` — rows can only be created by a database superuser")

# 3 API routes vs clients
section("API routes not used by any client (web portals, Flutter, Telegram, prototype)")
routes = re.findall(r'@app\.(get|post|put)\("([^"]+)"', api_src)
for m, p in routes:
    probe = re.sub(r"\{[^}]+\}", "", p).rstrip("/").split("/")[-1] or p
    key = p.split("{")[0].rstrip("/")
    if p in ("/health", "/ready") or "webhook" in p: continue
    if key not in clients and f"/{probe}" not in clients:
        item(f"`{m.upper()} {p}`")

# 4 placeholders / stubs
section("Placeholders, stubs and development-only code paths")
pats = [r"REPLACE_[A-Z_]+", r"pending-external-witness", r"\bTODO\b|\bFIXME\b", r"dev-only-not-a-secret", r"NotImplemented", r"if False"]
for p in files((".py", ".sql", ".ts", ".tsx", ".dart", ".json", ".yml", ".yaml", ".xml", ".entitlements", "Dockerfile.core", ".md")):
    if "/tests/" in p or "/scripts/audit/" in p or "/docs/" in p or "/reports/" in p or p.endswith("README.md"): continue
    for pat in pats:
        for mm in set(re.findall(pat, read(p))):
            item(f"`{os.path.relpath(p, ROOT)}`: {mm}")

# 5 background jobs referenced but absent
section("Background work that is designed but has no runner")
for name, sig in {"outbox publisher (published_at never set)": "published_at = ", "claim expiry scheduler": "expire_claims",
                  "auto-close at closes_at": "close_competition", "session cleanup": "DELETE FROM veriq.sessions"}.items():
    runner = [p for p in prod_py if sig in read(p) and ("scripts/jobs" in p or "worker" in p)]
    if not runner: item(name)

print("# VERIQ automated audit\n" + "\n".join(out))
