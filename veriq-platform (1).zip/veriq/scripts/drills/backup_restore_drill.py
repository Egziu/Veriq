"""VERIQ backup / restore / failover drill — executed, measured, and verified (not a document).

Phases
  0  Configure primary: wal_level=replica, WAL archiving (archive_timeout=60s), replication slots.
  1  Physical base backup (pg_basebackup, fast checkpoint, streamed WAL).
  2  Workload A (campaign, entries, close, signed result, ledger) -> snapshot facts at T1 -> WAL switch.
  3  Workload B after T1.
  4  Point-in-time restore to T1 on a separate instance -> facts must equal T1 snapshot; workload B absent.
  5  Full restore from archive -> facts must equal the primary.
  6  Synchronous standby (remote_apply) -> workload C -> primary killed (immediate) -> standby promoted
     -> every committed entry present (RPO = 0 for accepted entries).
Every restored instance is checked for: ledger balance, audit hash chains, receipt chains + chain heads,
FORCE RLS on all tenant tables, unprivileged app role, and independent verification of each published result.
Writes reports/drills/<UTC timestamp>.md. Exit code 0 only if every check passes.
"""
from __future__ import annotations
import base64, json, os, shutil, subprocess, sys, time
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
for p in ("tests", "services/core", "packages/rules", "packages/verifier"):
    sys.path.insert(0, os.path.join(ROOT, p))
DB = "veriq_drill"
os.environ["VERIQ_TEST_DB"] = DB
import psycopg  # noqa: E402
from psycopg.rows import dict_row  # noqa: E402

PGB = "/usr/lib/postgresql/16/bin"
SOCK = "/tmp/pg"
WORK = "/tmp/pgdrill"
ARCHIVE = f"{WORK}/archive"
LOG: list[str] = []
FAIL: list[str] = []


def sh(cmd: str, check=True):
    r = subprocess.run(["su", "postgres", "-c", cmd], capture_output=True, text=True)
    if check and r.returncode:
        raise RuntimeError(f"{cmd}\n{r.stderr}")
    return r.stdout.strip()


def say(s):
    print(s); LOG.append(s)


def check(name, ok, detail=""):
    say(f"  [{'PASS' if ok else 'FAIL'}] {name}{(' — ' + detail) if detail else ''}")
    if not ok:
        FAIL.append(name)


def conn(port, db=DB):
    return psycopg.connect(f"host={SOCK} port={port} dbname={db} user=postgres", autocommit=True, row_factory=dict_row)


def facts(port) -> dict:
    with conn(port) as c:
        f = {"entries": c.execute("SELECT count(*) n FROM veriq.entries").fetchone()["n"],
             "competitions": {str(r["id"]): (r["state"], r["accepted_count"], r["chain_head"]) for r in
                              c.execute("SELECT id, state, accepted_count, chain_head FROM veriq.competitions ORDER BY id").fetchall()},
             "journals": c.execute("SELECT count(*) n FROM veriq.journals WHERE state='POSTED'").fetchone()["n"],
             "ledger_sum": c.execute("SELECT coalesce(sum(amount_minor),0) s FROM veriq.journal_lines").fetchone()["s"],
             "results": c.execute("SELECT count(*) n FROM veriq.result_runs WHERE published_at IS NOT NULL").fetchone()["n"]}
    return f


def integrity(port, label):
    from veriq_core.kms import keyring_for
    import veriq_verifier
    with conn(port) as c:
        check(f"{label}: ledger balances to zero", c.execute("SELECT coalesce(sum(amount_minor),0) s FROM veriq.journal_lines").fetchone()["s"] == 0)
        unbalanced = c.execute("SELECT count(*) n FROM (SELECT journal_id FROM veriq.journal_lines GROUP BY journal_id, currency "
                               "HAVING sum(amount_minor)<>0) x").fetchone()["n"]
        check(f"{label}: every journal balanced", unbalanced == 0)
        ents = [r["id"] for r in c.execute("SELECT DISTINCT legal_entity_id id FROM veriq.audit_log").fetchall()]
        bad = []
        for e in ents:
            c.execute("SELECT set_config('veriq.entity_id', %s, false)", (str(e),))
            if not c.execute("SELECT veriq.verify_audit_chain() v").fetchone()["v"]["ok"]:
                bad.append(str(e))
        check(f"{label}: audit hash chains intact ({len(ents)} entities)", not bad, ",".join(bad))
        broken = 0
        for comp in c.execute("SELECT id, chain_head, accepted_count FROM veriq.competitions").fetchall():
            rows = c.execute("SELECT seq, prev_receipt_hash, receipt_hash FROM veriq.entries WHERE competition_id=%s ORDER BY seq", (comp["id"],)).fetchall()
            prev = "0" * 64
            for i, r in enumerate(rows, 1):
                if r["seq"] != i or r["prev_receipt_hash"] != prev:
                    broken += 1; break
                prev = r["receipt_hash"]
            if len(rows) != comp["accepted_count"] or (rows and prev != comp["chain_head"]):
                broken += 1
        check(f"{label}: receipt chains contiguous and match chain heads", broken == 0)
        forced = c.execute("SELECT count(*) n FROM pg_class k JOIN pg_namespace n ON n.oid=k.relnamespace WHERE n.nspname='veriq' "
                           "AND k.relkind='r' AND k.relname NOT IN ('countries','legal_entities','payment_providers') AND NOT (k.relrowsecurity AND k.relforcerowsecurity)").fetchone()["n"]
        check(f"{label}: FORCE RLS on every tenant table", forced == 0)
        role = c.execute("SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname='veriq_app'").fetchone()
        check(f"{label}: app role unprivileged", role == {"rolsuper": False, "rolbypassrls": False})
        ok_v = 0; runs = c.execute("SELECT legal_entity_id, manifest, manifest_digest, signature, winning_number FROM veriq.result_runs "
                                   "WHERE published_at IS NOT NULL").fetchall()
        for r in runs:
            pub = keyring_for(str(r["legal_entity_id"])).public_key_der()   # keys live in the HSM, not the database backup
            v = veriq_verifier.verify(r["manifest"], r["signature"], pub, {"manifest_digest": r["manifest_digest"], "winning_number": r["winning_number"]})
            ok_v += v["verified"]
        check(f"{label}: published results independently re-verified", ok_v == len(runs), f"{ok_v}/{len(runs)}")


def workload(tag: str, entries: int, close=True):
    from conftest import World
    from veriq_core.modules import fairness
    w = World(f"Drill entity {tag} (synthetic)"); w.activate()
    comp, _ = w.competition(cap=entries, hi=100000, title=f"Drill {tag}")
    custs = [w.customer() for _ in range(max(1, entries // 5))]
    for i in range(entries):
        assert w.enter(comp, custs[i % len(custs)], (i * 7919) % 100000 + 1)["ok"]
    with w.as_staff("cfo") as cur:
        from veriq_core.db import call
        call(cur, "post_journal", "sponsor.invoice", f"DRILL-{tag}", "Synthetic sponsor fee",
             json.dumps([{"account": "1000-BANK", "currency": "ETB", "amount_minor": 25_000_000},
                         {"account": "4000-SPONSOR-REVENUE", "currency": "ETB", "amount_minor": -25_000_000}]), None)
    if close:
        w.close(comp)
        with w.as_staff("ops") as cur:
            r = fairness.compute_and_publish(cur, comp, fairness.Signer(entity=w.entity), tsa_urls=[], tsa_roots=[], min_witness=0)
            assert r["publish"] == "OK"
    return w, comp


def start(datadir, port, extra=""):
    open(f"{datadir}/postgresql.auto.conf", "a").write(f"\nport = {port}\narchive_mode = off\n{extra}\n")
    sh(f"{PGB}/pg_ctl -D {datadir} -o '-k {SOCK} -p {port}' -l {datadir}.log -w -t 120 start")


def wait_ready(port, timeout=120):
    t = time.time()
    while time.time() - t < timeout:
        try:
            with conn(port, "postgres") as c:
                if not c.execute("SELECT pg_is_in_recovery() r").fetchone()["r"]:
                    return
        except Exception:
            pass
        time.sleep(0.3)
    raise RuntimeError("instance not ready")


def main():
    started = datetime.now(timezone.utc)
    say(f"# VERIQ backup / restore / failover drill — {started:%Y-%m-%d %H:%M:%S} UTC\n")
    for d in (WORK,):
        shutil.rmtree(d, ignore_errors=True)
    os.makedirs(ARCHIVE); shutil.chown(WORK, "postgres"); shutil.chown(ARCHIVE, "postgres")

    say("## Phase 0 — configure primary (WAL archiving)")
    with conn(5432, "postgres") as c:
        for k, v in {"wal_level": "replica", "archive_mode": "on", "archive_command": f"test ! -f {ARCHIVE}/%f && cp %p {ARCHIVE}/%f",
                     "archive_timeout": "60", "max_wal_senders": "10", "synchronous_standby_names": ""}.items():
            c.execute(f"ALTER SYSTEM SET {k} = '{v}'")
    sh(f"{PGB}/pg_ctl -D {SOCK}/data -o '-k {SOCK} -p 5432' -l {SOCK}/log -w restart")
    subprocess.run([f"{ROOT}/scripts/migrate.sh", DB], check=True, capture_output=True)
    with conn(5432) as c:
        c.execute("INSERT INTO veriq.countries VALUES ('ET','Ethiopia') ON CONFLICT DO NOTHING")
        c.execute("INSERT INTO veriq.payment_providers(code,state,gaming_model_accepted) VALUES ('fakepay','ACTIVE',true) ON CONFLICT DO NOTHING")
    say("  archive_mode=on, archive_timeout=60s, wal_level=replica")

    say("\n## Phase 1 — base backup")
    t = time.time(); sh(f"{PGB}/pg_basebackup -h {SOCK} -p 5432 -D {WORK}/base -X stream -c fast")
    say(f"  pg_basebackup completed in {time.time()-t:.1f}s ({sh(f'du -sh {WORK}/base').split()[0]})")

    say("\n## Phase 2 — workload A, snapshot at T1")
    wa, ca = workload("A", 300)
    with conn(5432) as c:
        t1 = c.execute("SELECT clock_timestamp() t").fetchone()["t"]
    fa = facts(5432); time.sleep(1.1)
    with conn(5432) as c:
        c.execute("SELECT pg_switch_wal()")
    say(f"  T1 = {t1.isoformat()} · entries={fa['entries']} journals={fa['journals']} results={fa['results']}")

    say("\n## Phase 3 — workload B after T1")
    wb, cb = workload("B", 200)
    with conn(5432) as c:
        c.execute("SELECT pg_switch_wal()"); c.execute("CHECKPOINT")
    time.sleep(2)
    fp = facts(5432)
    say(f"  primary now: entries={fp['entries']} journals={fp['journals']} results={fp['results']}")

    say("\n## Phase 4 — point-in-time restore to T1")
    t = time.time(); d = f"{WORK}/pitr"; shutil.copytree(f"{WORK}/base", d)
    subprocess.run(["chown", "-R", "postgres", d]); os.chmod(d, 0o700)
    open(f"{d}/recovery.signal", "w").close()
    start(d, 5433, f"restore_command = 'cp {ARCHIVE}/%f %p'\nrecovery_target_time = '{t1.isoformat()}'\nrecovery_target_action = 'promote'")
    wait_ready(5433); rto = time.time() - t
    f4 = facts(5433)
    check("PITR: state equals snapshot at T1", f4 == fa, f"entries {f4['entries']} vs {fa['entries']}")
    check("PITR: workload B absent (restored to the exact point)", str(cb) not in f4["competitions"])
    integrity(5433, "PITR")
    say(f"  RTO (copy + WAL replay + promote): {rto:.1f}s")
    sh(f"{PGB}/pg_ctl -D {d} -m fast stop")

    say("\n## Phase 5 — full restore from archive")
    t = time.time(); d = f"{WORK}/full"; shutil.copytree(f"{WORK}/base", d)
    subprocess.run(["chown", "-R", "postgres", d]); os.chmod(d, 0o700)
    open(f"{d}/recovery.signal", "w").close()
    start(d, 5433, f"restore_command = 'cp {ARCHIVE}/%f %p'\nrecovery_target_action = 'promote'")
    wait_ready(5433); rto_full = time.time() - t
    f5 = facts(5433)
    check("Full restore: identical to primary", f5 == fp, f"entries {f5['entries']} vs {fp['entries']}")
    integrity(5433, "Full restore")
    say(f"  RTO: {rto_full:.1f}s")
    sh(f"{PGB}/pg_ctl -D {d} -m fast stop")

    say("\n## Phase 6 — synchronous standby, primary killed, standby promoted")
    sb = f"{WORK}/standby"
    sh(f"{PGB}/pg_basebackup -h {SOCK} -p 5432 -D {sb} -X stream -c fast -R -C -S drill_slot")
    open(f"{sb}/postgresql.auto.conf", "a").write(f"\nprimary_conninfo = 'host={SOCK} port=5432 user=postgres application_name=drill_standby'\n")
    start(sb, 5434)
    with conn(5432, "postgres") as c:
        c.execute("ALTER SYSTEM SET synchronous_standby_names = 'drill_standby'")
        c.execute("ALTER SYSTEM SET synchronous_commit = 'remote_apply'"); c.execute("SELECT pg_reload_conf()")
    time.sleep(2)
    with conn(5432, "postgres") as c:
        st = c.execute("SELECT sync_state FROM pg_stat_replication WHERE application_name='drill_standby'").fetchone()
    check("Standby attached synchronously", bool(st) and st["sync_state"] == "sync", str(st))
    wc, cc = workload("C", 150, close=False)
    fc = facts(5432)
    t = time.time()
    sh(f"{PGB}/pg_ctl -D {SOCK}/data -m immediate stop")          # simulated primary loss, no clean shutdown
    sh(f"{PGB}/pg_ctl -D {sb} promote -w")
    wait_ready(5434); rto_fail = time.time() - t
    f6 = facts(5434)
    check("Failover: zero committed entries lost (RPO = 0)", f6 == fc, f"entries {f6['entries']} vs {fc['entries']}")
    check("Failover: open competition C chain intact on new primary", f6["competitions"].get(str(cc)) == fc["competitions"][str(cc)])
    integrity(5434, "Promoted standby")
    say(f"  Failover RTO (kill -> promoted & writable): {rto_fail:.1f}s")
    sh(f"{PGB}/pg_ctl -D {sb} -m fast stop")

    # Restore the development primary to its normal configuration.
    with open(f"{SOCK}/data/postgresql.auto.conf", "a") as fh:
        fh.write("\nsynchronous_standby_names = ''\nsynchronous_commit = 'on'\n")
    sh(f"{PGB}/pg_ctl -D {SOCK}/data -o '-k {SOCK} -p 5432' -l {SOCK}/log -w start")
    with conn(5432, "postgres") as c:
        c.execute("ALTER SYSTEM SET synchronous_standby_names = ''"); c.execute("ALTER SYSTEM SET synchronous_commit = 'on'")
        c.execute("SELECT pg_reload_conf()")
        c.execute("SELECT pg_drop_replication_slot('drill_slot') WHERE EXISTS (SELECT 1 FROM pg_replication_slots WHERE slot_name='drill_slot')")

    say("\n## Summary")
    say(f"  Archive-only RPO bound: archive_timeout = 60 s (entries committed after the last archived segment are at risk).")
    say(f"  Synchronous standby RPO for committed entries: 0 (measured).")
    say(f"  RTO: PITR {rto:.1f}s · full restore {rto_full:.1f}s · failover {rto_fail:.1f}s (local disk, {fp['entries']} entries; scale with data size).")
    say(f"  Result: {'ALL CHECKS PASSED' if not FAIL else 'FAILED: ' + ', '.join(FAIL)}")
    os.makedirs(f"{ROOT}/reports/drills", exist_ok=True)
    out = f"{ROOT}/reports/drills/{started:%Y%m%dT%H%M%SZ}.md"
    open(out, "w").write("\n".join(LOG) + "\n")
    print("report:", out)
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
