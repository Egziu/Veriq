#!/usr/bin/env bash
# Runs the background worker (outbox, claim expiry, Chapa reconciliation, overdue-close alerts).
cd "$(dirname "$0")/../.." && PYTHONPATH=services/core:packages/rules:packages/verifier exec python3 -m veriq_core.worker "$@"
