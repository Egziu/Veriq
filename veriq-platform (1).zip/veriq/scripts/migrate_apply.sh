#!/usr/bin/env bash
# PRODUCTION migration runner (scripts/migrate.sh is test-only: it DROPS the database).
# - Applies each db/migrations/*.sql not yet recorded, each in ONE transaction (all-or-nothing).
# - Records name + SHA-256; refuses to continue if an already-applied file was edited afterwards (tamper/drift check).
# Usage: PGHOST=... PGUSER=postgres scripts/migrate_apply.sh <dbname | postgresql://... URL>
# If VERIQ_APP_DB_PASSWORD is set, the restricted veriq_app login role gets that password (needed for TCP connections).
set -euo pipefail
DB=${1:?database name}; DIR="$(cd "$(dirname "$0")/../db/migrations" && pwd)"
q() { psql -d "$DB" -v ON_ERROR_STOP=1 -qtAX "$@"; }
q -c "CREATE TABLE IF NOT EXISTS public.veriq_migrations(name text PRIMARY KEY, sha256 char(64) NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())"
for f in "$DIR"/*.sql; do
  n=$(basename "$f"); h=$(sha256sum "$f" | cut -d' ' -f1)
  rec=$(q -c "SELECT sha256 FROM public.veriq_migrations WHERE name='$n'")
  if [[ -n "$rec" ]]; then
    [[ "$rec" == "$h" ]] || { echo "DRIFT: $n changed after it was applied (recorded $rec, file $h). Write a new migration instead." >&2; exit 2; }
    echo "skip   $n"; continue
  fi
  psql -d "$DB" -v ON_ERROR_STOP=1 -q -1 -f "$f" -c "INSERT INTO public.veriq_migrations(name, sha256) VALUES ('$n', '$h')" >/dev/null
  echo "applied $n"
done
if [[ -n "${VERIQ_APP_DB_PASSWORD:-}" ]]; then
  [[ ${#VERIQ_APP_DB_PASSWORD} -ge 24 ]] || { echo "VERIQ_APP_DB_PASSWORD must be at least 24 characters" >&2; exit 3; }
  psql -d "$DB" -v ON_ERROR_STOP=1 -qtAX -v pw="$VERIQ_APP_DB_PASSWORD" -c "ALTER ROLE veriq_app PASSWORD :'pw'" >/dev/null 2>&1 \
    || printf "ALTER ROLE veriq_app PASSWORD :'pw';\n" | psql -d "$DB" -v ON_ERROR_STOP=1 -qtAX -v pw="$VERIQ_APP_DB_PASSWORD" >/dev/null
  echo "veriq_app password set"
fi
