"""One-time platform bootstrap for a new legal entity (run by the DBA at a witnessed ceremony, then never again).
Creates the country row, the legal entity, and exactly two ACTIVE founders — a CEO and an INFRA_ADMIN who must be
different people. Every other staff member is then created through the API with two-person control
(INFRA_ADMIN proposes, CEO activates). Records the ceremony in the hash-chained audit log.
Usage: PG_SUPER_DSN="host=... dbname=veriq user=postgres" python bootstrap_entity.py ET Ethiopia "VERIQ Ethiopia PLC" "CEO Name" "Admin Name" """
import os, sys
import psycopg

cc, cname, entity_name, ceo, admin = sys.argv[1:6]
if ceo.strip().lower() == admin.strip().lower():
    sys.exit("CEO and INFRA_ADMIN must be different people")
with psycopg.connect(os.environ["PG_SUPER_DSN"]) as c:
    c.execute("INSERT INTO veriq.countries VALUES (%s,%s) ON CONFLICT DO NOTHING", (cc, cname))
    ent = c.execute("INSERT INTO veriq.legal_entities(name,country_code) VALUES (%s,%s) RETURNING id", (entity_name, cc)).fetchone()[0]
    ceo_id = c.execute("INSERT INTO veriq.staff_users(legal_entity_id,display_name,roles) VALUES (%s,%s,ARRAY['CEO']) RETURNING id", (ent, ceo)).fetchone()[0]
    adm_id = c.execute("INSERT INTO veriq.staff_users(legal_entity_id,display_name,roles) VALUES (%s,%s,ARRAY['INFRA_ADMIN']) RETURNING id", (ent, admin)).fetchone()[0]
    c.execute("SELECT set_config('veriq.entity_id', %s, true)", (str(ent),))
    c.execute("SELECT veriq.audit(%s, 'entity.bootstrapped', %s, jsonb_build_object('ceo', %s::text, 'infra_admin', %s::text))", (ent, ent, ceo_id, adm_id))
print(f"legal_entity_id={ent}\nceo_staff_id={ceo_id}\ninfra_admin_staff_id={adm_id}")
print("Next: hsm_ceremony.py <entity>; enroll_staff.py for both founders; then create all other staff via /v1/staff/staff.")
