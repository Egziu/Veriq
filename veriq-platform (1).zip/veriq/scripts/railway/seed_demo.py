"""Seed a CHECKING environment (Railway staging) with a synthetic, ready-to-use world.
Runs inside the core service:  railway ssh --service core -- python scripts/railway/seed_demo.py
Needs DATABASE_URL (superuser, for the one-time bootstrap) and VERIQ_DEV_TOKEN_KEY (to print role tokens).
Refuses to run when VERIQ_ENV=production. Everything it creates is labelled "(synthetic)"."""
import hashlib, json, os, sys, uuid
from datetime import datetime, timedelta, timezone
sys.path[:0] = ["services/core", "packages/rules", "packages/verifier"]
import psycopg
from psycopg.rows import dict_row

if os.environ.get("VERIQ_ENV") == "production":
    sys.exit("refusing: seed_demo is for checking environments only")
from veriq_core import security

EVIDENCE = ['CLASSIFICATION', 'REGULATOR_APPROVAL', 'RULE_VERSION', 'AGE_GEO_POLICY', 'KYC_AML_POLICY', 'PRIVACY_RESIDENCY',
            'ADVERTISING_CHANNEL', 'TAX_ACCOUNTING', 'PRIZE_CONTRACT_RESERVE', 'INCIDENT_SUPPORT', 'FAIRNESS_PROCESS']
ROLES = {"ceo": ["CEO"], "infra_admin": ["INFRA_ADMIN"], "compliance": ["COMPLIANCE"], "compliance2": ["COMPLIANCE"],
         "cfo": ["CFO"], "finance": ["FINANCE"], "deployment": ["DEPLOYMENT"], "comp_ops": ["COMP_OPS"], "support": ["SUPPORT"],
         "inventory": ["INVENTORY"], "courier_a": ["FULFILLMENT"], "courier_b": ["FULFILLMENT"], "auditor": ["AUDITOR"], "sponsor": ["SPONSOR"]}
H = lambda s: hashlib.sha256(s.encode()).hexdigest()
now = datetime.now(timezone.utc)

c = psycopg.connect(os.environ["DATABASE_URL"], autocommit=True, row_factory=dict_row)
def as_(ent, actor):
    c.execute("SELECT set_config('veriq.entity_id', %s, false), set_config('veriq.actor_id', %s, false)", (ent, actor or ""))
def fn(name, *args):
    return c.execute(f"SELECT veriq.{name}({','.join(['%s'] * len(args))}) AS r", args).fetchone()["r"]

c.execute("INSERT INTO veriq.countries VALUES ('ET','Ethiopia') ON CONFLICT DO NOTHING")
ent = str(c.execute("INSERT INTO veriq.legal_entities(name,country_code) VALUES (%s,'ET') RETURNING id",
                    (f"VERIQ Check {now:%Y%m%d-%H%M} (synthetic)",)).fetchone()["id"])
staff = {k: str(c.execute("INSERT INTO veriq.staff_users(legal_entity_id,display_name,roles) VALUES (%s,%s,%s) RETURNING id",
                          (ent, f"{k} (synthetic)", r)).fetchone()["id"]) for k, r in ROLES.items()}
as_(ent, staff["cfo"]); fn("bootstrap_chart_of_accounts", "ETB")
as_(ent, staff["comp_ops"]); sponsor = str(fn("create_sponsor", "Synthetic Telecom PLC"))
c.execute("INSERT INTO veriq.sponsor_members(sponsor_id,staff_id,legal_entity_id) VALUES (%s,%s,%s)", (sponsor, staff["sponsor"], ent))

for channel in ("WEB", "TELEGRAM", "ANDROID", "IOS"):
    as_(ent, staff["compliance2"]); auth = str(fn("create_authorization", "ET", "SPONSOR_FREE", channel, "Synthetic pilot scope"))
    as_(ent, staff["compliance"])
    for k in EVIDENCE:
        fn("record_evidence", auth, k, H(k + auth), f"synthetic://dossier/{auth}/{k}.pdf", None)
    fn("transition_authorization", auth, "DOSSIER", None, None); fn("transition_authorization", auth, "REVIEWED", None, None)
    for who, role in (("compliance", "COMPLIANCE"), ("cfo", "CFO"), ("deployment", "DEPLOYMENT")):
        as_(ent, staff[who]); assert fn("approve_authorization", auth, role, "LIMITED_PILOT") == "OK"
    as_(ent, staff["deployment"])
    assert fn("transition_authorization", auth, "LIMITED_PILOT", now - timedelta(minutes=1), now + timedelta(days=30)) == "OK"

as_(ent, staff["comp_ops"])
rule = str(fn("draft_rule", json.dumps({"algorithm": "lowest-unique/1.0.0", "range": [1, 50], "cap": 2,
                                        "no_winner": "announce_and_rollover_prize", "nonce": str(uuid.uuid4())})))
as_(ent, staff["compliance"]); assert fn("approve_rule", rule) == "OK"
as_(ent, staff["comp_ops"])
comp = str(fn("create_competition", "ET", "SPONSOR_FREE", "Synthetic smartphone giveaway", rule, now - timedelta(seconds=5),
              now + timedelta(days=2), 0, "ETB", 1, 50, 2, 2_500_000))
assert fn("assign_sponsor", comp, sponsor) == "OK"
as_(ent, staff["cfo"]); assert fn("secure_prize", comp, 2_500_000, H("synthetic supplier commitment")) == "OK"
as_(ent, staff["comp_ops"]); assert fn("open_competition", comp) == "OK"

customers = []
for i in range(5):
    cid = str(uuid.uuid4())
    as_(ent, None)
    c.execute("INSERT INTO veriq.customers(id,legal_entity_id,country_code,terms_consent_at) VALUES (%s,%s,'ET',now())", (cid, ent))
    as_(ent, staff["compliance"]); assert fn("verify_customer_identity", cid, True, "VERIFIED") == "OK"
    customers.append(cid)

out = {"legal_entity_id": ent, "competition_id": comp, "sponsor_id": sponsor,
       "staff_tokens": {k: security.issue(v, ent, "staff", roles=ROLES[k], ttl=86400) for k, v in staff.items()},
       "customer_tokens": [security.issue(x, ent, "customer", ttl=86400) for x in customers],
       "note": "SYNTHETIC checking data. Tokens expire in 24 h. Development tokens are refused when VERIQ_ENV=production."}
print(json.dumps(out, indent=2))
