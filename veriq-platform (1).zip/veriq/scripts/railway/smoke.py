"""Smoke-test a deployed VERIQ (e.g. Railway) over HTTPS, then independently re-verify the published result.
Usage: python scripts/railway/smoke.py https://<core-or-portal-host> seed.json"""
import base64, json, sys, uuid
import httpx
sys.path[:0] = ["packages/verifier"]
import veriq_verifier

base, seed = sys.argv[1].rstrip("/"), json.load(open(sys.argv[2]))
http = httpx.Client(base_url=base, timeout=30)
S, C = seed["staff_tokens"], seed["customer_tokens"]
B = lambda t, **h: {"Authorization": f"Bearer {t}", **h}
results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond), detail)); print(f"{'PASS' if cond else 'FAIL'}  {name}  {detail}")

r = http.get("/health"); check("health", r.status_code == 200, r.text[:80])
r = http.get("/ready"); check("ready (DB reachable, unprivileged role)", r.status_code == 200, r.text[:80])
check("security headers", "strict-transport-security" in r.headers and r.headers.get("x-frame-options") == "DENY")
check("anonymous blocked", http.get("/v1/me/entries").status_code == 401)
r = http.get("/v1/availability", params={"country": "ET", "product": "PAID_COMPETITION", "channel": "WEB"}, headers=B(C[0]))
check("paid product blocked by gate", r.json().get("decision") != "OK", r.text[:80])
comp = seed["competition_id"]
picks = [7, 7, 12, 3, 3]
for tok, n in zip(C, picks):
    r = http.post(f"/v1/competitions/{comp}/entries", json={"selection": n}, headers=B(tok, **{"Idempotency-Key": f"smoke-{uuid.uuid4()}"}))
    check(f"entry {n} accepted", r.status_code == 201, r.text[:100])
key = f"smoke-{uuid.uuid4()}"
a = http.post(f"/v1/competitions/{comp}/entries", json={"selection": 20}, headers=B(C[0], **{"Idempotency-Key": key}))
b = http.post(f"/v1/competitions/{comp}/entries", json={"selection": 20}, headers=B(C[0], **{"Idempotency-Key": key}))
check("idempotent retry returns same entry", a.status_code == 201 and b.status_code == 200 and a.json()["entry_id"] == b.json()["entry_id"])
check("customer cannot close", http.post(f"/v1/staff/competitions/{comp}/close", headers=B(C[0])).status_code == 403)
r = http.post(f"/v1/staff/competitions/{comp}/close", headers=B(S["comp_ops"])); check("close + freeze", r.status_code == 200, r.text[:100])
late = http.post(f"/v1/competitions/{comp}/entries", json={"selection": 1}, headers=B(C[1], **{"Idempotency-Key": f"smoke-{uuid.uuid4()}"}))
check("late entry refused", late.status_code == 409)
r = http.post(f"/v1/staff/competitions/{comp}/result", headers=B(S["comp_ops"])); check("result published", r.status_code == 200, r.text[:120])
m = http.get(f"/v1/competitions/{comp}/manifest", headers=B(C[2])).json()
v = veriq_verifier.verify(m["manifest"], m["signature"], base64.b64decode(m["public_key_der_b64"]),
                          {"manifest_digest": m["manifest_digest"], "winning_number": m["winning_number"]})
check("independent re-verification on this machine", v["verified"], f"winner={v['winning_number']} reasons={v['reasons']}")
r = http.get(f"/v1/sponsor/competitions/{comp}/report", headers=B(S["sponsor"])); check("sponsor report (aggregated)", r.status_code == 200, r.text[:100])
check("sponsor cannot read receipts", http.get(f"/v1/entries/{a.json()['entry_id']}/receipt", headers=B(S["sponsor"])).status_code == 404)
failed = [n for n, ok, _ in results if not ok]
print(f"\n{len(results) - len(failed)}/{len(results)} checks passed" + (f"; FAILED: {failed}" if failed else ""))
sys.exit(1 if failed else 0)
