#!/bin/sh
# Bind to "::" (IPv6+IPv4, required for Railway private networking) when the kernel supports IPv6, else 0.0.0.0.
HOST="${VERIQ_BIND_HOST:-}"
if [ -z "$HOST" ]; then
  if python3 -c "import socket; socket.socket(socket.AF_INET6).close()" 2>/dev/null; then HOST="::"; else HOST="0.0.0.0"; fi
fi
exec python3 -m uvicorn veriq_core.api.app:app --host "$HOST" --port "${PORT:-8080}" --proxy-headers --forwarded-allow-ips='*' --no-server-header
