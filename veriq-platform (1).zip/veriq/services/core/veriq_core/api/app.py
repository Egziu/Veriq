"""VERIQ core HTTP API (modular monolith). Critical decisions happen in database command functions; this layer
authenticates (passkey sessions), enforces CSRF for cookie clients, rate-limits, validates and maps problem codes."""
from __future__ import annotations
import base64, hashlib, hmac, os, secrets, time, uuid
from collections import defaultdict
from datetime import date
from typing import Annotated

from fastapi import Depends, FastAPI, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator

from .. import pii, security
from ..db import call, tx
from ..kms import keyring_for
from ..modules import fairness, identity, payments, telegram

ENV = os.environ.get("VERIQ_ENV", "development")
app = FastAPI(title="VERIQ Core API", version="1.0.0-rc1",
              description="Trust in Every Win. Server-authoritative entries, country gates, ledger and verifiable results.",
              docs_url=None if ENV == "production" else "/docs", redoc_url=None,
              openapi_url=None if ENV == "production" else "/openapi.json")
app.add_middleware(CORSMiddleware, allow_origins=identity.ORIGINS, allow_credentials=True, allow_methods=["GET", "POST", "PUT"],
                   allow_headers=["Authorization", "Content-Type", "Idempotency-Key", "X-Channel", "X-CSRF-Token", "X-Entity",
                                  "X-Request-ID", "X-Client"])

PROBLEM_STATUS = {
    "DENIED_COUNTRY": 403, "DENIED_PRODUCT": 403, "EXPIRED_SCOPE": 403, "PROVIDER_SUSPENDED": 503,
    "RESERVE_SHORTFALL": 409, "COMPETITION_NOT_OPEN": 409, "IDEMPOTENCY_CONFLICT": 422, "ENTRY_CAP_REACHED": 409,
    "SELF_EXCLUDED": 403, "ELIGIBILITY_INCOMPLETE": 403, "CONSENT_REQUIRED": 403, "SELECTION_OUT_OF_RANGE": 422,
    "PAYMENT_REQUIRED": 402, "PAYMENT_NOT_CONFIRMED": 402, "PAYMENT_AMOUNT_MISMATCH": 422, "PAYMENT_NOT_FOUND": 404,
    "FREE_ENTRY_MUST_NOT_CHARGE": 422, "NOT_FOUND": 404, "CUSTOMER_NOT_FOUND": 404, "ROLE_NOT_HELD": 403,
    "UNAUTHENTICATED": 401, "RATE_LIMITED": 429, "RULE_NOT_APPROVED": 409, "NOT_OPEN": 409, "CSRF_FAILED": 403,
    "NO_PUBLISHED_WINNER": 404, "NOT_THE_WINNER": 403, "CLAIM_PERIOD_ENDED": 410, "NOT_REVIEWABLE": 409,
    "CLAIM_NOT_APPROVED": 409, "ITEM_NOT_AVAILABLE": 409, "NOT_ALLOCATED": 409, "NOT_DISPATCHED": 409,
    "DUAL_CONTROL_REQUIRED": 403, "SERIAL_MISMATCH": 422, "PROOF_REQUIRED": 422, "PHONE_ALREADY_REGISTERED": 409,
    "INVALID_ET_MOBILE": 422, "AUTH_FAILED": 401, "TELEGRAM_AUTH_FAILED": 401, "TELEGRAM_NOT_LINKED": 403,
    "WITNESS_REQUIRED": 409, "AGE_REQUIREMENT": 403, "VERIFICATION_MISMATCH": 409, "WEBHOOK_REJECTED": 401,
    "PAYLOAD_TOO_LARGE": 413, "CREATOR_EXCLUDED": 403, "MISSING_APPROVALS": 409, "ILLEGAL_TRANSITION": 409,
    "MISSING_EVIDENCE": 409, "INVALID_INTERVAL": 422, "NOT_DRAFT": 409, "NO_ACTOR": 401, "NOT_PROPOSED": 404,
    "SPONSOR_USERS_ONLY_SPONSOR_ROLE": 422, "PAYMENT_NOT_FOR_THIS_COMPETITION": 422, "BAD_URL": 422,
}


def problem(code: str, request: Request, detail: str | None = None, status: int | None = None) -> JSONResponse:
    st = status or PROBLEM_STATUS.get(code, 400)
    return JSONResponse(status_code=st, media_type="application/problem+json", content={
        "type": f"https://veriq.et/problems/{code.lower().replace('_', '-')}", "title": code, "status": st,
        "detail": detail or code, "code": code, "request_id": getattr(request.state, "request_id", None)})


class Problem(Exception):
    def __init__(self, code: str, detail: str | None = None, status: int | None = None):
        self.code, self.detail, self.status = code, detail, status


@app.exception_handler(Problem)
async def _problem(request: Request, exc: Problem):
    return problem(exc.code, request, exc.detail, exc.status)


from fastapi.exceptions import RequestValidationError


@app.exception_handler(RequestValidationError)
async def _validation(request: Request, exc: RequestValidationError):
    fields = [".".join(str(x) for x in e.get("loc", [])[1:]) + ": " + e.get("msg", "") for e in exc.errors()]
    return problem("VALIDATION_FAILED", request, "; ".join(fields)[:500], status=422)   # never echo the input


def _auth_tx(entity: str, fn):
    """Run an authentication step so that its side effects COMMIT even when authentication fails:
    a consumed challenge stays consumed and a clone-suspected credential stays revoked."""
    err, out = None, None
    with tx(entity) as cur:
        try:
            out = fn(cur)
        except identity.AuthError as e:
            err = e
    if err:
        raise Problem("AUTH_FAILED", str(err))
    return out


import psycopg as _pg


@app.exception_handler(_pg.Error)
async def _db_error(request: Request, exc: _pg.Error):
    state = getattr(exc, "sqlstate", "") or ""
    if state.startswith("VQ"):
        code = (exc.diag.message_primary or "DB_REJECTED").split()[0].rstrip(":")
        return problem(code, request, status=PROBLEM_STATUS.get(code, 409))
    if state == "23505":
        return problem("CONFLICT", request, "Already exists.", status=409)
    if state in ("23514", "23503", "22P02", "22023"):
        return problem("INVALID_INPUT", request, "Rejected by a data rule.", status=422)
    if state == "42501":
        return problem("ROLE_NOT_HELD", request, status=403)
    return problem("INTERNAL", request, "Unexpected error.", status=500)


@app.exception_handler(PermissionError)
async def _perm(request: Request, exc: PermissionError):
    return problem("UNAUTHENTICATED", request, str(exc), status=401)


# ---------------- edge-adjacent controls (production adds WAF/DDoS at the edge) ----------------
_BUCKETS: dict[str, list[float]] = defaultdict(list)
RATE = int(os.environ.get("VERIQ_RATE_PER_MIN", "120"))
AUTH_RATE = int(os.environ.get("VERIQ_AUTH_RATE_PER_MIN", "20"))


@app.middleware("http")
async def guard(request: Request, call_next):
    request.state.request_id = (request.headers.get("x-request-id") or str(uuid.uuid4()))[:64]
    if int(request.headers.get("content-length") or 0) > 64_000:
        return problem("PAYLOAD_TOO_LARGE", request)
    # NUL is never legitimate input and PostgreSQL text rejects it: refuse at the edge (found by the route sweep).
    raw_target = request.scope.get("raw_path", b"") + b"?" + request.scope.get("query_string", b"")
    if b"\x00" in raw_target or b"%00" in raw_target.lower():
        return problem("INVALID_INPUT", request, "Input contains a null character.", status=400)
    if request.method in ("POST", "PUT") and "json" in (request.headers.get("content-type") or ""):
        body = await request.body()
        if b"\x00" in body or b"\\u0000" in body:
            return problem("INVALID_INPUT", request, "Input contains a null character.", status=400)
    who = request.client.host if request.client else "anon"
    auth = request.headers.get("authorization") or request.cookies.get("vq_session") or ""
    is_auth = request.url.path.startswith("/v1/auth/")
    key = (hashlib.sha256(auth.encode()).hexdigest()[:16] if auth and not is_auth else who) + (":auth" if is_auth else ":api")
    limit = AUTH_RATE if is_auth else RATE
    now = time.monotonic(); b = _BUCKETS[key]; b[:] = [t for t in b if now - t < 60]
    if len(b) >= limit:
        return problem("RATE_LIMITED", request)
    b.append(now)
    resp = await call_next(request)
    resp.headers.update({
        "X-Request-ID": request.state.request_id, "Strict-Transport-Security": "max-age=63072000; includeSubDomains; preload",
        "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "X-Frame-Options": "DENY",
        "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'", "Cache-Control": "no-store",
        "Permissions-Policy": "camera=(), microphone=(), geolocation=()", "Cross-Origin-Opener-Policy": "same-origin"})
    return resp


# ---------------- authentication ----------------
def _presented_token(request: Request) -> tuple[str | None, bool]:
    a = request.headers.get("authorization") or ""
    if a.startswith("Bearer "):
        return a[7:], False
    if request.cookies.get("vq_session"):
        return request.cookies["vq_session"], True
    return None, False


def claims(request: Request) -> security.Claims:
    token, via_cookie = _presented_token(request)
    if not token:
        raise PermissionError("UNAUTHENTICATED")
    if via_cookie and request.method not in ("GET", "HEAD"):
        csrf, sent = request.cookies.get("vq_csrf", ""), request.headers.get("x-csrf-token", "")
        if not csrf or not sent or not hmac.compare_digest(csrf, sent):
            raise Problem("CSRF_FAILED")
    if token.startswith("vq1."):
        try:
            entity, th = identity.parse_token(token)
            uuid.UUID(entity)
        except Exception:
            raise PermissionError("MALFORMED_TOKEN")
        with tx(entity) as cur:
            s = call(cur, "resolve_session", th)
        if not s:
            raise PermissionError("SESSION_INVALID")
        return security.Claims(str(s["principal_id"]), entity, s["kind"], tuple(s["roles"]), 0)
    if ENV == "production":
        raise PermissionError("DEV_TOKENS_DISABLED")
    return security.verify(token)


def require_staff(c: security.Claims, *roles: str) -> None:
    if c.kind != "staff" or (roles and not set(roles) & set(c.roles)):
        raise Problem("ROLE_NOT_HELD")


def require_customer(c: security.Claims) -> None:
    if c.kind != "customer":
        raise Problem("ROLE_NOT_HELD", "Customers only.")


def session_response(token: str, kind: str, request: Request, extra: dict) -> JSONResponse:
    body = dict(extra)
    if request.headers.get("x-client") == "mobile":  # native apps keep the token in Android Keystore / iOS Keychain
        body["token"] = token
    resp = JSONResponse(body)
    max_age = 1800 if kind == "staff" else 43200
    resp.set_cookie("vq_session", token, max_age=max_age, httponly=True, secure=True, samesite="strict", path="/")
    resp.set_cookie("vq_csrf", secrets.token_urlsafe(24), max_age=max_age, httponly=False, secure=True, samesite="strict", path="/")
    return resp


# ---------------- models ----------------
class EntryIn(BaseModel):
    selection: int = Field(ge=0, le=10_000_000)
    payment_intent_id: uuid.UUID | None = None


class Onboard(BaseModel):
    phone: str = Field(min_length=9, max_length=20)
    full_name: str = Field(min_length=2, max_length=120)
    birth_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    accept_terms: bool

    @field_validator("accept_terms")
    @classmethod
    def must_accept(cls, v):
        if not v:
            raise ValueError("terms must be accepted")
        return v


class Credential(BaseModel):
    credential: dict
    label: str = Field(default="passkey", max_length=40)


class LoginBegin(BaseModel):
    principal_id: uuid.UUID | None = None
    kind: str | None = Field(default=None, pattern="^(customer|staff)$")


class Address(BaseModel):
    recipient: str = Field(max_length=120)
    phone: str = Field(max_length=20)
    city: str = Field(max_length=60)
    details: str = Field(max_length=300)


class Review(BaseModel):
    approve: bool
    note: str = Field(max_length=500)


class Allocate(BaseModel):
    prize_item_id: uuid.UUID


class Dispatch(BaseModel):
    carrier: str = Field(max_length=60)
    tracking_ref: str = Field(max_length=80)


class Delivered(BaseModel):
    scanned_serial: str = Field(max_length=80)
    recipient_signature_sha256: str = Field(pattern="^[0-9a-f]{64}$")
    handover_photo_sha256: str = Field(pattern="^[0-9a-f]{64}$")


class PrizeItem(BaseModel):
    model: str = Field(max_length=120)
    serial: str = Field(max_length=80)
    warranty_months: int = Field(ge=0, le=120)
    valuation_minor: int = Field(gt=0)
    evidence_sha256: str = Field(pattern="^[0-9a-f]{64}$")


class Exclusion(BaseModel):
    days: int = Field(ge=1, le=3650)


class MiniAppEntry(BaseModel):
    init_data: str = Field(max_length=4096)
    competition_id: uuid.UUID
    selection: int = Field(ge=0, le=10_000_000)
    idempotency_key: str = Field(min_length=8, max_length=128)


def _age_ok(birth: str) -> bool:
    y, m, d = map(int, birth.split("-")); today = date.today()
    return (today.year - y - ((today.month, today.day) < (m, d))) >= 18


def _s(v):
    return None if v is None else str(v)


# ---------------- probes ----------------
@app.get("/health")
def health():
    return {"status": "ok", "service": "veriq-core", "version": app.version, "env": ENV}


def _db_role_check() -> str | None:
    """Row-level security is ignored for superusers and BYPASSRLS roles. Refuse to serve with such a connection."""
    import psycopg
    from ..db import APP_DSN
    with psycopg.connect(APP_DSN, connect_timeout=3) as conn:
        r = conn.execute("SELECT rolsuper, rolbypassrls, current_user FROM pg_roles WHERE rolname = current_user").fetchone()
    if r[0] or r[1]:
        return f"UNSAFE_DB_ROLE:{r[2]}"
    return None


@app.on_event("startup")
def _refuse_privileged_db_role():
    if os.environ.get("VERIQ_SKIP_ROLE_CHECK") == "1":
        return
    try:
        problem_ = _db_role_check()
    except Exception:
        return   # DB not reachable yet: /ready reports it
    if problem_:
        raise RuntimeError(f"{problem_} — VERIQ_APP_DSN must use the restricted veriq_app role, never the database superuser")


@app.get("/ready")
def ready():
    try:
        p_ = _db_role_check()
    except Exception:
        return JSONResponse({"ready": False, "reason": "DATABASE_UNREACHABLE"}, status_code=503)
    if p_:
        return JSONResponse({"ready": False, "reason": p_}, status_code=503)
    return {"ready": True}


# ---------------- onboarding + passkeys ----------------
@app.post("/v1/auth/customers")
def onboard(body: Onboard, x_entity: Annotated[str, Header()]):
    if not _age_ok(body.birth_date):
        raise Problem("AGE_REQUIREMENT", "You must be 18 or older.")
    kr = keyring_for(x_entity); cid = str(uuid.uuid4())
    try:
        phone = pii.normalize_et_phone(body.phone)
        bidx = pii.phone_index(kr, x_entity, phone)
    except pii.PiiError as e:
        raise Problem(str(e))
    ct, wdek, kid = pii.encrypt(kr, x_entity, cid, {"full_name": body.full_name, "birth_date": body.birth_date, "phone": phone})
    with tx(x_entity) as cur:
        cur.execute("SELECT 1 FROM veriq.customers WHERE phone_blind_index=%s", (bidx,))
        if cur.fetchone():
            raise Problem("PHONE_ALREADY_REGISTERED", "Sign in with your passkey, or use account recovery.")
        cur.execute("SELECT country_code FROM veriq.legal_entities WHERE id=%s", (x_entity,))
        country = cur.fetchone()["country_code"]
        cur.execute("INSERT INTO veriq.customers(id, legal_entity_id, country_code, pii_ciphertext, pii_wrapped_dek, pii_key_id, "
                    "phone_blind_index, terms_consent_at) VALUES (%s,%s,%s,%s,%s,%s,%s, now())", (cid, x_entity, country, ct, wdek, kid, bidx))
        opts = identity.begin_registration(cur, cid, "customer", "VERIQ member")
    return {"customer_id": cid, "registration_options": opts,
            "next": "Create a passkey. Identity verification (age and KYC) follows before your first entry."}


@app.post("/v1/auth/passkey/register/finish")
def register_finish(request: Request, body: Credential, x_entity: Annotated[str, Header()]):
    def step(cur):
        pid = identity.finish_registration(cur, body.credential, body.label)
        cur.execute("SELECT principal_kind FROM veriq.passkey_credentials WHERE principal_id=%s ORDER BY created_at DESC LIMIT 1", (pid,))
        kind = cur.fetchone()["principal_kind"]
        return pid, kind, identity.new_session(cur, x_entity, pid, kind, "passkey", request.headers.get("user-agent", ""))
    pid, kind, token = _auth_tx(x_entity, step)
    return session_response(token, kind, request, {"principal_id": pid, "kind": kind})


@app.post("/v1/auth/passkey/login/begin")
def login_begin(body: LoginBegin, x_entity: Annotated[str, Header()]):
    with tx(x_entity) as cur:
        return identity.begin_authentication(cur, _s(body.principal_id), body.kind)


@app.post("/v1/auth/passkey/login/finish")
def login_finish(request: Request, body: Credential, x_entity: Annotated[str, Header()]):
    r = _auth_tx(x_entity, lambda cur: identity.finish_authentication(cur, x_entity, body.credential, request.headers.get("user-agent", "")))
    return session_response(r["token"], r["kind"], request, {"principal_id": r["principal_id"], "kind": r["kind"]})


@app.post("/v1/auth/logout")
def logout(request: Request, c: security.Claims = Depends(claims)):
    token, _ = _presented_token(request)
    with tx(c.entity, c.sub) as cur:
        call(cur, "revoke_session", hashlib.sha256(token.encode()).hexdigest())
    resp = JSONResponse({"signed_out": True})
    resp.delete_cookie("vq_session"); resp.delete_cookie("vq_csrf")
    return resp


@app.post("/v1/me/sessions/revoke-all")
def revoke_all(c: security.Claims = Depends(claims)):
    with tx(c.entity, c.sub) as cur:
        return {"revoked": call(cur, "revoke_sessions", c.sub, None)}


# ---------------- me ----------------
@app.get("/v1/me")
def me(c: security.Claims = Depends(claims)):
    require_customer(c)
    with tx(c.entity) as cur:
        cur.execute("SELECT pii_ciphertext, pii_wrapped_dek, kyc_state, age_verified, self_excluded_until FROM veriq.customers WHERE id=%s", (c.sub,))
        row = cur.fetchone()
    p = pii.decrypt(keyring_for(c.entity), c.entity, c.sub, bytes(row["pii_ciphertext"]), bytes(row["pii_wrapped_dek"])) if row["pii_ciphertext"] else {}
    phone = p.get("phone") or ""
    return {"customer_id": c.sub, "full_name": p.get("full_name"), "phone_masked": (phone[:6] + "•••" + phone[-2:]) if phone else None,
            "kyc_state": row["kyc_state"], "age_verified": row["age_verified"], "self_excluded_until": _s(row["self_excluded_until"])}


@app.post("/v1/me/self-exclusion")
def self_exclude(body: Exclusion, c: security.Claims = Depends(claims)):
    require_customer(c)
    with tx(c.entity) as cur:
        cur.execute("UPDATE veriq.customers SET self_excluded_until = greatest(coalesce(self_excluded_until, now()), now()) "
                    "+ make_interval(days => %s) WHERE id=%s RETURNING self_excluded_until", (body.days, c.sub))
        until = cur.fetchone()["self_excluded_until"]
    return {"self_excluded_until": until.isoformat(), "note": "This cannot be shortened before it ends."}


@app.post("/v1/me/telegram/link-code")
def telegram_code(c: security.Claims = Depends(claims)):
    require_customer(c)
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    code = "".join(secrets.choice(alphabet) for _ in range(8))
    with tx(c.entity) as cur:
        call(cur, "issue_challenge", "TELEGRAM_LINK", c.sub, "customer", hashlib.sha256(code.encode()).hexdigest(), 300)
    return {"code": f"{code[:4]}-{code[4:]}", "expires_in": 300, "instructions": "Send /link followed by this code to the VERIQ bot."}


# ---------------- campaigns + entries ----------------
@app.get("/v1/availability")
def availability(country: str, product: str, channel: str, c: security.Claims = Depends(claims)):
    with tx(c.entity, c.sub) as cur:
        return {"country": country, "product": product, "channel": channel,
                "decision": call(cur, "authz_check", c.entity, country, product, channel)}


@app.get("/v1/competitions")
def competitions(c: security.Claims = Depends(claims)):
    with tx(c.entity) as cur:
        cur.execute("SELECT c.id, c.title, c.state, c.product_type, c.opens_at, c.closes_at, c.number_min, c.number_max, c.per_customer_cap, "
                    "c.entry_fee_minor, c.currency, c.prize_secured, r.rule_hash, r.body AS rules FROM veriq.competitions c "
                    "JOIN veriq.rule_versions r ON r.id=c.rule_version_id WHERE c.state IN ('OPEN','FROZEN','RESULT_PUBLISHED') "
                    "ORDER BY c.closes_at DESC LIMIT 50")
        rows = cur.fetchall()
    return [{k: (str(v) if k in ("id", "opens_at", "closes_at") else v) for k, v in r.items()} for r in rows]


@app.post("/v1/competitions/{competition_id}/entries", status_code=201)
def submit_entry(competition_id: uuid.UUID, body: EntryIn, idempotency_key: Annotated[str, Header(min_length=8, max_length=128)],
                 x_channel: Annotated[str, Header()] = "WEB", c: security.Claims = Depends(claims)):
    require_customer(c)
    if x_channel not in ("WEB", "ANDROID", "IOS"):
        raise Problem("DENIED_PRODUCT", "Telegram entries use the Mini App endpoint.")
    with tx(c.entity) as cur:
        r = call(cur, "accept_entry", str(competition_id), c.sub, body.selection, idempotency_key, x_channel, _s(body.payment_intent_id))
    if not r["ok"]:
        raise Problem(r["code"])
    return JSONResponse(status_code=200 if r["replay"] else 201, content={**r, "accepted_at": str(r["accepted_at"])})


@app.get("/v1/me/entries")
def my_entries(c: security.Claims = Depends(claims)):
    require_customer(c)
    with tx(c.entity) as cur:
        cur.execute("SELECT e.id, e.competition_id, c.title, e.seq, e.selection, e.receipt_hash, e.prev_receipt_hash, e.rule_hash, "
                    "e.accepted_at, e.channel FROM veriq.entries e JOIN veriq.competitions c ON c.id=e.competition_id "
                    "WHERE e.customer_id=%s ORDER BY e.accepted_at DESC LIMIT 100", (c.sub,))
        return [{k: str(v) for k, v in r.items()} for r in cur.fetchall()]


@app.get("/v1/entries/{entry_id}/receipt")
def receipt(entry_id: uuid.UUID, c: security.Claims = Depends(claims)):
    with tx(c.entity) as cur:
        cur.execute("SELECT id, competition_id, seq, selection, rule_hash, accepted_at, receipt_hash, prev_receipt_hash "
                    "FROM veriq.entries WHERE id=%s AND (customer_id::text=%s OR %s)",
                    (str(entry_id), c.sub, c.kind == "staff" and bool({"SUPPORT", "COMP_OPS", "AUDITOR", "FRAUD"} & set(c.roles))))
        row = cur.fetchone()
    if not row:  # same answer for "absent" and "not yours": no BOLA oracle
        raise Problem("NOT_FOUND")
    return {k: str(v) for k, v in row.items()}


@app.get("/v1/competitions/{competition_id}/manifest")
def manifest(competition_id: uuid.UUID, c: security.Claims = Depends(claims)):
    with tx(c.entity) as cur:
        cur.execute("SELECT manifest, manifest_digest, signature, key_id, outcome, winning_number, verifier_attestation "
                    "FROM veriq.result_runs WHERE competition_id=%s AND published_at IS NOT NULL", (str(competition_id),))
        row = cur.fetchone()
        if not row:
            raise Problem("NOT_FOUND")
        cur.execute("SELECT r.tsa_name, r.gen_time, r.serial_number, encode(r.token_der,'base64') AS token_der_b64 FROM veriq.witness_receipts r "
                    "JOIN veriq.witness_roots w ON w.id=r.witness_root_id WHERE w.competition_id=%s", (str(competition_id),))
        row["witness_receipts"] = [{**w, "gen_time": w["gen_time"].isoformat()} for w in cur.fetchall()]
    row["public_key_der_b64"] = base64.b64encode(keyring_for(c.entity).public_key_der()).decode()
    return row


# ---------------- claims (customer) ----------------
@app.post("/v1/competitions/{competition_id}/claim")
def open_claim(competition_id: uuid.UUID, c: security.Claims = Depends(claims)):
    require_customer(c)
    with tx(c.entity) as cur:
        r = call(cur, "open_claim", str(competition_id), c.sub)
    if not r["ok"]:
        raise Problem(r["code"])
    return {"claim_id": r["claim_id"], "next": "Identity review, then delivery. VERIQ never asks for payment to release a prize."}


@app.put("/v1/claims/{claim_id}/address")
def claim_address(claim_id: uuid.UUID, body: Address, c: security.Claims = Depends(claims)):
    require_customer(c)
    ct, wdek, _ = pii.encrypt(keyring_for(c.entity), c.entity, f"claim:{claim_id}", body.model_dump())
    blob = len(wdek).to_bytes(2, "big") + wdek + ct
    with tx(c.entity) as cur:
        cur.execute("UPDATE veriq.claims SET delivery_address_ciphertext=%s WHERE id=%s AND customer_id=%s "
                    "AND state IN ('OPENED','APPROVED','ALLOCATED') RETURNING id", (blob, str(claim_id), c.sub))
        if not cur.fetchone():
            raise Problem("NOT_FOUND")
    return {"saved": True}


@app.get("/v1/me/claims")
def my_claims(c: security.Claims = Depends(claims)):
    require_customer(c)
    with tx(c.entity) as cur:
        cur.execute("SELECT cl.id, cl.state, cl.deadline, c.title, d.carrier, d.tracking_ref, d.delivered_at FROM veriq.claims cl "
                    "JOIN veriq.competitions c ON c.id=cl.competition_id LEFT JOIN veriq.deliveries d ON d.claim_id=cl.id "
                    "WHERE cl.customer_id=%s", (c.sub,))
        return [{k: _s(v) for k, v in r.items()} for r in cur.fetchall()]


# ---------------- staff: competition, claims, fulfillment ----------------
@app.post("/v1/staff/competitions/{competition_id}/close")
def close(competition_id: uuid.UUID, c: security.Claims = Depends(claims)):
    require_staff(c, "COMP_OPS")
    with tx(c.entity, c.sub) as cur:
        r = call(cur, "close_competition", str(competition_id))
    if not r["ok"]:
        raise Problem(r["code"])
    return r


@app.post("/v1/staff/competitions/{competition_id}/result")
def result(competition_id: uuid.UUID, c: security.Claims = Depends(claims)):
    require_staff(c, "COMP_OPS")
    with tx(c.entity, c.sub) as cur:
        r = fairness.compute_and_publish(cur, str(competition_id), fairness.Signer(entity=c.entity))
    if r["publish"] != "OK":
        raise Problem(r["publish"] if r["publish"] in PROBLEM_STATUS else "VERIFICATION_MISMATCH")
    return {"outcome": r["outcome"], "winning_number": r["winning_number"], "manifest_digest": r["manifest_digest"],
            "attestation": r["attestation"], "publish": r["publish"]}


@app.post("/v1/staff/competitions/{competition_id}/prize-items")
def add_prize(competition_id: uuid.UUID, body: PrizeItem, c: security.Claims = Depends(claims)):
    require_staff(c, "INVENTORY")
    with tx(c.entity, c.sub) as cur:
        return {"prize_item_id": str(call(cur, "receive_prize_item", str(competition_id), body.model, body.serial,
                                          body.warranty_months, body.valuation_minor, body.evidence_sha256))}


@app.get("/v1/staff/claims")
def claims_queue(c: security.Claims = Depends(claims)):
    require_staff(c, "COMPLIANCE", "INVENTORY", "FULFILLMENT", "SUPPORT")
    with tx(c.entity, c.sub) as cur:
        cur.execute("SELECT cl.id, cl.competition_id, cl.state, cl.opened_at, cl.deadline, c.title, cl.prize_item_id, p.serial, p.model, "
                    "d.carrier, d.tracking_ref, d.dispatched_by, d.delivered_at FROM veriq.claims cl "
                    "JOIN veriq.competitions c ON c.id=cl.competition_id LEFT JOIN veriq.prize_items p ON p.id=cl.prize_item_id "
                    "LEFT JOIN veriq.deliveries d ON d.claim_id=cl.id ORDER BY cl.opened_at")
        return [{k: _s(v) for k, v in r.items()} for r in cur.fetchall()]


def _staff_cmd(c, role, fn, *args):
    require_staff(c, role)
    with tx(c.entity, c.sub) as cur:
        r = call(cur, fn, *args)
    if r != "OK":
        raise Problem(r)
    return {"result": "OK"}


@app.post("/v1/staff/claims/{claim_id}/review")
def review(claim_id: uuid.UUID, body: Review, c: security.Claims = Depends(claims)):
    return _staff_cmd(c, "COMPLIANCE", "review_claim", str(claim_id), body.approve, body.note)


@app.post("/v1/staff/claims/{claim_id}/allocate")
def allocate(claim_id: uuid.UUID, body: Allocate, c: security.Claims = Depends(claims)):
    return _staff_cmd(c, "INVENTORY", "allocate_prize", str(claim_id), str(body.prize_item_id))


@app.post("/v1/staff/claims/{claim_id}/dispatch")
def dispatch(claim_id: uuid.UUID, body: Dispatch, c: security.Claims = Depends(claims)):
    return _staff_cmd(c, "FULFILLMENT", "dispatch_prize", str(claim_id), body.carrier, body.tracking_ref)


@app.post("/v1/staff/claims/{claim_id}/delivered")
def delivered(claim_id: uuid.UUID, body: Delivered, c: security.Claims = Depends(claims)):
    return _staff_cmd(c, "FULFILLMENT", "confirm_delivery", str(claim_id), body.scanned_serial,
                      body.recipient_signature_sha256, body.handover_photo_sha256)


@app.get("/v1/staff/claims/{claim_id}/address")
def claim_address_read(claim_id: uuid.UUID, c: security.Claims = Depends(claims)):
    require_staff(c, "FULFILLMENT")
    with tx(c.entity, c.sub) as cur:
        cur.execute("SELECT delivery_address_ciphertext FROM veriq.claims WHERE id=%s AND state IN ('ALLOCATED','DISPATCHED')", (str(claim_id),))
        row = cur.fetchone()
        if not row or not row["delivery_address_ciphertext"]:
            raise Problem("NOT_FOUND")
        call(cur, "audit_pii_read", str(claim_id), "delivery_address")   # every decrypted read is audited
    blob = bytes(row["delivery_address_ciphertext"]); n = int.from_bytes(blob[:2], "big")
    return pii.decrypt(keyring_for(c.entity), c.entity, f"claim:{claim_id}", blob[2 + n:], blob[2:2 + n])


# ---------------- sponsor portal ----------------
@app.get("/v1/sponsor/competitions")
def sponsor_list(c: security.Claims = Depends(claims)):
    require_staff(c, "SPONSOR")
    with tx(c.entity, c.sub) as cur:
        cur.execute("SELECT cp.id, cp.title, cp.state, cp.closes_at FROM veriq.competitions cp JOIN veriq.sponsor_members m "
                    "ON m.sponsor_id=cp.sponsor_id WHERE m.staff_id=%s ORDER BY cp.closes_at DESC", (c.sub,))
        return [{k: str(v) for k, v in r.items()} for r in cur.fetchall()]


@app.get("/v1/sponsor/competitions/{competition_id}/report")
def sponsor_report(competition_id: uuid.UUID, c: security.Claims = Depends(claims)):
    require_staff(c, "SPONSOR")
    with tx(c.entity, c.sub) as cur:
        r = call(cur, "sponsor_report", str(competition_id))
    if not r["ok"]:
        raise Problem(r["code"])
    return r


# ---------------- payments ----------------
@app.post("/v1/webhooks/payments/{provider}")
async def payment_webhook(request: Request, provider: str, x_signature: Annotated[str, Header()],
                          x_timestamp: Annotated[str, Header()], x_entity: Annotated[str, Header()]):
    raw = await request.body()
    secret = os.environ.get(f"VERIQ_PROVIDER_SECRET_{provider.upper()}", "").encode()
    if not secret:
        raise Problem("PROVIDER_SUSPENDED")
    try:
        event = payments.verify_webhook(raw, x_signature, x_timestamp, secret)
    except payments.WebhookRejected as e:
        raise Problem("WEBHOOK_REJECTED", str(e))
    with tx(x_entity) as cur:  # entity routing header trusted only after the signature check
        return payments.apply(cur, provider, event, raw)


# ---------------- Telegram ----------------
_BOTS: dict = {}


def bot_for(entity: str, bot=None):
    if bot is not None:
        from ..telegram_bot import build_dispatcher
        _BOTS[entity] = (bot, build_dispatcher(entity))
    if entity not in _BOTS:
        from aiogram import Bot
        from aiogram.client.default import DefaultBotProperties
        from ..telegram_bot import build_dispatcher
        _BOTS[entity] = (Bot(os.environ["VERIQ_TELEGRAM_BOT_TOKEN"], default=DefaultBotProperties(parse_mode="HTML")),
                         build_dispatcher(entity))
    return _BOTS[entity]


@app.post("/v1/telegram/webhook/{entity}")
async def telegram_webhook(request: Request, entity: uuid.UUID):
    expected = os.environ.get("VERIQ_TELEGRAM_WEBHOOK_SECRET", "")
    sent = request.headers.get("x-telegram-bot-api-secret-token", "")
    if not expected or not sent or not hmac.compare_digest(expected, sent):
        raise Problem("UNAUTHENTICATED", "bad webhook secret", status=401)
    from aiogram.types import Update
    update = Update.model_validate(await request.json())
    with tx(str(entity)) as cur:
        if call(cur, "telegram_seen", update.update_id):
            return {"ok": True, "duplicate": True}
    bot, dp = bot_for(str(entity))
    await dp.feed_update(bot, update)
    return {"ok": True}


@app.post("/v1/telegram/miniapp/entry", status_code=201)
def miniapp_entry(body: MiniAppEntry, x_entity: Annotated[str, Header()]):
    try:
        tg = telegram.validate_init_data(body.init_data, os.environ.get("VERIQ_TELEGRAM_BOT_TOKEN", ""))
    except telegram.TelegramAuthError as e:
        raise Problem("TELEGRAM_AUTH_FAILED", str(e))
    with tx(x_entity) as cur:
        cur.execute("SELECT customer_id FROM veriq.channel_links WHERE channel='TELEGRAM' AND external_principal=%s AND unlinked_at IS NULL",
                    (tg["telegram_user_id"],))
        row = cur.fetchone()
        if not row:
            raise Problem("TELEGRAM_NOT_LINKED", "Link your VERIQ account first: /link in the bot.")
        r = call(cur, "accept_entry", str(body.competition_id), str(row["customer_id"]), body.selection, body.idempotency_key, "TELEGRAM", None)
    if not r["ok"]:
        raise Problem(r["code"])
    return JSONResponse(status_code=200 if r["replay"] else 201, content={**r, "accepted_at": str(r["accepted_at"])})



# ======================================================================================================
# Chapa payments
# ======================================================================================================
from ..modules import chapa as chapa_mod   # noqa: E402

_CHAPA_CLIENT = None


def chapa_client() -> chapa_mod.ChapaClient:
    global _CHAPA_CLIENT
    if _CHAPA_CLIENT is None:
        try:
            _CHAPA_CLIENT = chapa_mod.ChapaClient(chapa_mod.ChapaConfig.from_env())
        except chapa_mod.ChapaError as e:
            raise Problem("PROVIDER_SUSPENDED", e.code)
    return _CHAPA_CLIENT


def _checkout(c: security.Claims, purpose: str, *, competition=None, invoice=None, channel="WEB",
              first="VERIQ", last="Customer", phone=None):
    tx_ref = chapa_mod.new_tx_ref()
    with tx(c.entity, c.sub if c.kind == "staff" else None) as cur:
        r = call(cur, "create_payment_intent", purpose, "chapa", tx_ref, c.sub if purpose == "ENTRY_FEE" else None,
                 competition, invoice, channel)
    if not r["ok"]:
        raise Problem(r["code"])
    client = chapa_client()
    try:
        url = client.initialize(tx_ref, r["amount_minor"], r["currency"], c.entity, first, last, phone, None, "VERIQ", r["title"])
    except chapa_mod.ChapaError as e:
        raise Problem("PROVIDER_UNAVAILABLE", e.code, status=503)   # intent stays INITIATED; reconciler expires it
    with tx(c.entity) as cur:
        call(cur, "set_checkout", r["intent_id"], url)
    return {"intent_id": str(r["intent_id"]), "tx_ref": tx_ref, "checkout_url": url, "amount_minor": r["amount_minor"],
            "currency": r["currency"], "note": "Payment is confirmed only after VERIQ verifies it with Chapa."}


class PaidEntryCheckout(BaseModel):
    competition_id: uuid.UUID
    channel: str = Field(default="WEB", pattern="^(WEB|ANDROID|IOS)$")


@app.post("/v1/payments/chapa/entry")
def chapa_entry_checkout(body: PaidEntryCheckout, c: security.Claims = Depends(claims)):
    require_customer(c)
    with tx(c.entity) as cur:
        cur.execute("SELECT pii_ciphertext, pii_wrapped_dek FROM veriq.customers WHERE id=%s", (c.sub,))
        row = cur.fetchone()
    p = pii.decrypt(keyring_for(c.entity), c.entity, c.sub, bytes(row["pii_ciphertext"]), bytes(row["pii_wrapped_dek"])) if row and row["pii_ciphertext"] else {}
    name = (p.get("full_name") or "VERIQ Customer").split()
    return _checkout(c, "ENTRY_FEE", competition=str(body.competition_id), channel=body.channel,
                     first=name[0], last=" ".join(name[1:]) or "-", phone=p.get("phone"))


@app.get("/v1/payments/{intent_id}")
def payment_status(intent_id: uuid.UUID, c: security.Claims = Depends(claims)):
    with tx(c.entity, c.sub if c.kind == "staff" else None) as cur:
        cur.execute("SELECT p.id, p.state, p.purpose, p.amount_minor, p.currency, p.merchant_ref, p.verified_at FROM veriq.payment_intents p "
                    "LEFT JOIN veriq.sponsor_invoices i ON i.id=p.sponsor_invoice_id LEFT JOIN veriq.sponsor_members m ON m.sponsor_id=i.sponsor_id "
                    "WHERE p.id=%s AND (p.customer_id::text=%s OR m.staff_id::text=%s OR %s)",
                    (str(intent_id), c.sub, c.sub, c.kind == "staff" and bool({"FINANCE", "CFO", "SUPPORT"} & set(c.roles))))
        row = cur.fetchone()
    if not row:
        raise Problem("NOT_FOUND")
    return {k: _s(v) if k not in ("amount_minor",) else v for k, v in row.items()}


@app.get("/v1/payments/chapa/callback/{entity}")
def chapa_callback(entity: uuid.UUID, trx_ref: str | None = None, tx_ref: str | None = None, status: str | None = None):
    """Browser/server callback after checkout. The `status` parameter is ignored: we always verify with Chapa."""
    ref = trx_ref or tx_ref
    if not ref or not ref.startswith("VQ-") or len(ref) > 40:
        raise Problem("INVALID_INPUT")
    try:
        with tx(str(entity)) as cur:
            r = chapa_mod.apply_from_verify(cur, chapa_client(), ref)
    except chapa_mod.ChapaError as e:
        raise Problem("PROVIDER_UNAVAILABLE", e.code, status=503)
    return {"tx_ref": ref, "state": r.get("state"), "disposition": r["disposition"]}


@app.post("/v1/webhooks/chapa/{entity}")
async def chapa_webhook(request: Request, entity: uuid.UUID):
    raw = await request.body()
    client = chapa_client()
    if not chapa_mod.verify_webhook_signature(raw, {k.lower(): v for k, v in request.headers.items()}, client.cfg.webhook_secret):
        raise Problem("WEBHOOK_REJECTED", "signature", status=401)
    event = __import__("json").loads(raw)
    try:
        with tx(str(entity)) as cur:
            if str(event.get("type", "")).lower() == "payout" or str(event.get("event", "")).startswith("payout"):
                return {"ok": True, "ignored": "payout"}
            if "refund" in str(event.get("event", "")).lower():
                return {"ok": True, **chapa_mod.reconcile_refunds(cur, client)}
            ref = event.get("tx_ref")
            if not ref:
                return {"ok": True, "ignored": "no tx_ref"}
            r = chapa_mod.apply_from_verify(cur, client, ref)
    except chapa_mod.ChapaError as e:
        # Non-200 makes Chapa retry (every 10 min, up to 72 h) — correct when we could not verify.
        raise Problem("PROVIDER_UNAVAILABLE", e.code, status=503)
    return {"ok": True, "disposition": r["disposition"]}


# ---------------- sponsor invoices ----------------
class InvoiceIn(BaseModel):
    sponsor_id: uuid.UUID
    number: str = Field(min_length=3, max_length=40, pattern=r"^[A-Za-z0-9-_/]+$")
    description: str = Field(min_length=3, max_length=200)
    amount_minor: int = Field(gt=0, le=10_000_000_000)
    currency: str = Field(default="ETB", pattern="^[A-Z]{3}$")


@app.post("/v1/staff/sponsor-invoices", status_code=201)
def issue_invoice(body: InvoiceIn, c: security.Claims = Depends(claims)):
    require_staff(c, "FINANCE")
    with tx(c.entity, c.sub) as cur:
        return {"invoice_id": str(call(cur, "issue_sponsor_invoice", str(body.sponsor_id), body.number, body.description,
                                       body.amount_minor, body.currency))}


@app.get("/v1/sponsor/invoices")
def my_invoices(c: security.Claims = Depends(claims)):
    require_staff(c, "SPONSOR")
    with tx(c.entity, c.sub) as cur:
        cur.execute("SELECT i.id, i.number, i.description, i.amount_minor, i.currency, i.state, i.issued_at, i.paid_at FROM veriq.sponsor_invoices i "
                    "JOIN veriq.sponsor_members m ON m.sponsor_id=i.sponsor_id WHERE m.staff_id=%s ORDER BY i.issued_at DESC", (c.sub,))
        return [{k: (v if k == "amount_minor" else _s(v)) for k, v in r.items()} for r in cur.fetchall()]


@app.post("/v1/sponsor/invoices/{invoice_id}/pay")
def pay_invoice(invoice_id: uuid.UUID, c: security.Claims = Depends(claims)):
    """Never discard an open checkout blindly: the sponsor may already have paid on it. Verify it with Chapa first;
    if paid, apply it; if still pending and recent, return the same checkout; only then start a new one."""
    require_staff(c, "SPONSOR")
    with tx(c.entity, c.sub) as cur:
        cur.execute("SELECT p.id, p.merchant_ref, p.checkout_url, p.state, p.amount_minor, p.currency, p.created_at > now() - interval '30 minutes' AS fresh "
                    "FROM veriq.payment_intents p JOIN veriq.sponsor_invoices i ON i.id=p.sponsor_invoice_id "
                    "JOIN veriq.sponsor_members m ON m.sponsor_id=i.sponsor_id AND m.staff_id=%s "
                    "WHERE p.sponsor_invoice_id=%s AND p.state IN ('INITIATED','PENDING')", (c.sub, str(invoice_id)))
        open_intent = cur.fetchone()
    if open_intent:
        try:
            with tx(c.entity) as cur:
                r = chapa_mod.apply_from_verify(cur, chapa_client(), open_intent["merchant_ref"])
        except chapa_mod.ChapaError as e:
            if e.code != "CHAPA_NOT_FOUND":   # only a definite "never reached Chapa" lets us replace the checkout
                raise Problem("PROVIDER_UNAVAILABLE", e.code, status=503)
            r = {"state": open_intent["state"], "disposition": "NOT_AT_PROVIDER"}
        if r.get("state") == "CONFIRMED" or r.get("disposition") == "ALREADY_CONFIRMED":
            raise Problem("INVOICE_NOT_PAYABLE", "This invoice has just been paid.", status=409)
        if r.get("disposition") == "STILL_PENDING" and open_intent["fresh"] and open_intent["checkout_url"]:
            return {"intent_id": str(open_intent["id"]), "tx_ref": open_intent["merchant_ref"], "checkout_url": open_intent["checkout_url"],
                    "amount_minor": open_intent["amount_minor"], "currency": open_intent["currency"], "reused": True,
                    "note": "Payment is confirmed only after VERIQ verifies it with Chapa."}
    return _checkout(c, "SPONSOR_INVOICE", invoice=str(invoice_id), first="Sponsor", last="Accounts")


# ---------------- refunds (FINANCE requests, a different CFO approves) ----------------
class RefundIn(BaseModel):
    amount_minor: int = Field(gt=0)
    reason: str = Field(min_length=3, max_length=200)


@app.post("/v1/staff/payments/{intent_id}/refunds", status_code=201)
def request_refund(intent_id: uuid.UUID, body: RefundIn, c: security.Claims = Depends(claims)):
    require_staff(c, "FINANCE")
    with tx(c.entity, c.sub) as cur:
        return {"refund_id": str(call(cur, "request_refund", str(intent_id), body.amount_minor, body.reason)), "state": "REQUESTED"}


@app.post("/v1/staff/refunds/{refund_id}/approve")
def approve_refund(refund_id: uuid.UUID, c: security.Claims = Depends(claims)):
    require_staff(c, "CFO")
    with tx(c.entity, c.sub) as cur:
        a = call(cur, "approve_refund", str(refund_id))
    if not a["ok"]:
        raise Problem(a["code"])
    try:
        with tx(c.entity, c.sub) as cur:
            ref = chapa_mod.submit_refund(cur, chapa_client(), str(refund_id), a)
    except chapa_mod.ChapaError as e:   # approved but not submitted: visible in the queue, resubmittable
        raise Problem("PROVIDER_UNAVAILABLE", e.code, status=503)
    return {"refund_id": str(refund_id), "state": "SUBMITTED", "provider_ref_id": ref}


@app.post("/v1/staff/payments/reconcile")
def reconcile(c: security.Claims = Depends(claims)):
    require_staff(c, "FINANCE", "CFO")
    with tx(c.entity, c.sub) as cur:
        return {"payments": chapa_mod.reconcile_pending(cur, chapa_client()), "refunds": chapa_mod.reconcile_refunds(cur, chapa_client())}


# ======================================================================================================
# Admin commands (audit: these existed only as database functions)
# ======================================================================================================
class AuthorizationIn(BaseModel):
    country: str = Field(pattern="^[A-Z]{2}$")
    product: str = Field(pattern="^(SPONSOR_FREE|PAID_COMPETITION)$")
    channel: str = Field(pattern="^(WEB|ANDROID|IOS|TELEGRAM)$")
    license_scope: str | None = Field(default=None, max_length=200)


class EvidenceIn(BaseModel):
    kind: str
    sha256: str = Field(pattern="^[0-9a-f]{64}$")
    storage_uri: str = Field(max_length=500)
    expires_at: str | None = None


class ApprovalIn(BaseModel):
    role: str = Field(pattern="^(COMPLIANCE|CFO|DEPLOYMENT)$")
    target_state: str = Field(pattern="^(LIMITED_PILOT|LIVE)$")


class TransitionIn(BaseModel):
    to: str
    effective_from: str | None = None
    effective_to: str | None = None


class RuleIn(BaseModel):
    body: dict


class CompetitionIn(BaseModel):
    country: str = Field(pattern="^[A-Z]{2}$")
    product: str = Field(pattern="^(SPONSOR_FREE|PAID_COMPETITION)$")
    title: str = Field(min_length=3, max_length=120)
    rule_version_id: uuid.UUID
    opens_at: str
    closes_at: str
    entry_fee_minor: int = Field(ge=0)
    currency: str = Field(default="ETB", pattern="^[A-Z]{3}$")
    number_min: int
    number_max: int
    per_customer_cap: int = Field(ge=1, le=1000)
    prize_obligation_minor: int = Field(ge=0)


class SecurePrizeIn(BaseModel):
    reserve_minor: int = Field(ge=0)
    evidence_sha256: str = Field(pattern="^[0-9a-f]{64}$")


class IdentityIn(BaseModel):
    age_verified: bool
    kyc_state: str = Field(pattern="^(PENDING|VERIFIED|REJECTED)$")


class StaffIn(BaseModel):
    display_name: str = Field(min_length=2, max_length=120)
    roles: list[str]
    sponsor_id: uuid.UUID | None = None


class ProviderIn(BaseModel):
    state: str = Field(pattern="^(ACTIVE|SUSPENDED)$")
    gaming_model_accepted: bool = False
    evidence_sha256: str | None = Field(default=None, pattern="^[0-9a-f]{64}$")


class ReasonIn(BaseModel):
    reason: str = Field(min_length=3, max_length=200)


class NameIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)


class SponsorAssignIn(BaseModel):
    sponsor_id: uuid.UUID


def _cmd(c, roles: tuple[str, ...], fn: str, *args):
    require_staff(c, *roles)
    with tx(c.entity, c.sub) as cur:
        r = call(cur, fn, *args)
    if isinstance(r, str) and r != "OK" and not _is_uuid(r):
        raise Problem(r.split(":")[0], r)
    if isinstance(r, dict) and r.get("ok") is False:
        raise Problem(r["code"])
    return {"result": _s(r) if not isinstance(r, dict) else r}


def _is_uuid(v) -> bool:
    try:
        uuid.UUID(str(v)); return True
    except ValueError:
        return False


@app.post("/v1/staff/authorizations", status_code=201)
def create_authorization(body: AuthorizationIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMPLIANCE",), "create_authorization", body.country, body.product, body.channel, body.license_scope)


@app.post("/v1/staff/authorizations/{auth_id}/evidence", status_code=201)
def add_evidence(auth_id: uuid.UUID, body: EvidenceIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMPLIANCE",), "record_evidence", str(auth_id), body.kind, body.sha256, body.storage_uri, body.expires_at)


@app.post("/v1/staff/authorizations/{auth_id}/approvals", status_code=201)
def approve_authorization(auth_id: uuid.UUID, body: ApprovalIn, c: security.Claims = Depends(claims)):
    return _cmd(c, (body.role,), "approve_authorization", str(auth_id), body.role, body.target_state)


@app.post("/v1/staff/authorizations/{auth_id}/transition")
def transition_authorization(auth_id: uuid.UUID, body: TransitionIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMPLIANCE", "DEPLOYMENT"), "transition_authorization", str(auth_id), body.to, body.effective_from, body.effective_to)


@app.post("/v1/staff/rules", status_code=201)
def draft_rule(body: RuleIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMP_OPS",), "draft_rule", __import__("json").dumps(body.body))


@app.post("/v1/staff/rules/{rule_id}/approve")
def approve_rule(rule_id: uuid.UUID, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMPLIANCE",), "approve_rule", str(rule_id))


@app.post("/v1/staff/competitions", status_code=201)
def create_competition(body: CompetitionIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMP_OPS",), "create_competition", body.country, body.product, body.title, str(body.rule_version_id),
                body.opens_at, body.closes_at, body.entry_fee_minor, body.currency, body.number_min, body.number_max,
                body.per_customer_cap, body.prize_obligation_minor)


@app.post("/v1/staff/competitions/{competition_id}/sponsor")
def assign_sponsor(competition_id: uuid.UUID, body: SponsorAssignIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMP_OPS",), "assign_sponsor", str(competition_id), str(body.sponsor_id))


@app.post("/v1/staff/competitions/{competition_id}/secure-prize")
def secure_prize(competition_id: uuid.UUID, body: SecurePrizeIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("CFO",), "secure_prize", str(competition_id), body.reserve_minor, body.evidence_sha256)


@app.post("/v1/staff/competitions/{competition_id}/open")
def open_competition(competition_id: uuid.UUID, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMP_OPS",), "open_competition", str(competition_id))


@app.post("/v1/staff/customers/{customer_id}/identity")
def verify_identity(customer_id: uuid.UUID, body: IdentityIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMPLIANCE",), "verify_customer_identity", str(customer_id), body.age_verified, body.kyc_state)


@app.post("/v1/staff/journals/{journal_id}/reverse")
def reverse_journal(journal_id: uuid.UUID, body: ReasonIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("CFO",), "reverse_journal", str(journal_id), body.reason)


@app.post("/v1/staff/accounts/bootstrap")
def bootstrap_accounts(c: security.Claims = Depends(claims)):
    return _cmd(c, ("CFO",), "bootstrap_chart_of_accounts", "ETB")


@app.post("/v1/staff/sponsors", status_code=201)
def create_sponsor(body: NameIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("COMP_OPS",), "create_sponsor", body.name)


@app.post("/v1/staff/staff", status_code=201)
def propose_staff(body: StaffIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("INFRA_ADMIN",), "propose_staff", body.display_name, body.roles, _s(body.sponsor_id))


@app.post("/v1/staff/staff/{staff_id}/activate")
def activate_staff(staff_id: uuid.UUID, c: security.Claims = Depends(claims)):
    return _cmd(c, ("CEO",), "activate_staff", str(staff_id))


@app.post("/v1/staff/staff/{staff_id}/deactivate")
def deactivate_staff(staff_id: uuid.UUID, c: security.Claims = Depends(claims)):
    return _cmd(c, ("CEO", "INFRA_ADMIN"), "deactivate_staff", str(staff_id))


@app.post("/v1/staff/providers/{code}")
def set_provider(code: str, body: ProviderIn, c: security.Claims = Depends(claims)):
    return _cmd(c, ("CFO",), "set_provider_state", code, body.state, body.gaming_model_accepted, body.evidence_sha256)
