"""Key management. Production: PKCS#11 HSM (Thales/Utimaco/YubiHSM, or cloud HSM via its PKCS#11 library).
Keys are generated inside the HSM at a witnessed ceremony (scripts/ops/hsm_ceremony.py), are SENSITIVE and
NON-EXTRACTABLE, and private material never enters this process. Tested here against SoftHSM2 (same PKCS#11 API).

Three keys per legal entity:
  sign  — ECDSA P-256: result manifests, signed receipts/exports
  kek   — AES-256-GCM: wraps per-record data keys (envelope encryption of PII)
  bidx  — HMAC-SHA256: blind indexes for exact-match lookup of encrypted fields (e.g. phone)
"""
from __future__ import annotations
import hashlib, os, threading
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, utils


class KeyringError(Exception):
    pass


class HsmKeyring:
    ALG = "ECDSA_P256_SHA256"

    def __init__(self, lib_path: str, token_label: str, pin: str, prefix: str):
        import pkcs11
        self._p = pkcs11
        self._lib = pkcs11.lib(lib_path)
        self._token = self._lib.get_token(token_label=token_label)
        self._pin = pin
        self.prefix = prefix
        self._lock = threading.Lock()
        self._pub_der: bytes | None = None

    @classmethod
    def from_env(cls, prefix: str) -> "HsmKeyring":
        try:
            return cls(os.environ["VERIQ_PKCS11_LIB"], os.environ["VERIQ_PKCS11_TOKEN"], os.environ["VERIQ_PKCS11_PIN"], prefix)
        except KeyError as e:
            raise KeyringError(f"MISSING_HSM_CONFIG:{e.args[0]}")

    def _session(self, rw=False):
        return self._token.open(user_pin=self._pin, rw=rw)

    def _get(self, s, cls_, label):
        try:
            return s.get_key(object_class=cls_, label=f"{self.prefix}.{label}")
        except (self._p.NoSuchKey, self._p.exceptions.NoSuchKey):
            raise KeyringError(f"KEY_NOT_PROVISIONED:{self.prefix}.{label}")

    # ---- ceremony (run once per entity, witnessed; never called by the API) ----
    def provision(self):
        from pkcs11 import Attribute, KeyType
        from pkcs11.util.ec import encode_named_curve_parameters
        priv_t = {Attribute.SENSITIVE: True, Attribute.EXTRACTABLE: False, Attribute.TOKEN: True}
        with self._session(rw=True) as s:
            dp = s.create_domain_parameters(KeyType.EC, {Attribute.EC_PARAMS: encode_named_curve_parameters("secp256r1")}, local=True)
            dp.generate_keypair(store=True, label=f"{self.prefix}.sign", private_template=priv_t)
            s.generate_key(KeyType.AES, 256, label=f"{self.prefix}.kek", store=True,
                           template={**priv_t, Attribute.ENCRYPT: True, Attribute.DECRYPT: True})
            s.generate_key(KeyType.GENERIC_SECRET, 256, label=f"{self.prefix}.bidx", store=True,
                           template={**priv_t, Attribute.SIGN: True})

    # ---- signing ----
    def sign(self, data: bytes) -> bytes:
        from pkcs11 import Mechanism, ObjectClass
        digest = hashlib.sha256(data).digest()
        with self._lock, self._session() as s:
            raw = self._get(s, ObjectClass.PRIVATE_KEY, "sign").sign(digest, mechanism=Mechanism.ECDSA)
        return utils.encode_dss_signature(int.from_bytes(raw[:32], "big"), int.from_bytes(raw[32:], "big"))

    def public_key_der(self) -> bytes:
        if self._pub_der is None:
            from pkcs11 import ObjectClass
            from pkcs11.util.ec import encode_ec_public_key
            with self._session() as s:
                self._pub_der = encode_ec_public_key(self._get(s, ObjectClass.PUBLIC_KEY, "sign"))
        return self._pub_der

    @property
    def key_id(self) -> str:
        return "p256:" + hashlib.sha256(self.public_key_der()).hexdigest()[:16]

    # ---- envelope encryption ----
    def wrap(self, dek: bytes, aad: bytes) -> bytes:
        from pkcs11 import GCMParams, Mechanism, ObjectClass
        nonce = os.urandom(12)
        with self._lock, self._session() as s:
            ct = self._get(s, ObjectClass.SECRET_KEY, "kek").encrypt(dek, mechanism=Mechanism.AES_GCM, mechanism_param=GCMParams(nonce, aad, 128))
        return b"\x01" + nonce + ct

    def unwrap(self, blob: bytes, aad: bytes) -> bytes:
        from pkcs11 import GCMParams, Mechanism, ObjectClass
        if blob[:1] != b"\x01":
            raise KeyringError("UNKNOWN_WRAP_VERSION")
        try:
            with self._lock, self._session() as s:
                return self._get(s, ObjectClass.SECRET_KEY, "kek").decrypt(blob[13:], mechanism=Mechanism.AES_GCM,
                                                                           mechanism_param=GCMParams(blob[1:13], aad, 128))
        except KeyringError:
            raise
        except Exception:
            raise KeyringError("UNWRAP_FAILED")

    def blind_index(self, value: str) -> str:
        from pkcs11 import Mechanism, ObjectClass
        with self._lock, self._session() as s:
            return self._get(s, ObjectClass.SECRET_KEY, "bidx").sign(value.encode(), mechanism=Mechanism.SHA256_HMAC).hex()


class DevKeyring:
    """Software keyring for local development ONLY. Refused when VERIQ_ENV=production."""
    ALG = "ECDSA_P256_SHA256"

    def __init__(self, prefix: str = "dev"):
        if os.environ.get("VERIQ_ENV") == "production":
            raise KeyringError("DEV_KEYRING_FORBIDDEN_IN_PRODUCTION")
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        seed = os.environ.get("VERIQ_DEV_KEY_SEED", "")
        if seed:   # staging/check environments: deterministic per entity so data survives restarts
            if len(seed) < 32:
                raise KeyringError("DEV_KEY_SEED_TOO_SHORT")
            from cryptography.hazmat.primitives.kdf.hkdf import HKDF
            d = lambda label, n: HKDF(hashes.SHA256(), n, prefix.encode(), label.encode()).derive(seed.encode())
            n_order = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
            self._sk = ec.derive_private_key(int.from_bytes(d("sign", 48), "big") % (n_order - 1) + 1, ec.SECP256R1())
            self._kek = AESGCM(d("kek", 32)); self._bidx = d("bidx", 32)
        else:
            self._sk = ec.generate_private_key(ec.SECP256R1())
            self._kek = AESGCM(os.urandom(32)); self._bidx = os.urandom(32)
        self.prefix = prefix

    def sign(self, data: bytes) -> bytes:
        return self._sk.sign(data, ec.ECDSA(hashes.SHA256()))

    def public_key_der(self) -> bytes:
        return self._sk.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)

    @property
    def key_id(self) -> str:
        return "p256:" + hashlib.sha256(self.public_key_der()).hexdigest()[:16]

    def wrap(self, dek: bytes, aad: bytes) -> bytes:
        n = os.urandom(12); return b"\x01" + n + self._kek.encrypt(n, dek, aad)

    def unwrap(self, blob: bytes, aad: bytes) -> bytes:
        try:
            return self._kek.decrypt(blob[1:13], blob[13:], aad)
        except Exception:
            raise KeyringError("UNWRAP_FAILED")

    def blind_index(self, value: str) -> str:
        import hmac
        return hmac.new(self._bidx, value.encode(), hashlib.sha256).hexdigest()


_CACHE: dict[str, object] = {}
_CACHE_LOCK = threading.Lock()


def keyring_for(entity_id: str):
    """One keyring per legal entity, cached for the process (keys must be stable: blind indexes and
    decryption depend on it). HSM when VERIQ_PKCS11_LIB is configured; production refuses anything else."""
    with _CACHE_LOCK:
        if entity_id not in _CACHE:
            if os.environ.get("VERIQ_PKCS11_LIB"):
                _CACHE[entity_id] = HsmKeyring.from_env(prefix=f"veriq.{entity_id}")
            else:
                _CACHE[entity_id] = DevKeyring(prefix=f"dev.{entity_id}")
        return _CACHE[entity_id]
