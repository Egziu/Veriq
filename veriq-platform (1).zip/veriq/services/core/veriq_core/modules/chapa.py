"""Chapa payment gateway adapter (https://developer.chapa.co).

Trust model
- The ONLY source of truth for money is Chapa's verify API (GET /transaction/verify/{tx_ref}), called by us.
  Webhooks and browser callbacks are just *hints* that trigger a verify; their bodies never move money.
- Webhook authentication: `x-chapa-signature` = HMAC-SHA256(webhook secret, payload). We do NOT accept the
  `chapa-signature` header alone: per Chapa's docs it is an HMAC of the secret over itself — a constant value
  that does not bind the payload and can be replayed. Chapa's docs (JSON.stringify, compact) and its Python SDK
  (json.dumps, spaced) disagree on the signed bytes, so we accept a match on the raw body or either form,
  always with constant-time comparison.
- Chapa sends no timestamp, so replay is handled by idempotent application (unique event keys in the DB) and
  by re-verification.
- Test keys (CHASECK_TEST-...) are refused when VERIQ_ENV=production; a verify result whose `mode` differs from
  the key's mode is recorded as an EXCEPTION, never applied.
- Chapa charges are non-refundable: fees are posted to 5200-PAYMENT-FEES at confirmation and are not reversed.
- Gambling is on Chapa's high-risk list: paid entries additionally require the provider's recorded written
  acceptance (payment_providers.gaming_model_accepted, set only by CFO with evidence) and an open country gate.
"""
from __future__ import annotations
import hashlib, hmac, json, os, re, secrets
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from urllib.parse import urlparse

import httpx

from ..db import call

PROVIDER = "chapa"


class ChapaError(Exception):
    def __init__(self, code: str, detail: str = ""):
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code, self.detail = code, detail


@dataclass(frozen=True)
class ChapaConfig:
    secret_key: str
    webhook_secret: str
    base_url: str = "https://api.chapa.co/v1"
    callback_base: str = "https://api.veriq.et/v1/payments/chapa/callback"
    return_url: str = "https://app.veriq.et/payments/return"
    checkout_hosts: tuple[str, ...] = ("checkout.chapa.co",)
    timeout: float = 15.0

    @property
    def mode(self) -> str:
        return "test" if "_TEST-" in self.secret_key else "live"

    @classmethod
    def from_env(cls) -> "ChapaConfig":
        key, hook = os.environ.get("VERIQ_CHAPA_SECRET_KEY", ""), os.environ.get("VERIQ_CHAPA_WEBHOOK_SECRET", "")
        if not key or not hook:
            raise ChapaError("CHAPA_NOT_CONFIGURED")
        cfg = cls(secret_key=key, webhook_secret=hook,
                  base_url=os.environ.get("VERIQ_CHAPA_BASE_URL", cls.base_url),
                  callback_base=os.environ.get("VERIQ_CHAPA_CALLBACK_BASE", cls.callback_base),
                  return_url=os.environ.get("VERIQ_CHAPA_RETURN_URL", cls.return_url),
                  checkout_hosts=tuple(h for h in os.environ.get("VERIQ_CHAPA_CHECKOUT_HOSTS", "checkout.chapa.co").split(",") if h))
        if os.environ.get("VERIQ_ENV") == "production" and cfg.mode != "live":
            raise ChapaError("TEST_KEY_IN_PRODUCTION")
        if os.environ.get("VERIQ_ENV") == "production" and not cfg.base_url.startswith("https://api.chapa.co/"):
            raise ChapaError("NON_CHAPA_BASE_URL_IN_PRODUCTION")
        return cfg


# ---------------- money and references ----------------
def minor_to_amount(minor: int) -> str:
    if minor <= 0:
        raise ChapaError("INVALID_AMOUNT")
    return f"{minor // 100}.{minor % 100:02d}"


def amount_to_minor(value) -> int:
    try:
        d = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ChapaError("INVALID_AMOUNT", str(value))
    if d < 0 or d != d.quantize(Decimal("0.01")):
        raise ChapaError("INVALID_AMOUNT", str(value))
    return int(d * 100)


def new_tx_ref() -> str:
    return "VQ-" + secrets.token_hex(12).upper()   # Chapa tx_ref: letters, digits, -, _ ; unique per merchant


def _clean(text: str, limit: int) -> str:
    return re.sub(r"[^A-Za-z0-9 ._-]", "", text)[:limit].strip() or "VERIQ"


# ---------------- webhook authentication ----------------
def verify_webhook_signature(raw_body: bytes, headers: dict[str, str], secret: str) -> bool:
    sig = (headers.get("x-chapa-signature") or "").strip().lower()
    if not sig or not secret:
        return False
    candidates = [raw_body]
    try:
        obj = json.loads(raw_body)
        candidates += [json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode(),   # JS JSON.stringify
                       json.dumps(obj).encode()]                                              # Chapa Python SDK
    except ValueError:
        return False
    key = secret.encode()
    return any(hmac.compare_digest(hmac.new(key, c, hashlib.sha256).hexdigest(), sig) for c in candidates)


# ---------------- HTTP client ----------------
class ChapaClient:
    def __init__(self, cfg: ChapaConfig, http: httpx.Client | None = None):
        self.cfg = cfg
        self.http = http or httpx.Client(timeout=cfg.timeout)

    def _h(self) -> dict:
        return {"Authorization": f"Bearer {self.cfg.secret_key}", "Content-Type": "application/json", "Accept": "application/json"}

    def _req(self, method: str, path: str, body: dict | None = None, retry_get: bool = True) -> dict:
        url = f"{self.cfg.base_url}{path}"
        attempts = 2 if (method == "GET" and retry_get) else 1
        last = None
        for _ in range(attempts):
            try:
                r = self.http.request(method, url, headers=self._h(), json=body)
                break
            except httpx.HTTPError as e:   # never include the key in errors
                last = e
        else:
            raise ChapaError("CHAPA_UNREACHABLE", type(last).__name__)
        try:
            data = r.json()
        except ValueError:
            raise ChapaError("CHAPA_UNREACHABLE" if r.status_code >= 500 else "CHAPA_BAD_RESPONSE", f"HTTP {r.status_code}")
        if r.status_code >= 500 or r.status_code == 429:
            raise ChapaError("CHAPA_UNREACHABLE", f"HTTP {r.status_code}")   # unknown outcome — never treat as "not paid"
        if r.status_code == 404:
            raise ChapaError("CHAPA_NOT_FOUND", str(data.get("message"))[:200])
        if r.status_code >= 400 or data.get("status") != "success":
            raise ChapaError("CHAPA_REJECTED", str(data.get("message"))[:200])
        return data

    def initialize(self, tx_ref: str, amount_minor: int, currency: str, entity: str, first_name: str, last_name: str,
                   phone: str | None, email: str | None, title: str, description: str) -> str:
        body = {"amount": minor_to_amount(amount_minor), "currency": currency, "tx_ref": tx_ref,
                "first_name": _clean(first_name, 50), "last_name": _clean(last_name, 50),
                "callback_url": f"{self.cfg.callback_base}/{entity}", "return_url": f"{self.cfg.return_url}?tx_ref={tx_ref}",
                "customization": {"title": _clean(title, 16), "description": _clean(description, 50)}}
        if phone:
            body["phone_number"] = "0" + phone[-9:] if phone.startswith("+251") else phone
        if email:
            body["email"] = email
        data = self._req("POST", "/transaction/initialize", body)
        url = (data.get("data") or {}).get("checkout_url", "")
        host = urlparse(url).hostname or ""
        if urlparse(url).scheme != "https" or host not in self.cfg.checkout_hosts:
            raise ChapaError("UNEXPECTED_CHECKOUT_HOST", host)   # never send a customer to an unexpected host
        return url

    def verify(self, tx_ref: str) -> dict:
        data = self._req("GET", f"/transaction/verify/{tx_ref}").get("data") or {}
        if data.get("tx_ref") != tx_ref:
            raise ChapaError("VERIFY_REFERENCE_MISMATCH")
        return {"status": str(data.get("status", "")).lower(), "amount_minor": amount_to_minor(data.get("amount", "0")),
                "currency": data.get("currency"), "fee_minor": amount_to_minor(data.get("charge") or "0"),
                "mode": data.get("mode"), "reference": data.get("reference"), "raw": data}

    def refund(self, provider_reference: str, amount_minor: int, reason: str, merchant_reference: str) -> str:
        data = self._req("POST", f"/refund/{provider_reference}",
                         {"reason": _clean(reason, 120), "amount": minor_to_amount(amount_minor), "reference": merchant_reference})
        ref = (data.get("data") or {}).get("ref_id")
        if not ref:
            raise ChapaError("CHAPA_BAD_RESPONSE", "missing ref_id")
        return ref

    def verify_refund(self, ref_id: str) -> str:
        return str(((self._req("GET", f"/refund/{ref_id}/verify").get("data")) or {}).get("status", "")).lower()


# ---------------- application services ----------------
def apply_from_verify(cur, client: ChapaClient, tx_ref: str) -> dict:
    """Verify with Chapa, then let the database decide. Safe to call any number of times."""
    v = client.verify(tx_ref)
    raw_digest = hashlib.sha256(json.dumps(v["raw"], sort_keys=True).encode()).hexdigest()
    return call(cur, "apply_verified_payment", PROVIDER, f"verify:{tx_ref}:{v['status']}", tx_ref, v["status"], v["amount_minor"],
                v["currency"], v["fee_minor"], v["reference"], v["mode"], client.cfg.mode, raw_digest)


def reconcile_pending(cur, client: ChapaClient, older_than: timedelta = timedelta(minutes=2), limit: int = 200) -> dict:
    """Catches missed webhooks and abandoned checkouts. Run by the worker every few minutes."""
    cur.execute("SELECT merchant_ref FROM veriq.payment_intents WHERE provider=%s AND state IN ('INITIATED','PENDING') "
                "AND created_at < now() - %s ORDER BY created_at LIMIT %s", (PROVIDER, older_than, limit))
    out = {"checked": 0, "applied": 0, "errors": 0}
    for row in cur.fetchall():
        out["checked"] += 1
        try:
            out["applied"] += bool(apply_from_verify(cur, client, row["merchant_ref"])["applied"])
        except ChapaError:
            out["errors"] += 1
    return out


def submit_refund(cur, client: ChapaClient, refund_id: str, approval: dict) -> str:
    ref_id = client.refund(approval["provider_reference"], approval["amount_minor"], approval["reason"], approval["merchant_reference"])
    call(cur, "mark_refund_submitted", refund_id, ref_id)
    return ref_id


def reconcile_refunds(cur, client: ChapaClient) -> dict:
    cur.execute("SELECT provider_ref_id FROM veriq.payment_refunds WHERE state='SUBMITTED'")
    out = {"checked": 0, "settled": 0}
    for row in cur.fetchall():
        out["checked"] += 1
        r = call(cur, "settle_refund", row["provider_ref_id"], client.verify_refund(row["provider_ref_id"]))
        out["settled"] += r in ("REFUNDED", "REVERSED")
    return out
