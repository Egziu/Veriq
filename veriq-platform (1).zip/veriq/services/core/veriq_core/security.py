"""Token verification. DEVELOPMENT implementation: HMAC-SHA256 compact tokens.
Production replaces this with OIDC + passkeys (WebAuthn) for customers and phishing-resistant MFA for staff
(see docs/adr/0003-identity.md). The *interface* — verified claims in, never client-chosen context — stays."""
from __future__ import annotations
import base64, hashlib, hmac, json, os, time
from dataclasses import dataclass

_DEFAULT = "dev-only-not-a-secret-change-me"


def _key() -> bytes:
    k = os.environ.get("VERIQ_DEV_TOKEN_KEY", _DEFAULT)
    if k == _DEFAULT and os.environ.get("VERIQ_ALLOW_DEFAULT_DEV_KEY") != "1":
        raise PermissionError("DEV_TOKEN_KEY_NOT_SET")   # a public default key on a public URL = anyone mints tokens
    if k != _DEFAULT and len(k) < 32:
        raise PermissionError("DEV_TOKEN_KEY_TOO_SHORT")
    return k.encode()


@dataclass(frozen=True)
class Claims:
    sub: str
    entity: str
    kind: str          # "customer" | "staff"
    roles: tuple[str, ...]
    exp: int


def _b64(b: bytes) -> str: return base64.urlsafe_b64encode(b).rstrip(b"=").decode()
def _unb64(s: str) -> bytes: return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def issue(sub: str, entity: str, kind: str, roles=(), ttl: int = 900) -> str:
    body = _b64(json.dumps({"sub": sub, "entity": entity, "kind": kind, "roles": list(roles), "exp": int(time.time()) + ttl}).encode())
    return body + "." + _b64(hmac.new(_key(), body.encode(), hashlib.sha256).digest())


def verify(token: str) -> Claims:
    try:
        body, sig = token.split(".")
    except ValueError:
        raise PermissionError("MALFORMED_TOKEN")
    if not hmac.compare_digest(_unb64(sig), hmac.new(_key(), body.encode(), hashlib.sha256).digest()):
        raise PermissionError("BAD_SIGNATURE")
    c = json.loads(_unb64(body))
    if c["exp"] < time.time():
        raise PermissionError("TOKEN_EXPIRED")
    return Claims(c["sub"], c["entity"], c["kind"], tuple(c["roles"]), c["exp"])
