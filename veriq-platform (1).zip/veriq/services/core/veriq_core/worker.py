"""VERIQ background worker (audit: designed jobs had no runner).
Each cycle, per legal entity:
  1. Publish the transactional outbox (at-least-once; consumers dedupe on event_id), FOR UPDATE SKIP LOCKED so
     several workers can run safely.
  2. Expire claims past their deadline.
  3. Reconcile Chapa payments/refunds (catches missed webhooks and abandoned checkouts) when Chapa is configured.
  4. Report competitions past closes_at that are still OPEN (acceptance already refuses them; an operator must
     close and publish — closing is deliberately not automated without a named accountable actor).
Run: python -m veriq_core.worker  (loops every VERIQ_WORKER_INTERVAL seconds; --once for a single cycle)."""
from __future__ import annotations
import json, logging, os, sys, time
from typing import Callable
from .db import call, tx

log = logging.getLogger("veriq.worker")


def stdout_sink(event: dict) -> None:
    print(json.dumps(event, default=str), flush=True)


def entities() -> list[str]:
    import psycopg
    from .db import APP_DSN
    with psycopg.connect(APP_DSN) as c:
        return [str(r[0]) for r in c.execute("SELECT id FROM veriq.legal_entities")]


def publish_outbox(entity: str, sink: Callable[[dict], None], batch: int = 500) -> int:
    with tx(entity) as cur:
        cur.execute("SELECT id, event_id, aggregate_type, aggregate_id, event_type, payload, classification, occurred_at, country_code "
                    "FROM veriq.outbox WHERE published_at IS NULL ORDER BY id LIMIT %s FOR UPDATE SKIP LOCKED", (batch,))
        rows = cur.fetchall()
        for r in rows:
            sink({"event_id": str(r["event_id"]), "type": r["event_type"], "legal_entity_id": entity, "country_code": r["country_code"],
                  "aggregate": {"type": r["aggregate_type"], "id": str(r["aggregate_id"])}, "classification": r["classification"],
                  "occurred_at": r["occurred_at"].isoformat(), "payload": r["payload"], "schema_version": 1})
        if rows:
            cur.execute("UPDATE veriq.outbox SET published_at = now() WHERE id = ANY(%s)", ([r["id"] for r in rows],))
    return len(rows)


def cycle(sink: Callable[[dict], None] = stdout_sink, chapa_client=None) -> dict:
    report = {}
    for e in entities():
        r = {"published": publish_outbox(e, sink)}
        with tx(e) as cur:
            r["claims_expired"] = call(cur, "expire_claims")
            cur.execute("SELECT id, title, closes_at FROM veriq.competitions WHERE state='OPEN' AND closes_at < now()")
            r["overdue_close"] = [{"id": str(x["id"]), "title": x["title"]} for x in cur.fetchall()]
        if chapa_client is not None:
            from .modules import chapa
            with tx(e) as cur:
                r["chapa"] = {"payments": chapa.reconcile_pending(cur, chapa_client), "refunds": chapa.reconcile_refunds(cur, chapa_client)}
        report[e] = r
        if r["overdue_close"]:
            log.warning("competitions past close time still OPEN: %s", r["overdue_close"])
    return report


def main():
    logging.basicConfig(level=logging.INFO)
    client = None
    if os.environ.get("VERIQ_CHAPA_SECRET_KEY"):
        from .modules.chapa import ChapaClient, ChapaConfig
        client = ChapaClient(ChapaConfig.from_env())
    interval = int(os.environ.get("VERIQ_WORKER_INTERVAL", "60"))
    while True:
        rep = cycle(chapa_client=client)
        log.info("cycle: %s", json.dumps({k: {kk: vv for kk, vv in v.items() if kk != "overdue_close"} for k, v in rep.items()}))
        if "--once" in sys.argv:
            return
        time.sleep(interval)


if __name__ == "__main__":
    main()
