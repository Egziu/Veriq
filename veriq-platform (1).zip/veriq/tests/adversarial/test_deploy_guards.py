"""Railway/staging deployment guards."""
import importlib, os
import pytest
from fastapi.testclient import TestClient


def test_app_refuses_superuser_database_connection(monkeypatch):
    from veriq_core import db
    from veriq_core.api import app as api
    monkeypatch.setattr(db, "APP_DSN", db.APP_DSN.replace("user=veriq_app", "user=postgres"))
    r = TestClient(api.app).get("/ready")
    assert r.status_code == 503 and r.json()["reason"].startswith("UNSAFE_DB_ROLE")
    with pytest.raises(RuntimeError, match="UNSAFE_DB_ROLE"):
        api._refuse_privileged_db_role()


def test_app_role_is_ready():
    from veriq_core.api import app as api
    assert TestClient(api.app).get("/ready").json() == {"ready": True}


def test_dev_tokens_refused_with_public_default_key(monkeypatch):
    from veriq_core import security
    monkeypatch.delenv("VERIQ_ALLOW_DEFAULT_DEV_KEY", raising=False); monkeypatch.delenv("VERIQ_DEV_TOKEN_KEY", raising=False)
    with pytest.raises(PermissionError, match="DEV_TOKEN_KEY_NOT_SET"):
        security.issue("a", "b", "customer")
    monkeypatch.setenv("VERIQ_DEV_TOKEN_KEY", "short")
    with pytest.raises(PermissionError, match="TOO_SHORT"):
        security.issue("a", "b", "customer")
    monkeypatch.setenv("VERIQ_DEV_TOKEN_KEY", "x" * 40)
    assert security.verify(security.issue("a", "b", "customer")).sub == "a"


def test_seeded_dev_keyring_is_stable_and_entity_scoped(monkeypatch):
    from veriq_core.kms import DevKeyring, KeyringError
    monkeypatch.setenv("VERIQ_DEV_KEY_SEED", "s" * 40)
    a1, a2, b = DevKeyring("dev.A"), DevKeyring("dev.A"), DevKeyring("dev.B")
    assert a1.public_key_der() == a2.public_key_der() != b.public_key_der()
    assert a2.unwrap(a1.wrap(b"k" * 32, b"aad"), b"aad") == b"k" * 32          # survives a restart
    assert a1.blind_index("x") == a2.blind_index("x") != b.blind_index("x")
    monkeypatch.setenv("VERIQ_DEV_KEY_SEED", "short")
    with pytest.raises(KeyringError):
        DevKeyring("dev.A")
