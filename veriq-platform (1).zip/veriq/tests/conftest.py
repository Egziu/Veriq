"""Synthetic fixture world on a real, disposable PostgreSQL. All data is SYNTHETIC."""
import hashlib, os, subprocess, sys, uuid
from datetime import datetime, timedelta, timezone

import psycopg, pytest
from psycopg.rows import dict_row

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in ("services/core", "packages/rules", "packages/verifier"):
    sys.path.insert(0, os.path.join(ROOT, p))

DB = os.environ.get("VERIQ_TEST_DB", "veriq_test")
# Real PKCS#11 path for every test: SoftHSM2 token (same API as hardware HSMs).
os.environ.setdefault("VERIQ_ALLOW_DEFAULT_DEV_KEY", "1")
os.environ.setdefault("SOFTHSM2_CONF", "/tmp/softhsm/softhsm2.conf")
os.environ.setdefault("VERIQ_PKCS11_LIB", "/usr/lib/softhsm/libsofthsm2.so")
os.environ.setdefault("VERIQ_PKCS11_TOKEN", "veriq-signing")
os.environ.setdefault("VERIQ_PKCS11_PIN", "246810")
os.environ["VERIQ_APP_DSN"] = f"host=/tmp/pg dbname={DB} user=veriq_app"
SUPER = f"host=/tmp/pg dbname={DB} user=postgres"

from veriq_core.db import tx, call  # noqa: E402

EVIDENCE = ['CLASSIFICATION', 'REGULATOR_APPROVAL', 'RULE_VERSION', 'AGE_GEO_POLICY', 'KYC_AML_POLICY', 'PRIVACY_RESIDENCY',
            'ADVERTISING_CHANNEL', 'TAX_ACCOUNTING', 'PRIZE_CONTRACT_RESERVE', 'INCIDENT_SUPPORT', 'FAIRNESS_PROCESS']
NOW = lambda: datetime.now(timezone.utc)  # noqa: E731


def sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


@pytest.fixture(scope="session", autouse=True)
def database():
    subprocess.run([os.path.join(ROOT, "scripts/migrate.sh"), DB], check=True, capture_output=True)
    with psycopg.connect(SUPER, autocommit=True) as c:
        c.execute("INSERT INTO veriq.countries VALUES ('ET','Ethiopia'),('KE','Kenya') ON CONFLICT DO NOTHING")
        c.execute("INSERT INTO veriq.payment_providers(code,state,gaming_model_accepted) VALUES "
                  "('fakepay','ACTIVE',true),('unapproved','ACTIVE',false) ON CONFLICT DO NOTHING")
    yield


def superuser():
    return psycopg.connect(SUPER, autocommit=True, row_factory=dict_row)


class World:
    """One legal entity with separated staff, accounts and an authorization row per product/channel."""

    def __init__(self, name="VERIQ Ethiopia PLC (synthetic)", country="ET"):
        self.entity = str(uuid.uuid4()); self.country = country
        self.staff = {r: str(uuid.uuid4()) for r in ("creator", "compliance", "cfo", "deploy", "ops", "support",
                                                     "inventory", "courier", "courier2", "sponsor", "sponsor_other", "admin",
                                                     "finance", "ceo", "finance_cfo", "compliance2")}
        roles = {"creator": ["COMP_OPS"], "compliance": ["COMPLIANCE"], "cfo": ["CFO"], "deploy": ["DEPLOYMENT"],
                 "ops": ["COMP_OPS"], "support": ["SUPPORT"], "inventory": ["INVENTORY"], "courier": ["FULFILLMENT"],
                 "courier2": ["FULFILLMENT"], "sponsor": ["SPONSOR"], "sponsor_other": ["SPONSOR"], "admin": ["INFRA_ADMIN"],
                 "finance": ["FINANCE"], "ceo": ["CEO"], "finance_cfo": ["FINANCE", "CFO"],
                 "compliance2": ["COMPLIANCE"]}
        with superuser() as c:
            c.execute("INSERT INTO veriq.legal_entities(id,name,country_code) VALUES (%s,%s,%s)", (self.entity, name, country))
            for k, sid in self.staff.items():
                c.execute("INSERT INTO veriq.staff_users(id,legal_entity_id,display_name,roles) VALUES (%s,%s,%s,%s)",
                          (sid, self.entity, f"{k} (synthetic)", roles[k]))
            for code, kind in (("1100-PROVIDER-CLEARING", "ASSET"), ("1000-BANK", "ASSET"), ("2100-CUSTOMER-LIABILITY", "LIABILITY"),
                               ("2200-PRIZE-OBLIGATION", "LIABILITY"), ("1300-PRIZE-INVENTORY", "ASSET"), ("4000-SPONSOR-REVENUE", "REVENUE")):
                c.execute("INSERT INTO veriq.accounts(legal_entity_id,code,currency,kind,name) VALUES (%s,%s,'ETB',%s,%s)",
                          (self.entity, code, kind, code))
        self.auth = {}
        from veriq_core.kms import HsmKeyring
        HsmKeyring.from_env(prefix=f"veriq.{self.entity}").provision()   # witnessed ceremony in production

    def as_staff(self, who):
        return tx(self.entity, self.staff[who])

    def create_authorization(self, product="SPONSOR_FREE", channel="WEB"):
        with superuser() as c:
            aid = c.execute("INSERT INTO veriq.country_product_authorizations(legal_entity_id,country_code,product_type,channel,created_by) "
                            "VALUES (%s,%s,%s,%s,%s) RETURNING id", (self.entity, self.country, product, channel, self.staff["creator"])).fetchone()["id"]
        self.auth[(product, channel)] = str(aid)
        return str(aid)

    def add_evidence(self, aid, kinds, expires=None):
        with self.as_staff("compliance") as cur:
            for k in kinds:
                call(cur, "record_evidence", aid, k, sha(k + aid + str(expires)), f"s3://evidence/{aid}/{k}.pdf", expires)

    def approve_all(self, aid, target):
        for who, role in (("compliance", "COMPLIANCE"), ("cfo", "CFO"), ("deploy", "DEPLOYMENT")):
            with self.as_staff(who) as cur:
                assert call(cur, "approve_authorization", aid, role, target) == "OK"

    def activate(self, product="SPONSOR_FREE", channel="WEB", to="LIMITED_PILOT"):
        aid = self.create_authorization(product, channel)
        kinds = EVIDENCE + (["PROVIDER_ACCEPTANCE"] if product == "PAID_COMPETITION" else [])
        self.add_evidence(aid, kinds)
        with self.as_staff("compliance") as cur:
            for st in ("DOSSIER", "REVIEWED"):
                assert call(cur, "transition_authorization", aid, st, None, None) == "OK"
        self.approve_all(aid, to)
        with self.as_staff("deploy") as cur:
            assert call(cur, "transition_authorization", aid, to, NOW() - timedelta(minutes=1), NOW() + timedelta(days=30)) == "OK"
        return aid

    def customer(self, verified=True, consent=True):
        cid = str(uuid.uuid4())
        with tx(self.entity) as cur:
            cur.execute("INSERT INTO veriq.customers(id,legal_entity_id,country_code,terms_consent_at) VALUES (%s,%s,%s,%s)",
                        (cid, self.entity, self.country, NOW() if consent else None))
        if verified:
            with self.as_staff("compliance") as cur:
                assert call(cur, "verify_customer_identity", cid, True, "VERIFIED") == "OK"
        return cid

    def sponsor(self, member="sponsor", name="Synthetic Telecom PLC"):
        sid = str(uuid.uuid4())
        with superuser() as c:
            c.execute("INSERT INTO veriq.sponsors(id,legal_entity_id,name) VALUES (%s,%s,%s)", (sid, self.entity, name))
            c.execute("INSERT INTO veriq.sponsor_members(sponsor_id,staff_id,legal_entity_id) VALUES (%s,%s,%s)", (sid, self.staff[member], self.entity))
        return sid

    def competition(self, product="SPONSOR_FREE", fee=0, cap=3, lo=1, hi=100, minutes=60, secure=True, title="Sponsor campaign (synthetic)", sponsor=None):
        body = '{"algorithm":"lowest-unique/1.0.0","range":[%d,%d],"cap":%d,"no_winner":"announce_and_rollover_prize","nonce":"%s"}' % (lo, hi, cap, uuid.uuid4())
        with self.as_staff("creator") as cur:
            rid = str(call(cur, "draft_rule", body))
        with self.as_staff("compliance") as cur:
            assert call(cur, "approve_rule", rid) == "OK"
        with self.as_staff("ops") as cur:
            comp = str(call(cur, "create_competition", self.country, product, title, rid, NOW() - timedelta(seconds=5),
                            NOW() + timedelta(minutes=minutes), fee, "ETB", lo, hi, cap, 2_500_000))
            if sponsor:
                assert call(cur, "assign_sponsor", comp, sponsor) == "OK"
        if secure:
            with self.as_staff("cfo") as cur:
                assert call(cur, "secure_prize", comp, 2_500_000, sha("supplier-commitment" + comp)) == "OK"
            with self.as_staff("ops") as cur:
                assert call(cur, "open_competition", comp) == "OK"
        return comp, rid

    def enter(self, comp, cust, sel, key=None, channel="WEB", pi=None):
        with tx(self.entity) as cur:
            return call(cur, "accept_entry", comp, cust, sel, key or f"idem-{uuid.uuid4()}", channel, pi)

    def close(self, comp):
        with self.as_staff("ops") as cur:
            return call(cur, "close_competition", comp)


@pytest.fixture
def world():
    return World()


@pytest.fixture
def live_world():
    w = World()
    w.activate("SPONSOR_FREE", "WEB")
    w.activate("SPONSOR_FREE", "TELEGRAM")
    return w


@pytest.fixture(autouse=True)
def _reset_rate_limits():
    from veriq_core.api import app as api
    api._BUCKETS.clear()
    yield
