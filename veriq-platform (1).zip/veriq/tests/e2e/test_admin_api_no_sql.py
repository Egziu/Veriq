"""Audit finding #1 fixed: a campaign can be set up and run end-to-end through the API — no superuser SQL."""
import hashlib, uuid
from datetime import datetime, timedelta, timezone
from fastapi.testclient import TestClient
from conftest import World, EVIDENCE
from veriq_core import security
from veriq_core.api.app import app

client = TestClient(app, base_url="https://testserver")
H = lambda w, who, roles: {"Authorization": "Bearer " + security.issue(w.staff[who], w.entity, "staff", roles=roles)}


def ok(r, code=200):
    assert r.status_code == code, r.text
    return r.json()


def test_campaign_setup_entirely_through_the_api():
    w = World(); now = datetime.now(timezone.utc)
    ok(client.post("/v1/staff/accounts/bootstrap", headers=H(w, "cfo", ["CFO"])))
    # A second compliance officer opens the dossier: whoever creates a request may never approve it.
    auth = ok(client.post("/v1/staff/authorizations", headers=H(w, "compliance2", ["COMPLIANCE"]),
                          json={"country": "ET", "product": "SPONSOR_FREE", "channel": "WEB"}), 201)["result"]
    for k in EVIDENCE:
        ok(client.post(f"/v1/staff/authorizations/{auth}/evidence", headers=H(w, "compliance", ["COMPLIANCE"]),
                       json={"kind": k, "sha256": hashlib.sha256(k.encode()).hexdigest(), "storage_uri": f"s3://dossier/{k}.pdf"}), 201)
    for st in ("DOSSIER", "REVIEWED"):
        ok(client.post(f"/v1/staff/authorizations/{auth}/transition", headers=H(w, "compliance", ["COMPLIANCE"]), json={"to": st}))
    for who, role in (("compliance", "COMPLIANCE"), ("cfo", "CFO"), ("deploy", "DEPLOYMENT")):
        ok(client.post(f"/v1/staff/authorizations/{auth}/approvals", headers=H(w, who, [role]), json={"role": role, "target_state": "LIMITED_PILOT"}), 201)
    ok(client.post(f"/v1/staff/authorizations/{auth}/transition", headers=H(w, "deploy", ["DEPLOYMENT"]),
                   json={"to": "LIMITED_PILOT", "effective_from": (now - timedelta(minutes=1)).isoformat(), "effective_to": (now + timedelta(days=30)).isoformat()}))

    rule = ok(client.post("/v1/staff/rules", headers=H(w, "ops", ["COMP_OPS"]),
                          json={"body": {"algorithm": "lowest-unique/1.0.0", "range": [1, 50], "cap": 2, "nonce": str(uuid.uuid4())}}), 201)["result"]
    assert client.post(f"/v1/staff/rules/{rule}/approve", headers=H(w, "ops", ["COMP_OPS"])).status_code == 403     # wrong role
    ok(client.post(f"/v1/staff/rules/{rule}/approve", headers=H(w, "compliance", ["COMPLIANCE"])))
    sponsor = ok(client.post("/v1/staff/sponsors", headers=H(w, "ops", ["COMP_OPS"]), json={"name": "Synthetic Telecom"}), 201)["result"]
    comp = ok(client.post("/v1/staff/competitions", headers=H(w, "ops", ["COMP_OPS"]), json={
        "country": "ET", "product": "SPONSOR_FREE", "title": "API-only campaign", "rule_version_id": rule,
        "opens_at": (now - timedelta(seconds=5)).isoformat(), "closes_at": (now + timedelta(hours=1)).isoformat(),
        "entry_fee_minor": 0, "number_min": 1, "number_max": 50, "per_customer_cap": 2, "prize_obligation_minor": 1_000_000}), 201)["result"]
    ok(client.post(f"/v1/staff/competitions/{comp}/sponsor", headers=H(w, "ops", ["COMP_OPS"]), json={"sponsor_id": sponsor}))
    assert client.post(f"/v1/staff/competitions/{comp}/open", headers=H(w, "ops", ["COMP_OPS"])).json()["code"] == "RESERVE_SHORTFALL"
    ok(client.post(f"/v1/staff/competitions/{comp}/secure-prize", headers=H(w, "cfo", ["CFO"]),
                   json={"reserve_minor": 1_000_000, "evidence_sha256": hashlib.sha256(b"PO-1").hexdigest()}))
    ok(client.post(f"/v1/staff/competitions/{comp}/open", headers=H(w, "ops", ["COMP_OPS"])))

    cust = w.customer(verified=False)
    tok = {"Authorization": "Bearer " + security.issue(cust, w.entity, "customer")}
    assert client.post(f"/v1/competitions/{comp}/entries", headers={**tok, "Idempotency-Key": "api-only-1"}, json={"selection": 9}).json()["code"] == "ELIGIBILITY_INCOMPLETE"
    ok(client.post(f"/v1/staff/customers/{cust}/identity", headers=H(w, "compliance", ["COMPLIANCE"]), json={"age_verified": True, "kyc_state": "VERIFIED"}))
    assert client.post(f"/v1/competitions/{comp}/entries", headers={**tok, "Idempotency-Key": "api-only-2"}, json={"selection": 9}).status_code == 201


def test_staff_creation_needs_two_people():
    w = World()
    new = ok(client.post("/v1/staff/staff", headers=H(w, "admin", ["INFRA_ADMIN"]), json={"display_name": "New Compliance", "roles": ["COMPLIANCE"]}), 201)["result"]
    assert client.post(f"/v1/staff/staff/{new}/activate", headers=H(w, "admin", ["INFRA_ADMIN"])).status_code == 403
    ok(client.post(f"/v1/staff/staff/{new}/activate", headers=H(w, "ceo", ["CEO"])))
    ok(client.post(f"/v1/staff/staff/{new}/deactivate", headers=H(w, "ceo", ["CEO"])))
    bad = client.post("/v1/staff/staff", headers=H(w, "admin", ["INFRA_ADMIN"]),
                      json={"display_name": "Sneaky", "roles": ["CFO"], "sponsor_id": str(uuid.uuid4())})
    assert bad.status_code in (409, 422)


def test_admin_cannot_propose_and_activate_themselves_as_ceo():
    w = World()
    from conftest import superuser
    with superuser() as c:
        c.execute("UPDATE veriq.staff_users SET roles=ARRAY['INFRA_ADMIN','CEO'] WHERE id=%s", (w.staff["admin"],))
    new = ok(client.post("/v1/staff/staff", headers=H(w, "admin", ["INFRA_ADMIN", "CEO"]), json={"display_name": "Puppet", "roles": ["CFO"]}), 201)["result"]
    assert client.post(f"/v1/staff/staff/{new}/activate", headers=H(w, "admin", ["INFRA_ADMIN", "CEO"])).json()["code"] == "DUAL_CONTROL_REQUIRED"
