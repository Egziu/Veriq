"""Chapa gateway: sponsor invoices, gated paid entries, webhook trust, verification-as-truth, refunds, outages."""
import hashlib, hmac, json, uuid
import pytest
from fastapi.testclient import TestClient
from conftest import World, call, superuser, tx
from support.fake_chapa import FakeChapa
from veriq_core import security
from veriq_core.api import app as api
from veriq_core.modules import chapa as cm

client = TestClient(api.app, base_url="https://testserver")
HOOK = "whsec-synthetic-webhook-secret"
EVID = hashlib.sha256(b"chapa-written-acceptance-letter").hexdigest()


@pytest.fixture(scope="module")
def fake():
    f = FakeChapa()
    api._CHAPA_CLIENT = cm.ChapaClient(cm.ChapaConfig(secret_key=f.key, webhook_secret=HOOK, base_url=f.base_url,
                                                      callback_base="https://api.veriq.et/v1/payments/chapa/callback"))
    yield f
    f.stop(); api._CHAPA_CLIENT = None


def H(w, who, roles):
    return {"Authorization": "Bearer " + security.issue(w.staff[who], w.entity, "staff", roles=roles)}


def C(w, cust):
    return {"Authorization": "Bearer " + security.issue(cust, w.entity, "customer")}


def ready_world(provider_state="ACTIVE"):
    w = World()
    with w.as_staff("cfo") as cur:
        call(cur, "bootstrap_chart_of_accounts", "ETB")
    r = client.post("/v1/staff/providers/chapa", headers=H(w, "cfo", ["CFO"]), json={"state": provider_state, "gaming_model_accepted": False})
    assert r.status_code == 200, r.text
    return w


def webhook(w, body: dict, secret=HOOK, header="x-chapa-signature", compact=True):
    raw = json.dumps(body, separators=(",", ":") if compact else (", ", ": ")).encode()
    sig = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    return client.post(f"/v1/webhooks/chapa/{w.entity}", content=raw, headers={header: sig, "Content-Type": "application/json"})


def ledger(w):
    with superuser() as c:
        return {r["code"]: r["s"] for r in c.execute("SELECT a.code, sum(l.amount_minor) s FROM veriq.journal_lines l JOIN veriq.accounts a "
                "ON a.id=l.account_id WHERE l.legal_entity_id=%s GROUP BY a.code", (w.entity,)).fetchall()}


def invoice_checkout(w, amount=5_000_000):
    sid = w.sponsor()
    inv = client.post("/v1/staff/sponsor-invoices", headers=H(w, "finance", ["FINANCE"]),
                      json={"sponsor_id": sid, "number": f"INV-{uuid.uuid4().hex[:6]}", "description": "Campaign sponsorship (synthetic)", "amount_minor": amount})
    assert inv.status_code == 201, inv.text
    pay = client.post(f"/v1/sponsor/invoices/{inv.json()['invoice_id']}/pay", headers=H(w, "sponsor", ["SPONSOR"]))
    assert pay.status_code == 200, pay.text
    return inv.json()["invoice_id"], pay.json()


def test_sponsor_invoice_paid_end_to_end_with_fees_and_idempotency(fake):
    w = ready_world(); inv, co = invoice_checkout(w)
    assert co["checkout_url"].startswith("https://checkout.chapa.co/")
    fake.pay(co["tx_ref"], "success", charge="1750.00")
    ev = {"event": "charge.success", "tx_ref": co["tx_ref"], "status": "success", "amount": "50000.00", "currency": "ETB"}
    r = webhook(w, ev); assert r.status_code == 200 and r.json()["disposition"] == "APPLIED"
    assert webhook(w, ev).json()["disposition"] == "DUPLICATE"           # Chapa retries are harmless
    assert webhook(w, ev, compact=False).status_code == 200              # SDK-style spaced JSON signature also accepted
    lst = client.get("/v1/sponsor/invoices", headers=H(w, "sponsor", ["SPONSOR"])).json()
    assert lst[0]["state"] == "PAID"
    b = ledger(w)
    assert b["1200-SPONSOR-RECEIVABLE"] == 0 and b["2300-SPONSOR-DEFERRED-REVENUE"] == -5_000_000
    assert b["1110-CHAPA-CLEARING"] == 5_000_000 - 175_000 and b["5200-PAYMENT-FEES"] == 175_000 and sum(b.values()) == 0


def test_webhook_authentication(fake):
    w = ready_world(); _, co = invoice_checkout(w); fake.pay(co["tx_ref"], "success")
    ev = {"event": "charge.success", "tx_ref": co["tx_ref"]}
    assert webhook(w, ev, secret="wrong-secret").status_code == 401
    static = hmac.new(HOOK.encode(), HOOK.encode(), hashlib.sha256).hexdigest()   # the documented static header
    r = client.post(f"/v1/webhooks/chapa/{w.entity}", content=json.dumps(ev).encode(), headers={"chapa-signature": static})
    assert r.status_code == 401                                          # payload-independent header alone is not trusted
    assert client.post(f"/v1/webhooks/chapa/{w.entity}", json=ev).status_code == 401


def test_signed_webhook_cannot_override_chapa_verify(fake):
    w = ready_world(); inv, co = invoice_checkout(w)                     # Chapa still says "pending"
    r = webhook(w, {"event": "charge.success", "tx_ref": co["tx_ref"], "status": "success"})
    assert r.json()["disposition"] == "STILL_PENDING"
    assert client.get("/v1/sponsor/invoices", headers=H(w, "sponsor", ["SPONSOR"])).json()[0]["state"] == "ISSUED"


def test_amount_and_mode_tampering_become_exceptions(fake):
    w = ready_world(); _, co = invoice_checkout(w)
    fake.pay(co["tx_ref"], "success", amount="1.00")
    assert webhook(w, {"event": "charge.success", "tx_ref": co["tx_ref"]}).json()["disposition"] == "AMOUNT_MISMATCH_EXCEPTION"
    w2 = ready_world(); _, co2 = invoice_checkout(w2)
    fake.pay(co2["tx_ref"], "success", mode="live")                       # test key but "live" verify result
    assert webhook(w2, {"event": "charge.success", "tx_ref": co2["tx_ref"]}).json()["disposition"] == "MODE_MISMATCH"
    assert "1110-CHAPA-CLEARING" not in ledger(w) and "1110-CHAPA-CLEARING" not in ledger(w2)


def test_callback_ignores_status_parameter(fake):
    w = ready_world(); _, co = invoice_checkout(w)
    r = client.get(f"/v1/payments/chapa/callback/{w.entity}", params={"trx_ref": co["tx_ref"], "status": "success"})
    assert r.json()["disposition"] == "STILL_PENDING"
    fake.pay(co["tx_ref"], "success")
    assert client.get(f"/v1/payments/chapa/callback/{w.entity}", params={"trx_ref": co["tx_ref"]}).json()["state"] == "CONFIRMED"
    assert client.get(f"/v1/payments/chapa/callback/{w.entity}", params={"trx_ref": "../etc"}).status_code in (400, 422)


def test_failed_payment_and_missed_webhook_reconciliation(fake):
    w = ready_world(); _, a = invoice_checkout(w); _, b = invoice_checkout(w)
    fake.pay(a["tx_ref"], "failed"); fake.pay(b["tx_ref"], "success")   # no webhooks delivered at all
    with superuser() as c:
        c.execute("UPDATE veriq.payment_intents SET created_at = now() - interval '10 minutes' WHERE legal_entity_id=%s", (w.entity,))
    r = client.post("/v1/staff/payments/reconcile", headers=H(w, "finance", ["FINANCE"])).json()
    assert r["payments"]["checked"] == 2 and r["payments"]["applied"] == 2
    states = sorted(i["state"] for i in client.get("/v1/sponsor/invoices", headers=H(w, "sponsor", ["SPONSOR"])).json())
    assert states == ["ISSUED", "PAID"]                                   # failed one can be paid again


def test_retry_reuses_or_applies_open_checkout_instead_of_discarding_it(fake):
    """Regression: a second 'pay' click used to expire the first checkout even if the sponsor had paid on it."""
    w = ready_world(); inv, first = invoice_checkout(w)
    again = client.post(f"/v1/sponsor/invoices/{inv}/pay", headers=H(w, "sponsor", ["SPONSOR"])).json()
    assert again["reused"] and again["tx_ref"] == first["tx_ref"]
    fake.pay(first["tx_ref"], "success")                                  # paid on the first page, no webhook yet
    r = client.post(f"/v1/sponsor/invoices/{inv}/pay", headers=H(w, "sponsor", ["SPONSOR"]))
    assert r.status_code == 409 and r.json()["code"] == "INVOICE_NOT_PAYABLE"
    assert client.get("/v1/sponsor/invoices", headers=H(w, "sponsor", ["SPONSOR"])).json()[0]["state"] == "PAID"


def test_fee_larger_than_payment_is_an_exception(fake):
    w = ready_world(); _, co = invoice_checkout(w, amount=1000); fake.pay(co["tx_ref"], "success", charge="25.00")
    assert webhook(w, {"event": "charge.success", "tx_ref": co["tx_ref"]}).json()["disposition"] == "FEE_INVALID_EXCEPTION"


def test_chapa_outage_is_safe(fake):
    w = ready_world(); inv, co = invoice_checkout(w); fake.pay(co["tx_ref"], "success")
    fake.down = True
    try:
        assert webhook(w, {"event": "charge.success", "tx_ref": co["tx_ref"]}).status_code == 503   # Chapa will retry
        assert client.post(f"/v1/sponsor/invoices/{inv}/pay", headers=H(w, "sponsor", ["SPONSOR"])).status_code == 503
    finally:
        fake.down = False
    assert webhook(w, {"event": "charge.success", "tx_ref": co["tx_ref"]}).json()["disposition"] == "APPLIED"


def test_unexpected_checkout_host_is_refused(fake, monkeypatch):
    w = ready_world()
    cfg = api._CHAPA_CLIENT.cfg
    api._CHAPA_CLIENT.cfg = cm.ChapaConfig(cfg.secret_key, cfg.webhook_secret, cfg.base_url, cfg.callback_base, cfg.return_url, ("pay.example",))
    try:
        sid = w.sponsor()
        inv = client.post("/v1/staff/sponsor-invoices", headers=H(w, "finance", ["FINANCE"]),
                          json={"sponsor_id": sid, "number": "INV-HOST", "description": "x" * 5, "amount_minor": 100}).json()["invoice_id"]
        r = client.post(f"/v1/sponsor/invoices/{inv}/pay", headers=H(w, "sponsor", ["SPONSOR"]))
        assert r.status_code == 503 and "UNEXPECTED_CHECKOUT_HOST" in r.json()["detail"]
    finally:
        api._CHAPA_CLIENT.cfg = cfg


def test_secret_key_never_leaves_the_server(fake):
    w = ready_world(); _, co = invoice_checkout(w)
    assert fake.key not in json.dumps(co)
    assert all(r["headers"].get("Authorization") == f"Bearer {fake.key}" for r in fake.requests)
    assert all(fake.key not in json.dumps(r["body"]) for r in fake.requests)


def test_paid_entry_requires_gate_and_written_acceptance(fake):
    w = ready_world(); comp, _ = w.competition(product="PAID_COMPETITION", fee=2000); cu = w.customer()
    me = C(w, cu)
    assert client.post("/v1/payments/chapa/entry", headers=me, json={"competition_id": comp}).json()["code"] == "DENIED_COUNTRY"
    w.activate("PAID_COMPETITION", "WEB")
    assert client.post("/v1/payments/chapa/entry", headers=me, json={"competition_id": comp}).json()["code"] == "PROVIDER_SUSPENDED"
    no_ev = client.post("/v1/staff/providers/chapa", headers=H(w, "cfo", ["CFO"]), json={"state": "ACTIVE", "gaming_model_accepted": True})
    assert no_ev.json()["code"] == "EVIDENCE_REQUIRED"
    assert client.post("/v1/staff/providers/chapa", headers=H(w, "cfo", ["CFO"]),
                       json={"state": "ACTIVE", "gaming_model_accepted": True, "evidence_sha256": EVID}).status_code == 200
    try:
        co = client.post("/v1/payments/chapa/entry", headers=me, json={"competition_id": comp}).json()
        assert co["amount_minor"] == 2000
        entry = client.post(f"/v1/competitions/{comp}/entries", headers={**me, "Idempotency-Key": "paid-0001"},
                            json={"selection": 4, "payment_intent_id": co["intent_id"]})
        assert entry.json()["code"] == "PAYMENT_NOT_CONFIRMED"           # not paid yet
        fake.pay(co["tx_ref"], "success", charge="0.70")
        assert webhook(w, {"event": "charge.success", "tx_ref": co["tx_ref"]}).json()["disposition"] == "APPLIED"
        entry = client.post(f"/v1/competitions/{comp}/entries", headers={**me, "Idempotency-Key": "paid-0002"},
                            json={"selection": 4, "payment_intent_id": co["intent_id"]})
        assert entry.status_code == 201
        again = client.post(f"/v1/competitions/{comp}/entries", headers={**me, "Idempotency-Key": "paid-0003"},
                            json={"selection": 5, "payment_intent_id": co["intent_id"]})
        assert again.json()["code"] == "PAYMENT_NOT_CONFIRMED"           # one payment funds one entry
        b = ledger(w)
        assert b["2100-CUSTOMER-LIABILITY"] == -2000 and b["1110-CHAPA-CLEARING"] == 1930 and b["5200-PAYMENT-FEES"] == 70
    finally:
        with superuser() as c:
            c.execute("UPDATE veriq.payment_providers SET gaming_model_accepted=false WHERE code='chapa'")


def test_refund_dual_control_and_settlement(fake):
    w = ready_world(); inv, co = invoice_checkout(w, amount=100_000); fake.pay(co["tx_ref"], "success", charge="35.00")
    webhook(w, {"event": "charge.success", "tx_ref": co["tx_ref"]})
    with superuser() as c:
        pid = str(c.execute("SELECT id FROM veriq.payment_intents WHERE merchant_ref=%s", (co["tx_ref"],)).fetchone()["id"])
    assert client.post(f"/v1/staff/payments/{pid}/refunds", headers=H(w, "finance", ["FINANCE"]),
                       json={"amount_minor": 200_000, "reason": "too much"}).json()["code"] == "REFUND_EXCEEDS_PAYMENT"
    rid = client.post(f"/v1/staff/payments/{pid}/refunds", headers=H(w, "finance_cfo", ["FINANCE", "CFO"]),
                      json={"amount_minor": 40_000, "reason": "Campaign scope reduced"}).json()["refund_id"]
    assert client.post(f"/v1/staff/refunds/{rid}/approve", headers=H(w, "finance_cfo", ["FINANCE", "CFO"])).json()["code"] == "DUAL_CONTROL_REQUIRED"
    assert client.post(f"/v1/staff/refunds/{rid}/approve", headers=H(w, "finance", ["FINANCE"])).status_code == 403
    ok = client.post(f"/v1/staff/refunds/{rid}/approve", headers=H(w, "cfo", ["CFO"])).json()
    assert ok["state"] == "SUBMITTED"
    fake.refunds[ok["provider_ref_id"]]["status"] = "refunded"
    assert client.post("/v1/staff/payments/reconcile", headers=H(w, "finance", ["FINANCE"])).json()["refunds"]["settled"] == 1
    b = ledger(w)
    assert b["1110-CHAPA-CLEARING"] == 100_000 - 3_500 - 40_000 and b["5200-PAYMENT-FEES"] == 3_500   # fee not refunded
    assert b["1200-SPONSOR-RECEIVABLE"] == 40_000 and sum(b.values()) == 0


def test_test_key_refused_in_production(monkeypatch):
    monkeypatch.setenv("VERIQ_ENV", "production"); monkeypatch.setenv("VERIQ_CHAPA_SECRET_KEY", "CHASECK_TEST-x")
    monkeypatch.setenv("VERIQ_CHAPA_WEBHOOK_SECRET", "y")
    with pytest.raises(cm.ChapaError, match="TEST_KEY_IN_PRODUCTION"):
        cm.ChapaConfig.from_env()


def test_money_conversion_is_exact():
    assert cm.minor_to_amount(5) == "0.05" and cm.minor_to_amount(123456) == "1234.56"
    assert cm.amount_to_minor("1234.56") == 123456 and cm.amount_to_minor(100) == 10000
    for bad in ["1.234", "-1", "abc"]:
        with pytest.raises(cm.ChapaError):
            cm.amount_to_minor(bad)
