"""Double-entry ledger invariants and payment event idempotency."""
import json, uuid
from conftest import World, call
from veriq_core.db import tx


def lines(*pairs):
    return json.dumps([{"account": a, "currency": "ETB", "amount_minor": m} for a, m in pairs])


def test_balanced_posting_and_reversal(world):
    with world.as_staff("cfo") as cur:
        j = call(cur, "post_journal", "sponsor.invoice", "INV-001", "Sponsor fee (synthetic)",
                 lines(("1000-BANK", 1_000_00), ("4000-SPONSOR-REVENUE", -1_000_00)), None)
        r = call(cur, "reverse_journal", j, "Invoice voided")
        cur.execute("SELECT sum(amount_minor) s FROM veriq.journal_lines"); assert cur.fetchone()["s"] == 0
        assert r != j


def test_unbalanced_rejected(world):
    try:
        with world.as_staff("cfo") as cur:
            call(cur, "post_journal", "x", "bad-1", "", lines(("1000-BANK", 100), ("4000-SPONSOR-REVENUE", -99)), None)
        raise AssertionError
    except Exception as e:
        assert "UNBALANCED_JOURNAL" in str(e)


def test_posted_journal_cannot_be_edited_even_by_superuser_path(world):
    from conftest import superuser
    with world.as_staff("cfo") as cur:
        j = call(cur, "post_journal", "x", "ok-1", "", lines(("1000-BANK", 500), ("4000-SPONSOR-REVENUE", -500)), None)
    with superuser() as c:
        for stmt in ("UPDATE veriq.journal_lines SET amount_minor=1 WHERE journal_id=%s", "DELETE FROM veriq.journals WHERE id=%s"):
            try:
                c.execute(stmt, (j,)); raise AssertionError(stmt)
            except Exception as e:
                assert "IMMUTABLE_RECORD" in str(e)


def test_reversal_only_once(world):
    with world.as_staff("cfo") as cur:
        j = call(cur, "post_journal", "x", "rev-1", "", lines(("1000-BANK", 7), ("4000-SPONSOR-REVENUE", -7)), None)
        call(cur, "reverse_journal", j, "first")
    try:
        with world.as_staff("cfo") as cur:
            call(cur, "reverse_journal", j, "second"); raise AssertionError
    except Exception as e:
        assert "unique" in str(e).lower()


def make_intent(w, cust, amount=5000, provider="fakepay", comp=None):
    """Generic-provider intents for ledger tests. The app role can no longer insert intents (only the gated
    create_payment_intent command can), so this fixture writes as superuser."""
    from conftest import superuser
    if comp is None:
        comp, _ = w.competition(product="PAID_COMPETITION", fee=amount, secure=False)
    pid, ref = str(uuid.uuid4()), f"VQ-{uuid.uuid4().hex[:12]}"
    with superuser() as c:
        c.execute("INSERT INTO veriq.payment_intents(id,legal_entity_id,customer_id,provider,merchant_ref,amount_minor,currency,purpose,competition_id) "
                  "VALUES (%s,%s,%s,%s,%s,%s,'ETB','ENTRY_FEE',%s)", (pid, w.entity, cust, provider, ref, amount, comp))
    return pid, ref


def apply(w, ref, kind, eid=None, amount=5000, provider="fakepay"):
    with tx(w.entity) as cur:
        return call(cur, "apply_payment_event", provider, eid or f"evt-{uuid.uuid4()}", ref, kind, amount, "ETB", "0" * 64)


def test_duplicate_and_reordered_callbacks_apply_once(world):
    cu = world.customer(); _, ref = make_intent(world, cu)
    assert apply(world, ref, "CONFIRMED", "evt-1")["applied"]
    assert apply(world, ref, "CONFIRMED", "evt-1")["disposition"] == "DUPLICATE"
    assert apply(world, ref, "PENDING", "evt-0")["disposition"] == "OUT_OF_ORDER_HELD"   # late PENDING after CONFIRMED
    with tx(world.entity) as cur:
        cur.execute("SELECT count(*) n FROM veriq.journals WHERE source='payment.confirmed'"); assert cur.fetchone()["n"] == 1


def test_amount_mismatch_goes_to_exception(world):
    cu = world.customer(); _, ref = make_intent(world, cu)
    r = apply(world, ref, "CONFIRMED", amount=1)
    assert r["disposition"] == "AMOUNT_MISMATCH_EXCEPTION" and r["state"] == "EXCEPTION"


def test_app_cannot_mark_paid_directly(world):
    cu = world.customer(); pid, _ = make_intent(world, cu)
    try:
        with tx(world.entity) as cur:
            cur.execute("UPDATE veriq.payment_intents SET state='CONFIRMED' WHERE id=%s", (pid,)); raise AssertionError
    except Exception as e:
        assert "permission denied" in str(e)


def test_paid_entry_path_and_refund_journal():
    w = World(); w.activate("PAID_COMPETITION", "WEB")
    comp, _ = w.competition(product="PAID_COMPETITION", fee=5000); cu = w.customer()
    pid, ref = make_intent(w, cu, comp=comp)
    assert w.enter(comp, cu, 11, pi=pid)["code"] == "PAYMENT_NOT_CONFIRMED"
    apply(w, ref, "CONFIRMED")
    ok = w.enter(comp, cu, 11, pi=pid); assert ok["ok"]
    assert w.enter(comp, cu, 12, pi=pid)["code"] == "PAYMENT_NOT_CONFIRMED"  # intent already APPLIED; cannot fund twice
    pid2, ref2 = make_intent(w, cu, comp=comp); apply(w, ref2, "CONFIRMED"); r = apply(w, ref2, "REFUNDED")
    assert r["applied"]
    with tx(w.entity) as cur:
        cur.execute("SELECT a.code, sum(l.amount_minor) s FROM veriq.journal_lines l JOIN veriq.accounts a ON a.id=l.account_id GROUP BY a.code")
        bal = {r["code"]: r["s"] for r in cur.fetchall()}
    assert bal["1100-PROVIDER-CLEARING"] == 5000 and bal["2100-CUSTOMER-LIABILITY"] == -5000


def test_unapproved_provider_blocks_paid_entry():
    w = World(); w.activate("PAID_COMPETITION", "WEB")
    comp, _ = w.competition(product="PAID_COMPETITION", fee=5000); cu = w.customer()
    pid, ref = make_intent(w, cu, provider="unapproved", comp=comp); apply(w, ref, "CONFIRMED", provider="unapproved")
    assert w.enter(comp, cu, 3, pi=pid)["code"] == "PROVIDER_SUSPENDED"


def test_paid_blocked_without_authorization(world):
    comp, _ = world.competition(product="PAID_COMPETITION", fee=5000); cu = world.customer()
    pid, ref = make_intent(world, cu, comp=comp); apply(world, ref, "CONFIRMED")
    assert world.enter(comp, cu, 3, pi=pid)["code"] == "DENIED_COUNTRY"



def test_payment_for_one_competition_cannot_fund_another():
    """Audit finding: accept_entry checked amount but not which competition the payment was for."""
    w = World(); w.activate("PAID_COMPETITION", "WEB")
    a, _ = w.competition(product="PAID_COMPETITION", fee=5000, title="A"); b, _ = w.competition(product="PAID_COMPETITION", fee=5000, title="B")
    cu = w.customer(); pid, ref = make_intent(w, cu, comp=a); apply(w, ref, "CONFIRMED")
    try:
        w.enter(b, cu, 3, pi=pid); raise AssertionError("cross-competition payment accepted")
    except Exception as e:
        assert "PAYMENT_NOT_FOR_THIS_COMPETITION" in str(e)
    assert w.enter(a, cu, 3, pi=pid)["ok"]
