"""Background worker: outbox publication (at-least-once, no double publish), claim expiry, overdue-close alert."""
from datetime import timedelta
from conftest import World, superuser
from veriq_core import worker
from veriq_core.modules import fairness


def test_outbox_published_once_and_claims_expired():
    w = World(); w.activate(); comp, _ = w.competition(minutes=60)
    c1, c2 = w.customer(), w.customer()
    w.enter(comp, c1, 3); w.enter(comp, c2, 9); w.close(comp)
    with w.as_staff("ops") as cur:
        fairness.compute_and_publish(cur, comp, fairness.Signer(entity=w.entity), tsa_urls=[], tsa_roots=[], min_witness=0)
    from veriq_core.db import tx, call
    with tx(w.entity) as cur:
        claim = call(cur, "open_claim", comp, c1)["claim_id"]
    with superuser() as c:
        c.execute("UPDATE veriq.claims SET deadline = now() - interval '1 second' WHERE id=%s", (claim,))
    got = []
    rep = worker.cycle(sink=got.append)[w.entity]
    types = [e["type"] for e in got if e["legal_entity_id"] == w.entity]
    assert types.count("entry.accepted.v1") == 2 and "competition.frozen.v1" in types and "result.verified.v1" in types
    assert all(e["classification"] in ("NO_PII", "INTERNAL") for e in got)
    assert rep["claims_expired"] == 1
    again = []
    worker.cycle(sink=again.append)
    assert not [e for e in again if e["legal_entity_id"] == w.entity]          # nothing published twice


def test_overdue_open_competition_is_reported():
    w = World(); w.activate(); comp, _ = w.competition(minutes=60)
    with superuser() as c:
        c.execute("UPDATE veriq.competitions SET opens_at = now() - interval '2 hours', closes_at = now() - interval '1 minute' WHERE id=%s", (comp,))
    rep = worker.cycle(sink=lambda e: None)[w.entity]
    assert [x["id"] for x in rep["overdue_close"]] == [comp]
