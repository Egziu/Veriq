"""Local stand-in for the Chapa API (shape per developer.chapa.co: initialize, verify, refund, refund-verify).
Lets tests drive every state: pending, success, failed, amount/mode tampering, outages, refunds. SYNTHETIC."""
import json, re, secrets, threading
from http.server import BaseHTTPRequestHandler, HTTPServer


class FakeChapa:
    def __init__(self, secret_key="CHASECK_TEST-synthetic0123456789", mode="test"):
        self.key, self.mode = secret_key, mode
        self.tx: dict[str, dict] = {}
        self.refunds: dict[str, dict] = {}
        self.requests: list[dict] = []
        self.down = False
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def _send(self, code, body):
                b = json.dumps(body).encode(); self.send_response(code)
                self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b)))
                self.end_headers(); self.wfile.write(b)

            def _auth(self):
                return self.headers.get("Authorization") == f"Bearer {fake.key}"

            def _handle(self, method):
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}") if n else {}
                fake.requests.append({"method": method, "path": self.path, "body": body, "headers": dict(self.headers)})
                if fake.down:
                    return self._send(502, {"message": "Bad gateway", "status": "failed"})
                if not self._auth():
                    return self._send(401, {"message": "Invalid API Key", "status": "failed", "data": None})
                p = self.path
                if method == "POST" and p == "/v1/transaction/initialize":
                    if body["tx_ref"] in fake.tx:
                        return self._send(400, {"message": "Transaction reference has been used before", "status": "failed"})
                    fake.tx[body["tx_ref"]] = {"amount": body["amount"], "currency": body["currency"], "status": "pending",
                                               "charge": "0.00", "mode": fake.mode, "reference": "AP" + secrets.token_hex(5),
                                               "first_name": body.get("first_name"), "last_name": body.get("last_name")}
                    return self._send(200, {"message": "Hosted Link", "status": "success",
                                            "data": {"checkout_url": f"https://checkout.chapa.co/checkout/payment/{secrets.token_hex(8)}"}})
                m = re.fullmatch(r"/v1/transaction/verify/(.+)", p)
                if method == "GET" and m:
                    t = fake.tx.get(m.group(1))
                    if not t:
                        return self._send(404, {"message": "Invalid transaction or Transaction not found", "status": "failed"})
                    return self._send(200, {"message": "Payment details", "status": "success", "data": {"tx_ref": m.group(1), **t}})
                m = re.fullmatch(r"/v1/refund/([^/]+)", p)
                if method == "POST" and m:
                    ref = next((k for k, v in fake.tx.items() if v["reference"] == m.group(1)), None)
                    if not ref:
                        return self._send(404, {"message": "Transaction not found", "status": "failed"})
                    rid = "MERC-REF-" + secrets.token_hex(6)
                    fake.refunds[rid] = {"status": "initiated", "amount": body.get("amount"), "payment_reference": m.group(1),
                                         "merchant_reference": body.get("reference")}
                    return self._send(200, {"message": "Refund initiated", "status": "success", "data": {"ref_id": rid}})
                m = re.fullmatch(r"/v1/refund/([^/]+)/verify", p)
                if method == "GET" and m and m.group(1) in fake.refunds:
                    return self._send(200, {"message": "Refund verified successfully", "status": "success",
                                            "data": {"ref_id": m.group(1), **fake.refunds[m.group(1)]}})
                return self._send(404, {"message": "Not found", "status": "failed"})

            def do_GET(self): self._handle("GET")
            def do_POST(self): self._handle("POST")

        self.server = HTTPServer(("127.0.0.1", 0), H)
        self.base_url = f"http://127.0.0.1:{self.server.server_port}/v1"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def pay(self, tx_ref, status="success", amount=None, charge="0.00", mode=None):
        t = self.tx[tx_ref]; t["status"] = status; t["charge"] = charge
        if amount is not None: t["amount"] = amount
        if mode is not None: t["mode"] = mode

    def stop(self):
        self.server.shutdown()
