# VERIQ — Trust in Every Win

High-assurance, multi-channel competition platform. **Release candidate 1.0.0-rc1. Launch decision: NO GO**
(see `reports/readiness/READINESS.md`). All data is synthetic.

## What is real and tested here
- **Go/no-go control plane** — every country × product × channel ships BLOCKED. Activation needs 11 evidence kinds
  (12 for paid, incl. provider acceptance), Compliance + CFO + Deployment approvals by three different people, never the creator.
- **Atomic acceptance** (`accept_entry`) — eligibility, consent, self-exclusion, cross-channel caps, idempotency,
  rule hash binding, contiguous sequence, hash-chained receipt, outbox — one transaction, one lock shared with close.
- **Double-entry ledger** — integer minor units, balanced on post and again at commit, immutable, one reversal per journal.
- **Payments** — signed webhooks with replay window; events applied at most once; the app role cannot mark anything paid.
- **Tenancy** — FORCE + RESTRICTIVE RLS, composite foreign keys, unprivileged app role that owns nothing.
- **Fairness** — pure `veriq_rules`, a separately written `veriq_verifier`, Ed25519-signed manifest, witnessed chain head;
  publication refused without a matching verifier attestation. Insider tampering with triggers disabled is *detected*.
- **Telegram** — initData HMAC validation per the official spec, forgery/staleness/duplicate-field tests.

## Run
```bash
scripts/demo/run_demo.sh          # migrate → 100 tests → narrated vertical slice → benchmark
python3 scripts/drills/backup_restore_drill.py   # needs the HSM env vars; writes reports/drills/
```
Requires PostgreSQL 16 on socket `/tmp/pg` (or set `PGHOST` / `VERIQ_APP_DSN`) and `pip install -r requirements.lock`.

## Map
| Path | Contents |
|---|---|
| `db/migrations/` | 0001 foundation + command functions · 0002 ledger, payments, results, RLS · 0003 hardening |
| `services/core/veriq_core/` | FastAPI API, DB context, payments, Telegram, fairness pipeline |
| `packages/rules`, `packages/verifier` | Deterministic rule library; independent verifier |
| `packages/design-tokens/` | Forest-and-gold tokens with measured contrast |
| `apps/web/prototype.html` | Interactive customer app + operations console prototype |
| `tests/` | integration, adversarial, property (2,500 cases), e2e — real PostgreSQL |
| `docs/adr/`, `docs/threat-model/` | Decisions and attack → control → evidence matrix |
| `openapi/` | Generated OpenAPI 3.1 |

## Added in round 2
Passkey login and revocable sessions; HSM-held keys (PKCS#11); envelope-encrypted PII with blind index; RFC 3161 witnesses;
claims, serial inventory and dual-control delivery; sponsor portal; full Telegram bot + Mini App entries; Next.js portals;
Flutter app (not yet compiled); executed backup/PITR/failover drill; route-wide security sweep; runbooks.

## Not started / partial (honest list)
Flutter compile/device testing · lost-passkey recovery · KYC provider integration · monitoring/alerting · procurement
and AI-assistant modules · human-reviewed translations · pilot load test · production HSM/TSA configuration ·
independent pentest · legal opinion. See reports/readiness/READINESS.md.
