# VERIQ mobile (Flutter, Android + iOS)

**Status: written, NOT compiled or run in the build sandbox** (Flutter SDK host is outside its network allowlist).
First steps for your team:
```bash
flutter create --org et.veriq --project-name veriq --platforms android,ios .   # generates platform scaffolding; keeps lib/ and test/
flutter pub get && flutter analyze && flutter test
flutter run --dart-define=VERIQ_API=https://staging-api.veriq.et --dart-define=VERIQ_ENTITY=<entity-uuid>
```
Then merge `android/app/src/main/AndroidManifest.snippet.xml`, keep `network_security_config.xml`, add `Runner.entitlements`,
and publish `apps/web/public/.well-known/*` with the real signing fingerprints (passkeys will not work without them).

`test/receipt_chain_test.dart` uses vectors produced by the Python reference — if it fails, the Dart verifier is wrong.
The passkey integration (`lib/auth/passkey_service.dart`) targets `passkeys` 2.4.0; confirm its API with `flutter analyze`.
