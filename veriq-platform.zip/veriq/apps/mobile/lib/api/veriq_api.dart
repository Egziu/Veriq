import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

/// Thin typed client. The server decides everything; the app never infers acceptance, payment or winning.
class VeriqApi {
  VeriqApi({required this.baseUrl, required this.entity, http.Client? client, FlutterSecureStorage? storage})
      : _http = client ?? http.Client(),
        _store = storage ?? const FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true),
            iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock_this_device));
  final String baseUrl;
  final String entity;
  final http.Client _http;
  final FlutterSecureStorage _store;
  static const _tokenKey = 'veriq.session';

  Future<String?> get token => _store.read(key: _tokenKey);
  Future<void> saveToken(String t) => _store.write(key: _tokenKey, value: t);
  Future<void> clearToken() => _store.delete(key: _tokenKey);

  Future<Map<String, String>> _headers({String? idem}) async {
    final t = await token;
    return {
      'Content-Type': 'application/json', 'X-Entity': entity, 'X-Client': 'mobile', 'X-Request-ID': const Uuid().v4(),
      if (t != null) 'Authorization': 'Bearer $t',
      if (idem != null) 'Idempotency-Key': idem,
    };
  }

  Future<Object?> _send(String method, String path, {Object? body, String? idem, String? channel}) async {
    final h = await _headers(idem: idem);
    if (channel != null) h['X-Channel'] = channel;
    final req = http.Request(method, Uri.parse('$baseUrl$path'))..headers.addAll(h);
    if (body != null) req.body = jsonEncode(body);
    final http.Response r;
    try {
      r = await http.Response.fromStream(await _http.send(req).timeout(const Duration(seconds: 15)));
    } catch (_) {
      throw const ApiProblem('OFFLINE', 'No connection. Nothing was submitted.', 0);
    }
    final decoded = r.body.isEmpty ? null : jsonDecode(r.body);
    if (r.statusCode >= 400) {
      final m = decoded is Map<String, Object?> ? decoded : <String, Object?>{};
      if (r.statusCode == 401) await clearToken();
      throw ApiProblem(m['code'] as String? ?? 'HTTP_${r.statusCode}', m['detail'] as String? ?? 'Request failed', r.statusCode,
          requestId: m['request_id'] as String?);
    }
    return decoded;
  }

  Future<Map<String, Object?>> post(String path, Object body, {String? idem, String? channel}) async =>
      (await _send('POST', path, body: body, idem: idem, channel: channel)) as Map<String, Object?>;
  Future<Object?> get(String path) => _send('GET', path);

  // ---- domain calls ----
  Future<List<Map<String, Object?>>> competitions() async => ((await get('/v1/competitions')) as List).cast<Map<String, Object?>>();
  Future<List<Map<String, Object?>>> myEntries() async => ((await get('/v1/me/entries')) as List).cast<Map<String, Object?>>();
  Future<List<Map<String, Object?>>> myClaims() async => ((await get('/v1/me/claims')) as List).cast<Map<String, Object?>>();
  Future<Map<String, Object?>> manifest(String comp) async => (await get('/v1/competitions/$comp/manifest')) as Map<String, Object?>;

  /// The idempotency key is created ONCE per intended entry and reused on retry, so a timeout can never create two entries.
  Future<Map<String, Object?>> submitEntry(String comp, int selection, String idempotencyKey, String channel) =>
      post('/v1/competitions/$comp/entries', {'selection': selection}, idem: idempotencyKey, channel: channel);
  Future<Map<String, Object?>> openClaim(String comp) => post('/v1/competitions/$comp/claim', {});
  Future<Map<String, Object?>> telegramLinkCode() => post('/v1/me/telegram/link-code', {});
  Future<Map<String, Object?>> selfExclude(int days) => post('/v1/me/self-exclusion', {'days': days});
  Future<void> signOutEverywhere() async { await post('/v1/me/sessions/revoke-all', {}); await clearToken(); }
}

class ApiProblem implements Exception {
  const ApiProblem(this.code, this.detail, this.status, {this.requestId});
  final String code;
  final String detail;
  final int status;
  final String? requestId;

  String get message => switch (code) {
        'OFFLINE' => 'You are offline. Nothing was submitted.',
        'ENTRY_CAP_REACHED' => 'You have used all your entries for this campaign.',
        'COMPETITION_NOT_OPEN' => 'This campaign is closed.',
        'SELF_EXCLUDED' => 'You chose a break from VERIQ. Entries are paused until it ends.',
        'ELIGIBILITY_INCOMPLETE' => 'Finish identity verification before entering.',
        'DENIED_COUNTRY' || 'DENIED_PRODUCT' || 'EXPIRED_SCOPE' => 'This is not available where you are.',
        'RATE_LIMITED' => 'Too many tries. Wait a minute and try again.',
        _ => '$detail${requestId == null ? '' : ' (ref ${requestId!.substring(0, 8)})'}',
      };
}
