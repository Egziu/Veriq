import 'dart:convert';
import 'package:passkeys/authenticator.dart';
import 'package:passkeys/types.dart';
import '../api/veriq_api.dart';

/// Passkeys via the platform (Android Credential Manager, iOS AuthenticationServices).
/// Requires: Digital Asset Links at https://veriq.et/.well-known/assetlinks.json (Android) and
/// webcredentials:veriq.et in Associated Domains (iOS). RP ID = veriq.et.
/// NOTE: written against passkeys 2.4.0; compile-verify with `flutter analyze` (not runnable in the build sandbox).
class PasskeyService {
  PasskeyService(this.api, {PasskeyAuthenticator? authenticator}) : _auth = authenticator ?? PasskeyAuthenticator();
  final VeriqApi api;
  final PasskeyAuthenticator _auth;

  Future<void> onboard({required String phone, required String fullName, required String birthDate}) async {
    final r = await api.post('/v1/auth/customers', {'phone': phone, 'full_name': fullName, 'birth_date': birthDate, 'accept_terms': true});
    final o = r['registration_options']! as Map<String, Object?>;
    final rp = o['rp']! as Map<String, Object?>;
    final user = o['user']! as Map<String, Object?>;
    final sel = (o['authenticatorSelection'] as Map<String, Object?>?) ?? {};
    final res = await _auth.register(RegisterRequestType(
      challenge: o['challenge']! as String,
      relyingParty: RelyingPartyType(name: rp['name']! as String, id: rp['id']! as String),
      user: UserType(displayName: user['displayName']! as String, name: user['name']! as String, id: user['id']! as String),
      authSelectionType: AuthenticatorSelectionType(
        requireResidentKey: false, residentKey: (sel['residentKey'] as String?) ?? 'preferred',
        userVerification: (sel['userVerification'] as String?) ?? 'preferred'),
      excludeCredentials: const [],
    ));
    final fin = await api.post('/v1/auth/passkey/register/finish', {
      'credential': {
        'id': res.id, 'rawId': res.rawId, 'type': 'public-key',
        'response': {'clientDataJSON': res.clientDataJSON, 'attestationObject': res.attestationObject},
        'clientExtensionResults': <String, Object?>{},
      }
    });
    await api.saveToken(fin['token']! as String);
  }

  Future<void> signIn() async {
    final o = await api.post('/v1/auth/passkey/login/begin', <String, Object?>{});
    final res = await _auth.authenticate(AuthenticateRequestType(
      relyingPartyId: o['rpId']! as String, challenge: o['challenge']! as String,
      mediation: MediationType.Optional, preferImmediatelyAvailableCredentials: false,
      userVerification: (o['userVerification'] as String?) ?? 'preferred', allowCredentials: const [],
    ));
    final fin = await api.post('/v1/auth/passkey/login/finish', {
      'credential': {
        'id': res.id, 'rawId': res.rawId, 'type': 'public-key',
        'response': {'clientDataJSON': res.clientDataJSON, 'authenticatorData': res.authenticatorData,
                     'signature': res.signature, 'userHandle': res.userHandle},
        'clientExtensionResults': <String, Object?>{},
      }
    });
    await api.saveToken(fin['token']! as String);
  }

  static String debug(Object o) => const JsonEncoder.withIndent('  ').convert(o);
}
