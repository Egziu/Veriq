import 'package:flutter/material.dart';
import '../api/veriq_api.dart';

/// One contract for every screen: loading, empty, error, offline/restricted (via ApiProblem), content.
class AsyncView<T> extends StatefulWidget {
  const AsyncView({super.key, required this.load, required this.builder, required this.emptyTitle, required this.emptyBody, this.isEmpty});
  final Future<T> Function() load;
  final Widget Function(BuildContext, T, Future<void> Function()) builder;
  final bool Function(T)? isEmpty;
  final String emptyTitle;
  final String emptyBody;
  @override
  State<AsyncView<T>> createState() => _AsyncViewState<T>();
}

class _AsyncViewState<T> extends State<AsyncView<T>> {
  late Future<T> _f = widget.load();
  Future<void> _reload() async { setState(() => _f = widget.load()); await _f.catchError((_) => _f); }

  @override
  Widget build(BuildContext context) => FutureBuilder<T>(
        future: _f,
        builder: (context, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Center(child: Semantics(label: 'Loading', child: CircularProgressIndicator()));
          }
          if (s.hasError) {
            final e = s.error;
            final msg = e is ApiProblem ? e.message : 'Something went wrong.';
            return Message(title: e is ApiProblem && e.code == 'OFFLINE' ? 'You are offline' : 'Could not load', body: msg,
                action: FilledButton(onPressed: _reload, child: const Text('Try again')));
          }
          final data = s.data as T;
          if (widget.isEmpty?.call(data) ?? false) return Message(title: widget.emptyTitle, body: widget.emptyBody);
          return RefreshIndicator(onRefresh: _reload, child: widget.builder(context, data, _reload));
        },
      );
}

class Message extends StatelessWidget {
  const Message({super.key, required this.title, required this.body, this.action});
  final String title;
  final String body;
  final Widget? action;
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(title, style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text(body, textAlign: TextAlign.center),
            if (action != null) ...[const SizedBox(height: 20), action!],
          ]),
        ),
      );
}
