import 'dart:convert';
import 'package:crypto/crypto.dart';

/// On-device verification, byte-for-byte identical to accept_entry() and packages/verifier (Python).
String receiptHash(String prev, String entryId, String competitionId, int seq, int selection, String ruleHash, String acceptedAtUtc) {
  final s = [prev, entryId, competitionId, '$seq', '$selection', ruleHash, acceptedAtUtc].join('|');
  return sha256.convert(utf8.encode(s)).toString();
}

class ChainEntry {
  ChainEntry(this.seq, this.entryId, this.selection, this.acceptedAtUtc, this.prev, this.receipt);
  final int seq;
  final String entryId;
  final int selection;
  final String acceptedAtUtc;
  final String prev;
  final String receipt;

  factory ChainEntry.fromJson(Map<String, Object?> j) => ChainEntry(
        j['seq'] as int, j['entry_id'] as String, j['selection'] as int,
        j['accepted_at_utc'] as String, j['prev_receipt_hash'] as String, j['receipt_hash'] as String);
}

class ChainVerdict {
  ChainVerdict(this.ok, this.reasons, this.winningNumber);
  final bool ok;
  final List<String> reasons;
  final int? winningNumber;
}

int? lowestUnique(Iterable<int> selections) {
  final counts = <int, int>{};
  for (final s in selections) {
    counts[s] = (counts[s] ?? 0) + 1;
  }
  final unique = counts.entries.where((e) => e.value == 1).map((e) => e.key).toList()..sort();
  return unique.isEmpty ? null : unique.first;
}

ChainVerdict verifyChain({required String competitionId, required String ruleHash, required String chainHead,
    required List<ChainEntry> entries, List<String> myReceipts = const []}) {
  final reasons = <String>[];
  var prev = '0' * 64;
  for (var i = 0; i < entries.length; i++) {
    final e = entries[i];
    if (e.seq != i + 1) { reasons.add('Sequence gap at ${e.seq}'); break; }
    if (e.prev != prev) { reasons.add('Chain broken at entry ${e.seq}'); break; }
    if (receiptHash(prev, e.entryId, competitionId, e.seq, e.selection, ruleHash, e.acceptedAtUtc) != e.receipt) {
      reasons.add('Entry ${e.seq} does not match its receipt'); break;
    }
    prev = e.receipt;
  }
  if (reasons.isEmpty && prev != chainHead) reasons.add('Chain head mismatch');
  final present = entries.map((e) => e.receipt).toSet();
  final missing = myReceipts.where((r) => !present.contains(r)).length;
  if (missing > 0) reasons.add('$missing of your receipts are missing — open a dispute');
  return ChainVerdict(reasons.isEmpty, reasons, lowestUnique(entries.map((e) => e.selection)));
}
