import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'api/veriq_api.dart';
import 'auth/passkey_service.dart';
import 'core/theme.dart';
import 'screens/account_screens.dart';
import 'screens/campaigns_screen.dart';
import 'screens/welcome_screen.dart';

const _api = String.fromEnvironment('VERIQ_API', defaultValue: 'https://api.veriq.et');
const _entity = String.fromEnvironment('VERIQ_ENTITY');

void main() {
  assert(_api.startsWith('https://'), 'VERIQ_API must be https');
  runApp(VeriqApp(api: VeriqApi(baseUrl: _api, entity: _entity)));
}

class VeriqApp extends StatefulWidget {
  const VeriqApp({super.key, required this.api});
  final VeriqApi api;
  @override
  State<VeriqApp> createState() => _VeriqAppState();
}

class _VeriqAppState extends State<VeriqApp> {
  bool? _signedIn;
  @override
  void initState() { super.initState(); widget.api.token.then((t) => setState(() => _signedIn = t != null)); }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'VERIQ',
        theme: veriqTheme(Brightness.light),
        darkTheme: veriqTheme(Brightness.dark),
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        supportedLocales: const [Locale('en'), Locale('am')],   // ti/om pending human-reviewed translations
        home: switch (_signedIn) {
          null => const Scaffold(body: Center(child: CircularProgressIndicator())),
          false => WelcomeScreen(passkeys: PasskeyService(widget.api), onSignedIn: () => setState(() => _signedIn = true)),
          true => HomeShell(api: widget.api, onSignedOut: () => setState(() => _signedIn = false)),
        },
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.api, required this.onSignedOut});
  final VeriqApi api;
  final VoidCallback onSignedOut;
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;
  @override
  Widget build(BuildContext context) {
    final channel = Platform.isIOS ? 'IOS' : 'ANDROID';
    final pages = [
      CampaignsScreen(api: widget.api, channel: channel),
      ReceiptsScreen(api: widget.api),
      PrizeScreen(api: widget.api),
      SettingsScreen(api: widget.api, onSignedOut: widget.onSignedOut),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('VERIQ')),
      body: SafeArea(child: pages[_i]),
      bottomNavigationBar: NavigationBar(selectedIndex: _i, onDestinationSelected: (i) => setState(() => _i = i), destinations: const [
        NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'Campaigns'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Receipts'),
        NavigationDestination(icon: Icon(Icons.card_giftcard_outlined), label: 'My prize'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
      ]),
    );
  }
}
