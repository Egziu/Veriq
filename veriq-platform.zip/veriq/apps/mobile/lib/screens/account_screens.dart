import 'package:flutter/material.dart';
import '../api/veriq_api.dart';
import '../core/async_view.dart';

class ReceiptsScreen extends StatelessWidget {
  const ReceiptsScreen({super.key, required this.api});
  final VeriqApi api;
  @override
  Widget build(BuildContext context) => AsyncView<List<Map<String, Object?>>>(
        load: api.myEntries, isEmpty: (l) => l.isEmpty,
        emptyTitle: 'No entries yet', emptyBody: 'Your receipts appear here the moment an entry is accepted.',
        builder: (context, l, _) => ListView(children: [
          for (final e in l)
            ListTile(title: Text('${e['title']} · entry #${e['seq']}'), subtitle: Text('Number ${e['selection']} · ${e['channel']}'),
                trailing: Text((e['receipt_hash']! as String).substring(0, 10))),
        ]),
      );
}

class PrizeScreen extends StatelessWidget {
  const PrizeScreen({super.key, required this.api});
  final VeriqApi api;
  static const _label = {'OPENED': 'Claim received', 'APPROVED': 'Identity confirmed', 'ALLOCATED': 'Prize reserved',
    'DISPATCHED': 'On its way', 'DELIVERED': 'Handed over', 'REJECTED': 'Not approved — contact support', 'EXPIRED': 'Claim period ended'};
  @override
  Widget build(BuildContext context) => AsyncView<List<Map<String, Object?>>>(
        load: api.myClaims, isEmpty: (l) => l.isEmpty,
        emptyTitle: 'No prize claims', emptyBody: 'If one of your entries wins, claim it here. VERIQ never asks for payment to release a prize.',
        builder: (context, l, _) => ListView(children: [
          for (final c in l)
            ListTile(title: Text(c['title']! as String), subtitle: Text(_label[c['state']] ?? c['state']! as String),
                trailing: c['tracking_ref'] == null ? null : Text('${c['carrier']}\n${c['tracking_ref']}', textAlign: TextAlign.end)),
        ]),
      );
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.api, required this.onSignedOut});
  final VeriqApi api;
  final VoidCallback onSignedOut;
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String? _note;
  Future<void> _do(Future<String> Function() f) async {
    try { final m = await f(); setState(() => _note = m); } on ApiProblem catch (e) { setState(() => _note = e.message); }
  }

  Future<void> _exclude() async {
    final days = await showDialog<int>(context: context, builder: (c) => SimpleDialog(title: const Text('Take a break'), children: [
          const Padding(padding: EdgeInsets.symmetric(horizontal: 24), child: Text('Entries are blocked on every channel. A break cannot be shortened once started.')),
          for (final d in [7, 30, 180, 365]) SimpleDialogOption(onPressed: () => Navigator.pop(c, d), child: Text('$d days')),
        ]));
    if (days != null) await _do(() async => 'Break active until ${(await widget.api.selfExclude(days))['self_excluded_until']}.');
  }

  @override
  Widget build(BuildContext context) => ListView(children: [
        ListTile(leading: const Icon(Icons.link), title: const Text('Link Telegram'), subtitle: const Text('Get a one-time code for the VERIQ bot'),
            onTap: () => _do(() async { final r = await widget.api.telegramLinkCode(); return 'Send /link ${r['code']} to the VERIQ bot within 5 minutes.'; })),
        ListTile(leading: const Icon(Icons.pause_circle_outline), title: const Text('Take a break'), onTap: _exclude),
        ListTile(leading: const Icon(Icons.logout), title: const Text('Sign out on all devices'),
            onTap: () async { await widget.api.signOutEverywhere(); widget.onSignedOut(); }),
        if (_note != null) Padding(padding: const EdgeInsets.all(16), child: SelectableText(_note!)),
      ]);
}
