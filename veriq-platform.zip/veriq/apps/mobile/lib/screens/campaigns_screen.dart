import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../api/veriq_api.dart';
import '../core/async_view.dart';
import 'verify_screen.dart';

class CampaignsScreen extends StatelessWidget {
  const CampaignsScreen({super.key, required this.api, required this.channel});
  final VeriqApi api;
  final String channel;
  @override
  Widget build(BuildContext context) => AsyncView<List<Map<String, Object?>>>(
        load: api.competitions,
        isEmpty: (l) => l.isEmpty,
        emptyTitle: 'No campaigns right now',
        emptyBody: 'New sponsor campaigns appear here. Paid competitions are not offered where VERIQ lacks written approval.',
        builder: (context, list, _) => ListView(padding: const EdgeInsets.all(16), children: [
          for (final c in list)
            Card(
              child: ListTile(
                title: Text(c['title']! as String),
                subtitle: Text('${c['state'] == 'OPEN' ? 'Open' : c['state'] == 'RESULT_PUBLISHED' ? 'Result published' : 'Closed'}'
                    ' · ${c['product_type'] == 'SPONSOR_FREE' ? 'Free' : 'Not available'} · prize ${c['prize_secured'] == true ? 'secured' : 'not secured'}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => CampaignScreen(api: api, c: c, channel: channel))),
              ),
            ),
        ]),
      );
}

class CampaignScreen extends StatefulWidget {
  const CampaignScreen({super.key, required this.api, required this.c, required this.channel});
  final VeriqApi api;
  final Map<String, Object?> c;
  final String channel;
  @override
  State<CampaignScreen> createState() => _CampaignScreenState();
}

class _CampaignScreenState extends State<CampaignScreen> {
  int? _pick;
  String? _idem;            // one key per intended entry; reused on retry
  bool _busy = false;
  Map<String, Object?>? _receipt;
  String? _error;

  Future<void> _submit() async {
    final online = !(await Connectivity().checkConnectivity()).contains(ConnectivityResult.none);
    if (!online) { setState(() => _error = 'Not submitted. You are offline — VERIQ never queues an entry as if it were accepted.'); return; }
    _idem ??= const Uuid().v4();
    setState(() { _busy = true; _error = null; });
    try {
      final r = await widget.api.submitEntry(widget.c['id']! as String, _pick!, _idem!, widget.channel);
      setState(() { _receipt = r; _idem = null; _pick = null; });
    } on ApiProblem catch (e) {
      setState(() => _error = e.code == 'OFFLINE'
          ? 'Status unknown. We kept your request key; tap Submit again to check — it cannot create a second entry.'
          : e.message);
    } finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.c, t = Theme.of(context).textTheme, open = c['state'] == 'OPEN' && c['product_type'] == 'SPONSOR_FREE';
    final lo = c['number_min']! as int, hi = c['number_max']! as int;
    return Scaffold(
      appBar: AppBar(title: Text(c['title']! as String)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('How the winner is chosen', style: t.titleMedium),
          const SizedBox(height: 6),
          Text('Pick a whole number from $lo to $hi. When entries close, the lowest number picked by exactly one entry wins. '
              'Up to ${c['per_customer_cap']} entries per person across app, web and Telegram. If no number is unique, there is no winner.'),
          const SizedBox(height: 8),
          Text('Rule version ${(c['rule_hash']! as String).substring(0, 12)}', style: t.bodySmall),
        ]))),
        if (_receipt != null) _ReceiptCard(r: _receipt!),
        if (!open && c['state'] != 'OPEN') ...[
          const SizedBox(height: 16),
          FilledButton.tonal(onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => VerifyScreen(api: widget.api, competitionId: c['id']! as String))), child: const Text('Check the result')),
        ],
        if (open && _receipt == null) ...[
          const SizedBox(height: 16),
          Text('Choose a number', style: t.titleMedium),
          const SizedBox(height: 8),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (var n = lo; n <= (hi - lo > 99 ? lo + 99 : hi); n++)
              ChoiceChip(label: Text('$n'), selected: _pick == n, onSelected: _busy ? null : (_) => setState(() { _pick = n; _idem = null; })),
          ]),
          if (_pick != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text('Your number: $_pick · Free · no payment is taken')),
          const SizedBox(height: 12),
          FilledButton(onPressed: _pick == null || _busy ? null : _submit, child: Text(_busy ? 'Submitting…' : 'Submit entry')),
        ],
        if (_error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
      ]),
    );
  }
}

class _ReceiptCard extends StatelessWidget {
  const _ReceiptCard({required this.r});
  final Map<String, Object?> r;
  @override
  Widget build(BuildContext context) {
    final gold = Theme.of(context).colorScheme.primary;
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: gold, width: 1.5)),
      child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Accepted entry #${r['seq']}', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: gold)),
        const SizedBox(height: 6),
        SelectableText('Receipt ${(r['receipt_hash']! as String).substring(0, 16)}…'),
        Text('Accepted ${r['accepted_at']}'),
        const SizedBox(height: 6),
        const Text('Accepted is not the same as winning. Results appear only after the close and an independent check.'),
      ])),
    );
  }
}
