import 'package:flutter/material.dart';
import '../api/veriq_api.dart';
import '../core/async_view.dart';
import '../core/receipt_chain.dart';

/// Re-checks the published result ON THIS DEVICE: recomputes every receipt, the chain head, and the winner,
/// and confirms the user's own receipts are in the published list.
class VerifyScreen extends StatelessWidget {
  const VerifyScreen({super.key, required this.api, required this.competitionId});
  final VeriqApi api;
  final String competitionId;

  Future<(Map<String, Object?>, ChainVerdict)> _load() async {
    final m = await api.manifest(competitionId);
    final mine = (await api.myEntries()).where((e) => e['competition_id'] == competitionId).map((e) => e['receipt_hash']! as String).toList();
    final man = m['manifest']! as Map<String, Object?>;
    final entries = (man['entries']! as List).cast<Map<String, Object?>>().map(ChainEntry.fromJson).toList();
    return (m, verifyChain(competitionId: competitionId, ruleHash: man['rule_hash']! as String, chainHead: man['chain_head']! as String,
        entries: entries, myReceipts: mine));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Verify the result')),
        body: AsyncView<(Map<String, Object?>, ChainVerdict)>(
          load: _load,
          emptyTitle: '', emptyBody: '',
          builder: (context, d, _) {
            final (m, v) = d;
            final claimed = m['winning_number'] as int?;
            final agrees = v.ok && v.winningNumber == claimed;
            final c = Theme.of(context).colorScheme;
            return ListView(padding: const EdgeInsets.all(16), children: [
              Text(claimed == null ? 'No winner this time' : 'Winning number: $claimed', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 12),
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: agrees ? c.primary : c.error, width: 1.5)),
                child: ListTile(
                  leading: Icon(agrees ? Icons.verified_outlined : Icons.report_outlined, color: agrees ? c.primary : c.error),
                  title: Text(agrees ? 'Checked on your phone' : 'Check failed'),
                  subtitle: Text(agrees
                      ? 'Every receipt links to the one before it, and the winner matches the rule.'
                      : [...v.reasons, if (v.winningNumber != claimed) 'Recomputed winner differs from the published one'].join('\n')),
                ),
              ),
              ListTile(title: const Text('Witnessed by'), subtitle: Text(((m['witness_receipts'] as List?) ?? const [])
                  .map((w) => '${(w as Map)['tsa_name']} at ${w['gen_time']}').join('\n').ifEmpty('No external witness recorded'))),
            ]);
          },
        ),
      );
}

extension on String {
  String ifEmpty(String other) => isEmpty ? other : this;
}
