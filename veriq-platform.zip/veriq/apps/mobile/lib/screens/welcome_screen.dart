import 'package:flutter/material.dart';
import '../api/veriq_api.dart';
import '../auth/passkey_service.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key, required this.passkeys, required this.onSignedIn});
  final PasskeyService passkeys;
  final VoidCallback onSignedIn;
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final _form = GlobalKey<FormState>();
  final _phone = TextEditingController(), _name = TextEditingController(), _birth = TextEditingController();
  bool _consent = false, _busy = false, _creating = false;
  String? _error;

  Future<void> _run(Future<void> Function() f) async {
    setState(() { _busy = true; _error = null; });
    try { await f(); widget.onSignedIn(); }
    on ApiProblem catch (e) { setState(() => _error = e.message); }
    catch (_) { setState(() => _error = 'The passkey step was cancelled or failed. Try again.'); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          const SizedBox(height: 24),
          Text('VERIQ', style: t.displaySmall?.copyWith(fontWeight: FontWeight.w600, letterSpacing: 4)),
          Text('Trust in every win', style: t.titleMedium),
          const SizedBox(height: 20),
          Text('Free sponsor campaigns with published rules, a secured prize, and a result anyone can check.', style: t.bodyLarge),
          const SizedBox(height: 28),
          if (!_creating) ...[
            FilledButton(onPressed: _busy ? null : () => setState(() => _creating = true), child: const Text('Create account')),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _busy ? null : () => _run(widget.passkeys.signIn), child: const Text('Sign in with passkey')),
          ] else
            Form(
              key: _form,
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text('We ask for your phone, name and date of birth to confirm you are 18 or older and to protect your prize. '
                    'They are encrypted and never shown to sponsors.', style: t.bodyMedium),
                const SizedBox(height: 12),
                TextFormField(controller: _phone, keyboardType: TextInputType.phone, autofillHints: const [AutofillHints.telephoneNumber],
                    decoration: const InputDecoration(labelText: 'Ethiopian mobile number', hintText: '09… or 07…'),
                    validator: (v) => (v ?? '').replaceAll(RegExp(r'\D'), '').length < 9 ? 'Enter your mobile number' : null),
                TextFormField(controller: _name, autofillHints: const [AutofillHints.name], decoration: const InputDecoration(labelText: 'Full name'),
                    validator: (v) => (v ?? '').trim().length < 2 ? 'Enter your name' : null),
                TextFormField(controller: _birth, keyboardType: TextInputType.datetime, decoration: const InputDecoration(labelText: 'Date of birth (YYYY-MM-DD)'),
                    validator: (v) => RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(v ?? '') ? null : 'Use YYYY-MM-DD'),
                CheckboxListTile(value: _consent, onChanged: (v) => setState(() => _consent = v ?? false), contentPadding: EdgeInsets.zero,
                    title: const Text('I have read the terms and privacy notice')),
                FilledButton(
                  onPressed: _busy || !_consent ? null : () { if (_form.currentState!.validate()) {
                    _run(() => widget.passkeys.onboard(phone: _phone.text, fullName: _name.text.trim(), birthDate: _birth.text));
                  } },
                  child: const Text('Create passkey'),
                ),
              ]),
            ),
          if (_error != null) Padding(padding: const EdgeInsets.only(top: 16), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        ]),
      ),
    );
  }
}
