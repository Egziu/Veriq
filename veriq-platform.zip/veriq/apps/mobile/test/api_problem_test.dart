import 'package:flutter_test/flutter_test.dart';
import 'package:veriq/api/veriq_api.dart';

void main() {
  test('offline never implies acceptance', () {
    expect(const ApiProblem('OFFLINE', '', 0).message, contains('Nothing was submitted'));
  });
  test('country gate codes map to a plain restriction message', () {
    for (final c in ['DENIED_COUNTRY', 'DENIED_PRODUCT', 'EXPIRED_SCOPE']) {
      expect(ApiProblem(c, '', 403).message, 'This is not available where you are.');
    }
  });
}
