import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:veriq/core/async_view.dart';
import 'package:veriq/api/veriq_api.dart';

void main() {
  testWidgets('AsyncView shows offline state with retry', (t) async {
    await t.pumpWidget(MaterialApp(home: Scaffold(body: AsyncView<List<int>>(
      load: () async => throw const ApiProblem('OFFLINE', '', 0), emptyTitle: 'Empty', emptyBody: '', builder: (_, __, ___) => const Text('content')))));
    await t.pumpAndSettle();
    expect(find.text('You are offline'), findsOneWidget);
    expect(find.text('Try again'), findsOneWidget);
  });
  testWidgets('AsyncView shows empty state', (t) async {
    await t.pumpWidget(MaterialApp(home: Scaffold(body: AsyncView<List<int>>(
      load: () async => <int>[], isEmpty: (l) => l.isEmpty, emptyTitle: 'No entries yet', emptyBody: 'b', builder: (_, __, ___) => const Text('content')))));
    await t.pumpAndSettle();
    expect(find.text('No entries yet'), findsOneWidget);
  });
}
