"use client";
import { useEffect, useState } from "react";
import { api, explain, type MyClaim } from "@/lib/api";

const STEPS = ["OPENED", "APPROVED", "ALLOCATED", "DISPATCHED", "DELIVERED"] as const;
const LABEL: Record<string, string> = { OPENED: "Claim received", APPROVED: "Identity confirmed", ALLOCATED: "Prize reserved", DISPATCHED: "On its way", DELIVERED: "Handed over" };

export default function Claims() {
  const [rows, setRows] = useState<MyClaim[] | null>(null);
  const [msg, setMsg] = useState("");
  useEffect(() => { api<MyClaim[]>("/v1/me/claims").then(setRows).catch(e => setMsg(explain(e))); }, []);

  async function save(id: string, f: FormData) {
    try {
      await api(`/v1/claims/${id}/address`, { method: "PUT", body: JSON.stringify(Object.fromEntries(f)) });
      setMsg("Address saved. It is encrypted and only the delivery team can read it.");
    } catch (e) { setMsg(explain(e)); }
  }

  return (
    <>
      <h1>My prize</h1>
      <p className="muted">VERIQ will never ask you to pay to receive a prize.</p>
      {msg && <div className="alert ok" role="status">{msg}</div>}
      {rows?.length === 0 && <div className="panel"><h2>No prize claims</h2><p className="muted">If one of your entries wins, you can claim it here after the verified result is published.</p></div>}
      {rows?.map(c => {
        const at = STEPS.indexOf(c.state as (typeof STEPS)[number]);
        return (
          <div className="panel" key={c.id}><h2>{c.title}</h2>
            <ol style={{ paddingLeft: 18 }}>{STEPS.map((s, i) => (
              <li key={s} style={{ color: i <= at ? "inherit" : "var(--muted)" }}>
                {LABEL[s]}{s === c.state ? " (current)" : ""}{s === "DISPATCHED" && c.tracking_ref ? `: ${c.carrier} ${c.tracking_ref}` : ""}
              </li>))}</ol>
            {["OPENED", "APPROVED", "ALLOCATED"].includes(c.state) && (
              <form onSubmit={e => { e.preventDefault(); void save(c.id, new FormData(e.currentTarget)); }}>
                <label htmlFor={`r-${c.id}`}>Recipient name</label><input id={`r-${c.id}`} name="recipient" required maxLength={120} />
                <label htmlFor={`p-${c.id}`}>Phone</label><input id={`p-${c.id}`} name="phone" required inputMode="tel" maxLength={20} />
                <label htmlFor={`c-${c.id}`}>City</label><input id={`c-${c.id}`} name="city" required maxLength={60} />
                <label htmlFor={`d-${c.id}`}>Address details</label><textarea id={`d-${c.id}`} name="details" required maxLength={300} />
                <p><button className="btn">Save delivery address</button></p>
              </form>)}
            <p className="muted">Claim deadline {new Date(c.deadline).toLocaleDateString()}.</p>
          </div>);
      })}
    </>
  );
}
