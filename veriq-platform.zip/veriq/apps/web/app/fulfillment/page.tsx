"use client";
import { useCallback, useEffect, useState } from "react";
import { api, explain, sha256Hex, type Claim } from "@/lib/api";

export default function Fulfillment() {
  const [rows, setRows] = useState<Claim[] | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const load = useCallback(() => { api<Claim[]>("/v1/staff/claims").then(setRows).catch(e => setMsg({ ok: false, text: explain(e) })); }, []);
  useEffect(() => { load(); }, [load]);

  async function act(path: string, body: object, done: string) {
    setMsg(null);
    try { await api(path, { method: "POST", body: JSON.stringify(body) }); setMsg({ ok: true, text: done }); load(); }
    catch (e) { setMsg({ ok: false, text: explain(e) }); }
  }

  async function confirm(c: Claim, form: HTMLFormElement) {
    const f = new FormData(form);
    const sig = f.get("sig"), photo = f.get("photo");
    if (!(sig instanceof File) || !sig.size || !(photo instanceof File) || !photo.size) {
      setMsg({ ok: false, text: "Attach the recipient signature and the handover photo." }); return;
    }
    await act(`/v1/staff/claims/${c.id}/delivered`, {
      scanned_serial: String(f.get("serial") ?? ""),
      recipient_signature_sha256: await sha256Hex(sig), handover_photo_sha256: await sha256Hex(photo),
    }, "Delivery confirmed and posted to the ledger.");
  }

  return (
    <>
      <h1>Claims and delivery</h1>
      <p className="muted">Each step needs a different role. Delivery must be confirmed by someone other than the person who dispatched it.</p>
      {msg && <div className={`alert ${msg.ok ? "ok" : ""}`} role="status">{msg.text}</div>}
      {rows === null && <p className="muted">Loading claims…</p>}
      {rows?.length === 0 && <div className="panel"><h2>No open claims</h2><p className="muted">Claims appear after a verified result is published and the winner opens a claim.</p></div>}
      {rows?.map(c => (
        <div className="panel" key={c.id}>
          <div className="row" style={{ justifyContent: "space-between" }}><h2>{c.title}</h2><span className="chip">{c.state}</span></div>
          <p className="muted">Claim {c.id.slice(0, 8)}, deadline {new Date(c.deadline).toLocaleDateString()}{c.serial ? `, ${c.model} serial ${c.serial}` : ""}{c.tracking_ref ? `, ${c.carrier} ${c.tracking_ref}` : ""}</p>
          {c.state === "OPENED" && (
            <div className="row">
              <button className="btn" onClick={() => act(`/v1/staff/claims/${c.id}/review`, { approve: true, note: "Identity verified in person" }, "Identity approved.")}>Approve identity</button>
              <button className="btn secondary" onClick={() => act(`/v1/staff/claims/${c.id}/review`, { approve: false, note: "Identity not verified" }, "Claim rejected.")}>Reject</button>
            </div>)}
          {c.state === "APPROVED" && (
            <form className="row" onSubmit={e => { e.preventDefault(); act(`/v1/staff/claims/${c.id}/allocate`, { prize_item_id: String(new FormData(e.currentTarget).get("item")) }, "Prize allocated."); }}>
              <div style={{ flex: 1 }}><label htmlFor={`i-${c.id}`}>Prize item ID (from stock)</label><input id={`i-${c.id}`} name="item" required /></div>
              <button className="btn">Allocate prize</button>
            </form>)}
          {c.state === "ALLOCATED" && (
            <form className="row" onSubmit={e => { e.preventDefault(); const f = new FormData(e.currentTarget);
              act(`/v1/staff/claims/${c.id}/dispatch`, { carrier: String(f.get("carrier")), tracking_ref: String(f.get("trk")) }, "Dispatched."); }}>
              <div><label htmlFor={`c-${c.id}`}>Carrier</label><input id={`c-${c.id}`} name="carrier" required /></div>
              <div><label htmlFor={`t-${c.id}`}>Tracking reference</label><input id={`t-${c.id}`} name="trk" required /></div>
              <button className="btn">Mark dispatched</button>
            </form>)}
          {c.state === "DISPATCHED" && (
            <form className="row" onSubmit={e => { e.preventDefault(); void confirm(c, e.currentTarget); }}>
              <div><label htmlFor={`s-${c.id}`}>Scanned serial</label><input id={`s-${c.id}`} name="serial" required autoComplete="off" /></div>
              <div><label htmlFor={`g-${c.id}`}>Recipient signature</label><input id={`g-${c.id}`} name="sig" type="file" accept="image/*" required /></div>
              <div><label htmlFor={`p-${c.id}`}>Handover photo</label><input id={`p-${c.id}`} name="photo" type="file" accept="image/*" capture="environment" required /></div>
              <button className="btn">Confirm delivery</button>
            </form>)}
          {c.state === "DELIVERED" && <p>Delivered {c.delivered_at ? new Date(c.delivered_at).toLocaleString() : ""}.</p>}
        </div>))}
    </>
  );
}
