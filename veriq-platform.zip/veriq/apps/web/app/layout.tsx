import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const dynamic = "force-dynamic"; // nonce CSP requires per-request rendering

export const metadata: Metadata = { title: "VERIQ portals", description: "Trust in every win" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600&family=IBM+Plex+Sans:wght@400;500;600&family=Noto+Sans+Ethiopic:wght@400;600&display=swap" rel="stylesheet" />
      </head>
      <body>
        <header>
          <b>VERIQ</b>
          <nav aria-label="Portals">
            <Link href="/claims">My prize</Link><Link href="/sponsor">Sponsor</Link>
            <Link href="/fulfillment">Claims and delivery</Link><Link href="/login">Sign in</Link>
          </nav>
        </header>
        <main>{children}</main>
      </body>
    </html>
  );
}
