"use client";
import { useState } from "react";
import { startAuthentication, type PublicKeyCredentialRequestOptionsJSON } from "@simplewebauthn/browser";
import { api, explain, type Session } from "@/lib/api";

export default function Login() {
  const [state, setState] = useState<"idle" | "waiting" | "done" | "error">("idle");
  const [msg, setMsg] = useState("");

  async function signIn(kind: "customer" | "staff") {
    setState("waiting"); setMsg("");
    try {
      const options = await api<PublicKeyCredentialRequestOptionsJSON>("/v1/auth/passkey/login/begin", { method: "POST", body: JSON.stringify({ kind }) });
      const credential = await startAuthentication({ optionsJSON: options });
      const s = await api<Session>("/v1/auth/passkey/login/finish", { method: "POST", body: JSON.stringify({ credential }) });
      setState("done");
      setMsg(s.kind === "staff" ? "Signed in. Staff sessions end after 30 minutes." : "Signed in.");
    } catch (e) {
      setState("error");
      setMsg(e instanceof Error && e.name === "NotAllowedError" ? "Sign-in was cancelled." : explain(e));
    }
  }

  return (
    <>
      <h1>Sign in</h1>
      <p className="muted">VERIQ uses passkeys: your phone or security key confirms it&apos;s you. No passwords, no codes by SMS.</p>
      <div className="panel row">
        <button className="btn" disabled={state === "waiting"} onClick={() => signIn("customer")}>Sign in with passkey</button>
        <button className="btn secondary" disabled={state === "waiting"} onClick={() => signIn("staff")}>Staff sign in</button>
      </div>
      {msg && <div className={`alert ${state === "done" ? "ok" : ""}`} role="status">{msg}</div>}
    </>
  );
}
