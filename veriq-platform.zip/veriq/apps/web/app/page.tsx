import Link from "next/link";

export default function Home() {
  return (
    <>
      <h1>VERIQ portals</h1>
      <p className="muted">Sign in with a passkey. Each portal shows only what your role is allowed to see.</p>
      <div className="panel"><h2>Winners</h2><p className="muted">Track your prize, add a delivery address, and see handover progress.</p><Link className="btn" href="/claims">Open my prize</Link></div>
      <div className="panel"><h2>Sponsors</h2><p className="muted">Campaign status and privacy-safe totals. Participant identities are never shown.</p><Link className="btn secondary" href="/sponsor">Open sponsor portal</Link></div>
      <div className="panel"><h2>Operations</h2><p className="muted">Identity review, prize allocation, dispatch and dual-control delivery.</p><Link className="btn secondary" href="/fulfillment">Open claims and delivery</Link></div>
    </>
  );
}
