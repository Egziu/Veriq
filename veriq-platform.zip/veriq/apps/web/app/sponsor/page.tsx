"use client";
import { useEffect, useState } from "react";
import { api, explain, type SponsorCampaign, type SponsorReport } from "@/lib/api";

const n = (v: number | null) => (v === null ? "Fewer than 10" : v.toLocaleString());

export default function Sponsor() {
  const [list, setList] = useState<SponsorCampaign[] | null>(null);
  const [report, setReport] = useState<SponsorReport | null>(null);
  const [err, setErr] = useState("");

  useEffect(() => { api<SponsorCampaign[]>("/v1/sponsor/competitions").then(setList).catch(e => setErr(explain(e))); }, []);
  const open = (id: string) => api<SponsorReport>(`/v1/sponsor/competitions/${id}/report`).then(setReport).catch(e => setErr(explain(e)));

  return (
    <>
      <h1>Sponsor portal</h1>
      <p className="muted">Totals only. Any number under 10 is hidden so no participant can be identified.</p>
      {err && <div className="alert" role="alert">{err}</div>}
      {list === null && !err && <p className="muted">Loading campaigns…</p>}
      {list?.length === 0 && <div className="panel"><h2>No campaigns yet</h2><p className="muted">Campaigns appear here once VERIQ links them to your sponsorship contract.</p></div>}
      {list && list.length > 0 && (
        <div className="panel table"><table>
          <thead><tr><th>Campaign</th><th>Status</th><th>Closes</th><th /></tr></thead>
          <tbody>{list.map(c => (
            <tr key={c.id}><td>{c.title}</td><td><span className="chip">{c.state}</span></td><td>{new Date(c.closes_at).toLocaleString()}</td>
              <td><button className="btn secondary" onClick={() => open(c.id)}>View report</button></td></tr>))}
          </tbody></table></div>
      )}
      {report && (
        <div className="panel"><h2>{report.title}</h2>
          <div className="stats">
            <div><b>{n(report.entries)}</b><span className="muted">Entries</span></div>
            <div><b>{n(report.entrants)}</b><span className="muted">Entrants</span></div>
            <div><b>{report.prize_secured ? "Secured" : "Not secured"}</b><span className="muted">Prize</span></div>
            <div><b>{report.delivered ? "Delivered" : "Pending"}</b><span className="muted">Handover</span></div>
          </div>
          <p className="muted" style={{ marginTop: 12 }}>By channel: {Object.entries(report.by_channel).map(([k, v]) => `${k} ${n(v)}`).join(", ") || "no entries yet"}</p>
        </div>
      )}
    </>
  );
}
