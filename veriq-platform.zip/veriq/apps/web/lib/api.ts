// Typed client for the VERIQ core API (mirrors openapi/veriq-core.v1.json). Cookie session + double-submit CSRF.
export const API = process.env.NEXT_PUBLIC_VERIQ_API ?? "https://api.veriq.et";
export const ENTITY = process.env.NEXT_PUBLIC_VERIQ_ENTITY ?? "";

export type Problem = { code: string; detail: string; status: number; request_id?: string };
export class ApiError extends Error {
  constructor(public problem: Problem) { super(problem.detail); }
}

function csrf(): string {
  const m = typeof document !== "undefined" ? document.cookie.match(/(?:^|; )vq_csrf=([^;]+)/) : null;
  return m?.[1] ? decodeURIComponent(m[1]) : "";
}

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("Content-Type", "application/json");
  headers.set("X-Entity", ENTITY);
  if (init.method && init.method !== "GET") headers.set("X-CSRF-Token", csrf());
  const r = await fetch(`${API}${path}`, { ...init, headers, credentials: "include", cache: "no-store" });
  if (!r.ok) {
    let p: Problem = { code: "NETWORK", detail: `Request failed (${r.status})`, status: r.status };
    try { p = (await r.json()) as Problem; } catch { /* keep default */ }
    throw new ApiError(p);
  }
  return (await r.json()) as T;
}

export type Claim = {
  id: string; competition_id: string; state: string; title: string; deadline: string;
  prize_item_id: string | null; serial: string | null; model: string | null; carrier: string | null;
  tracking_ref: string | null; dispatched_by: string | null; delivered_at: string | null;
};
export type MyClaim = { id: string; state: string; deadline: string; title: string; carrier: string | null; tracking_ref: string | null; delivered_at: string | null };
export type SponsorCampaign = { id: string; title: string; state: string; closes_at: string };
export type SponsorReport = {
  ok: boolean; title: string; state: string; entries: number | null; entrants: number | null;
  by_channel: Record<string, number | null>; suppression_threshold: number; prize_secured: boolean; delivered: boolean;
};
export type Session = { principal_id: string; kind: "customer" | "staff" };

export async function sha256Hex(file: File): Promise<string> {
  const d = await crypto.subtle.digest("SHA-256", await file.arrayBuffer());
  return Array.from(new Uint8Array(d)).map(b => b.toString(16).padStart(2, "0")).join("");
}

export const messages: Record<string, string> = {
  ROLE_NOT_HELD: "Your role can't do this. Ask someone with the right role.",
  DUAL_CONTROL_REQUIRED: "A different team member from the one who dispatched must confirm delivery.",
  SERIAL_MISMATCH: "The scanned serial doesn't match the allocated prize. Check the device before handing it over.",
  CLAIM_NOT_APPROVED: "Approve the winner's identity before allocating a prize.",
  ITEM_NOT_AVAILABLE: "That item isn't in stock for this campaign.",
  CSRF_FAILED: "Your session check failed. Reload the page and try again.",
  UNAUTHENTICATED: "Your session ended. Sign in again with your passkey.",
  AUTH_FAILED: "That passkey couldn't be verified. Try again, or use another registered device.",
  NOT_FOUND: "Not found, or not available to your account.",
};

export function explain(e: unknown): string {
  if (e instanceof ApiError) return `${messages[e.problem.code] ?? e.problem.detail} (ref ${e.problem.request_id ?? "—"})`;
  return "Something went wrong. Try again.";
}
