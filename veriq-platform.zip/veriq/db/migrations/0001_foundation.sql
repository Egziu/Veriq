-- VERIQ 0001 — foundation: roles, tenancy, country/product gate, rules, competitions, entries.
-- Design rule: critical tables are written ONLY through SECURITY DEFINER command functions.
-- The application role holds SELECT (under RLS) and EXECUTE; it never owns tables and never BYPASSRLS.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='veriq_owner') THEN
    CREATE ROLE veriq_owner NOLOGIN NOBYPASSRLS; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='veriq_app') THEN
    CREATE ROLE veriq_app LOGIN NOBYPASSRLS NOSUPERUSER NOCREATEDB NOCREATEROLE; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='veriq_auditor') THEN
    CREATE ROLE veriq_auditor LOGIN NOBYPASSRLS NOSUPERUSER; END IF;
END $$;

CREATE SCHEMA veriq AUTHORIZATION veriq_owner;
REVOKE ALL ON SCHEMA veriq FROM PUBLIC;
GRANT USAGE ON SCHEMA veriq TO veriq_app, veriq_auditor;
SET ROLE veriq_owner;
SET search_path = veriq, public;

-- Entity context: set by trusted server code with SET LOCAL from verified claims, per transaction.
CREATE FUNCTION current_entity() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT nullif(current_setting('veriq.entity_id', true), '')::uuid $$;
CREATE FUNCTION current_actor() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT nullif(current_setting('veriq.actor_id', true), '')::uuid $$;

CREATE FUNCTION forbid_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'IMMUTABLE_RECORD: % on % is forbidden', TG_OP, TG_TABLE_NAME USING ERRCODE='VQ900'; END $$;

-- ---------- Organization ----------
CREATE TABLE countries (code char(2) PRIMARY KEY CHECK (code ~ '^[A-Z]{2}$'), name text NOT NULL);
CREATE TABLE legal_entities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL, country_code char(2) NOT NULL REFERENCES countries,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, country_code));

CREATE TABLE staff_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL REFERENCES legal_entities,
  display_name text NOT NULL,
  roles text[] NOT NULL CHECK (roles <@ ARRAY['CEO','CFO','CTO','COMPLIANCE','DEPLOYMENT','COMP_OPS','FINANCE','SUPPORT','FRAUD','AUDITOR','INFRA_ADMIN']::text[]),
  active boolean NOT NULL DEFAULT true,
  UNIQUE (id, legal_entity_id));

-- ---------- Country / product authorization (go/no-go control plane) ----------
CREATE TABLE country_product_authorizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL,
  country_code char(2) NOT NULL,
  product_type text NOT NULL CHECK (product_type IN ('SPONSOR_FREE','PAID_COMPETITION')),
  channel text NOT NULL CHECK (channel IN ('WEB','ANDROID','IOS','TELEGRAM')),
  license_scope text,
  state text NOT NULL DEFAULT 'BLOCKED'
    CHECK (state IN ('BLOCKED','DOSSIER','REVIEWED','LIMITED_PILOT','LIVE','SUSPENDED','EXPIRED','REVOKED')),
  effective_from timestamptz, effective_to timestamptz,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (legal_entity_id, country_code) REFERENCES legal_entities(id, country_code),
  FOREIGN KEY (created_by, legal_entity_id) REFERENCES staff_users(id, legal_entity_id),
  CHECK (effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from),
  UNIQUE (legal_entity_id, country_code, product_type, channel),
  UNIQUE (id, legal_entity_id));

CREATE TABLE authorization_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  authorization_id uuid NOT NULL, legal_entity_id uuid NOT NULL,
  kind text NOT NULL CHECK (kind IN ('CLASSIFICATION','REGULATOR_APPROVAL','RULE_VERSION','AGE_GEO_POLICY',
     'KYC_AML_POLICY','PRIVACY_RESIDENCY','ADVERTISING_CHANNEL','TAX_ACCOUNTING','PRIZE_CONTRACT_RESERVE',
     'INCIDENT_SUPPORT','FAIRNESS_PROCESS','PROVIDER_ACCEPTANCE')),
  sha256 char(64) NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
  storage_uri text NOT NULL,
  expires_at timestamptz,
  recorded_by uuid NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (authorization_id, legal_entity_id) REFERENCES country_product_authorizations(id, legal_entity_id));
CREATE TRIGGER evidence_immutable BEFORE UPDATE OR DELETE ON authorization_evidence FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

CREATE TABLE authorization_approvals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  authorization_id uuid NOT NULL, legal_entity_id uuid NOT NULL,
  approval_role text NOT NULL CHECK (approval_role IN ('COMPLIANCE','CFO','DEPLOYMENT')),
  approver_id uuid NOT NULL,
  target_state text NOT NULL,
  approved_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (authorization_id, legal_entity_id) REFERENCES country_product_authorizations(id, legal_entity_id),
  FOREIGN KEY (approver_id, legal_entity_id) REFERENCES staff_users(id, legal_entity_id),
  UNIQUE (authorization_id, approval_role, target_state));
CREATE TRIGGER approvals_immutable BEFORE UPDATE OR DELETE ON authorization_approvals FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

CREATE TABLE payment_providers (
  code text PRIMARY KEY,
  state text NOT NULL DEFAULT 'SUSPENDED' CHECK (state IN ('ACTIVE','SUSPENDED')),
  gaming_model_accepted boolean NOT NULL DEFAULT false);

-- ---------- Customers ----------
CREATE TABLE customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL,
  country_code char(2) NOT NULL,
  pii_ciphertext bytea,                 -- field-level encrypted identity payload (KMS envelope)
  age_verified boolean NOT NULL DEFAULT false,
  kyc_state text NOT NULL DEFAULT 'NONE' CHECK (kyc_state IN ('NONE','PENDING','VERIFIED','REJECTED')),
  terms_consent_at timestamptz,
  self_excluded_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (legal_entity_id, country_code) REFERENCES legal_entities(id, country_code),
  UNIQUE (id, legal_entity_id));

CREATE TABLE channel_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL, customer_id uuid NOT NULL,
  channel text NOT NULL CHECK (channel IN ('TELEGRAM')),
  external_principal text NOT NULL,
  linked_at timestamptz NOT NULL DEFAULT now(), unlinked_at timestamptz,
  FOREIGN KEY (customer_id, legal_entity_id) REFERENCES customers(id, legal_entity_id));
CREATE UNIQUE INDEX channel_links_active ON channel_links(channel, external_principal) WHERE unlinked_at IS NULL;

-- ---------- Rules ----------
CREATE TABLE rule_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL REFERENCES legal_entities,
  body jsonb NOT NULL,
  rule_hash char(64) NOT NULL,
  state text NOT NULL DEFAULT 'DRAFT' CHECK (state IN ('DRAFT','APPROVED')),
  created_by uuid NOT NULL, approved_by uuid,
  approved_at timestamptz,
  CHECK (state = 'DRAFT' OR (approved_by IS NOT NULL AND approved_by <> created_by)),
  UNIQUE (id, legal_entity_id), UNIQUE (legal_entity_id, rule_hash));

CREATE FUNCTION rule_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.state = 'APPROVED' THEN RAISE EXCEPTION 'IMMUTABLE_RECORD: approved rule' USING ERRCODE='VQ900'; END IF;
    RETURN OLD; END IF;
  IF TG_OP = 'UPDATE' AND OLD.state = 'APPROVED' THEN
    RAISE EXCEPTION 'IMMUTABLE_RECORD: approved rule cannot change' USING ERRCODE='VQ900'; END IF;
  NEW.rule_hash := encode(sha256(convert_to(NEW.body::text, 'UTF8')), 'hex');
  RETURN NEW;
END $$;
CREATE TRIGGER rule_versions_guard BEFORE INSERT OR UPDATE OR DELETE ON rule_versions FOR EACH ROW EXECUTE FUNCTION rule_guard();

-- ---------- Competitions ----------
CREATE TABLE competitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL,
  country_code char(2) NOT NULL,
  product_type text NOT NULL CHECK (product_type IN ('SPONSOR_FREE','PAID_COMPETITION')),
  title text NOT NULL,
  rule_version_id uuid NOT NULL,
  state text NOT NULL DEFAULT 'DRAFT' CHECK (state IN ('DRAFT','OPEN','CLOSING','FROZEN','RESULT_PUBLISHED','CANCELLED')),
  opens_at timestamptz NOT NULL, closes_at timestamptz NOT NULL CHECK (closes_at > opens_at),
  entry_fee_minor bigint NOT NULL DEFAULT 0 CHECK (entry_fee_minor >= 0),
  currency char(3) NOT NULL DEFAULT 'ETB',
  number_min int NOT NULL, number_max int NOT NULL CHECK (number_max >= number_min),
  per_customer_cap int NOT NULL CHECK (per_customer_cap BETWEEN 1 AND 1000),
  prize_obligation_minor bigint NOT NULL DEFAULT 0, prize_reserve_minor bigint NOT NULL DEFAULT 0,
  prize_secured boolean NOT NULL DEFAULT false,
  next_seq bigint NOT NULL DEFAULT 1, accepted_count bigint NOT NULL DEFAULT 0,
  chain_head char(64) NOT NULL DEFAULT repeat('0', 64),
  closed_at timestamptz, high_water bigint,
  created_by uuid NOT NULL,
  CHECK (product_type <> 'SPONSOR_FREE' OR entry_fee_minor = 0),
  CHECK (accepted_count = next_seq - 1),
  FOREIGN KEY (legal_entity_id, country_code) REFERENCES legal_entities(id, country_code),
  FOREIGN KEY (rule_version_id, legal_entity_id) REFERENCES rule_versions(id, legal_entity_id),
  UNIQUE (id, legal_entity_id));

-- ---------- Payments (intent level; ledger in 0002) ----------
CREATE TABLE payment_intents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL, customer_id uuid NOT NULL,
  provider text NOT NULL REFERENCES payment_providers,
  merchant_ref text NOT NULL UNIQUE,
  amount_minor bigint NOT NULL CHECK (amount_minor > 0), currency char(3) NOT NULL,
  state text NOT NULL DEFAULT 'INITIATED' CHECK (state IN ('INITIATED','PENDING','CONFIRMED','RECONCILED','APPLIED',
     'FAILED','EXPIRED','PARTIAL_SETTLEMENT','EXCEPTION','DISPUTED','REVERSED','REFUNDED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (customer_id, legal_entity_id) REFERENCES customers(id, legal_entity_id),
  UNIQUE (id, legal_entity_id));

-- ---------- Entries ----------
CREATE TABLE entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL,
  competition_id uuid NOT NULL,
  customer_id uuid NOT NULL,
  seq bigint NOT NULL CHECK (seq >= 1),
  selection int NOT NULL,
  channel text NOT NULL,
  idempotency_key text NOT NULL CHECK (length(idempotency_key) BETWEEN 8 AND 128),
  request_digest char(64) NOT NULL,
  payment_intent_id uuid UNIQUE,
  rule_hash char(64) NOT NULL,
  accepted_at timestamptz NOT NULL,
  prev_receipt_hash char(64) NOT NULL,
  receipt_hash char(64) NOT NULL UNIQUE,
  FOREIGN KEY (competition_id, legal_entity_id) REFERENCES competitions(id, legal_entity_id),
  FOREIGN KEY (customer_id, legal_entity_id) REFERENCES customers(id, legal_entity_id),
  FOREIGN KEY (payment_intent_id, legal_entity_id) REFERENCES payment_intents(id, legal_entity_id),
  UNIQUE (competition_id, seq),
  UNIQUE (competition_id, customer_id, idempotency_key));
CREATE INDEX entries_comp_customer ON entries(competition_id, customer_id);
CREATE TRIGGER entries_immutable BEFORE UPDATE OR DELETE ON entries FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- ---------- Outbox / audit ----------
CREATE TABLE outbox (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  event_id uuid NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  legal_entity_id uuid NOT NULL, country_code char(2),
  aggregate_type text NOT NULL, aggregate_id uuid NOT NULL,
  event_type text NOT NULL CHECK (event_type ~ '^[a-z_]+\.[a-z_]+\.v[0-9]+$'),
  payload jsonb NOT NULL, classification text NOT NULL DEFAULT 'INTERNAL',
  occurred_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  published_at timestamptz);

CREATE TABLE audit_log (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  legal_entity_id uuid NOT NULL,
  actor_id uuid, action text NOT NULL, object_id uuid, payload jsonb NOT NULL DEFAULT '{}',
  at timestamptz NOT NULL DEFAULT clock_timestamp(),
  prev_hash char(64) NOT NULL, hash char(64) NOT NULL);
CREATE TRIGGER audit_immutable BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

CREATE FUNCTION audit(p_entity uuid, p_action text, p_object uuid, p_payload jsonb) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE v_prev char(64); v_at timestamptz := clock_timestamp();
BEGIN
  PERFORM pg_advisory_xact_lock(hashtextextended('veriq.audit.' || p_entity::text, 0));
  SELECT hash INTO v_prev FROM audit_log WHERE legal_entity_id = p_entity ORDER BY id DESC LIMIT 1;
  v_prev := coalesce(v_prev, repeat('0', 64));
  INSERT INTO audit_log(legal_entity_id, actor_id, action, object_id, payload, at, prev_hash, hash)
  VALUES (p_entity, current_actor(), p_action, p_object, p_payload, v_at, v_prev,
    encode(sha256(convert_to(v_prev || '|' || coalesce(current_actor()::text,'') || '|' || p_action || '|' ||
      coalesce(p_object::text,'') || '|' || p_payload::text || '|' || to_char(v_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US'), 'UTF8')), 'hex'));
END $$;

-- ---------- Authorization gate ----------
CREATE FUNCTION authz_check(p_entity uuid, p_country char(2), p_product text, p_channel text) RETURNS text
LANGUAGE plpgsql STABLE AS $$
DECLARE r record; v_now timestamptz := clock_timestamp();
BEGIN
  IF NOT EXISTS (SELECT 1 FROM country_product_authorizations WHERE legal_entity_id=p_entity AND country_code=p_country) THEN
    RETURN 'DENIED_COUNTRY'; END IF;
  SELECT * INTO r FROM country_product_authorizations
   WHERE legal_entity_id=p_entity AND country_code=p_country AND product_type=p_product AND channel=p_channel;
  IF NOT FOUND THEN RETURN 'DENIED_PRODUCT'; END IF;
  IF r.state = 'EXPIRED' OR (r.effective_to IS NOT NULL AND v_now >= r.effective_to) THEN RETURN 'EXPIRED_SCOPE'; END IF;
  IF r.state NOT IN ('LIMITED_PILOT','LIVE') OR r.effective_from IS NULL OR v_now < r.effective_from THEN RETURN 'DENIED_PRODUCT'; END IF;
  IF EXISTS (SELECT 1 FROM authorization_evidence e WHERE e.authorization_id=r.id AND e.expires_at IS NOT NULL AND e.expires_at <= v_now) THEN
    RETURN 'EXPIRED_SCOPE'; END IF;
  RETURN 'OK';
END $$;

CREATE FUNCTION transition_authorization(p_auth uuid, p_to text, p_from_ts timestamptz DEFAULT NULL, p_to_ts timestamptz DEFAULT NULL)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE r record; v_actor uuid := current_actor(); v_required text[];
        v_missing text[]; v_roles int; v_creator_signed boolean; v_distinct int;
BEGIN
  SELECT * INTO r FROM country_product_authorizations WHERE id=p_auth AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND THEN RETURN 'NOT_FOUND'; END IF;
  IF v_actor IS NULL THEN RETURN 'NO_ACTOR'; END IF;
  -- Stops are always allowed by an authorized staff member; they never need multi-party approval.
  IF p_to IN ('SUSPENDED','REVOKED','EXPIRED','BLOCKED') THEN
    UPDATE country_product_authorizations SET state=p_to WHERE id=p_auth;
    PERFORM audit(r.legal_entity_id, 'authorization.' || lower(p_to), p_auth, jsonb_build_object('from', r.state));
    INSERT INTO outbox(legal_entity_id,country_code,aggregate_type,aggregate_id,event_type,payload)
      VALUES (r.legal_entity_id, r.country_code, 'authorization', p_auth, 'authorization.suspended.v1', jsonb_build_object('state', p_to));
    RETURN 'OK'; END IF;
  IF NOT ((r.state,p_to) IN (('BLOCKED','DOSSIER'),('DOSSIER','REVIEWED'),('REVIEWED','LIMITED_PILOT'),('LIMITED_PILOT','LIVE'),('SUSPENDED','REVIEWED'))) THEN
    RETURN 'ILLEGAL_TRANSITION'; END IF;
  IF p_to IN ('LIMITED_PILOT','LIVE') THEN
    v_required := ARRAY['CLASSIFICATION','REGULATOR_APPROVAL','RULE_VERSION','AGE_GEO_POLICY','KYC_AML_POLICY',
      'PRIVACY_RESIDENCY','ADVERTISING_CHANNEL','TAX_ACCOUNTING','PRIZE_CONTRACT_RESERVE','INCIDENT_SUPPORT','FAIRNESS_PROCESS'];
    IF r.product_type = 'PAID_COMPETITION' THEN v_required := array_append(v_required, 'PROVIDER_ACCEPTANCE'); END IF;
    SELECT array_agg(k) INTO v_missing FROM unnest(v_required) k
      WHERE NOT EXISTS (SELECT 1 FROM authorization_evidence e WHERE e.authorization_id=p_auth AND e.kind=k
                        AND (e.expires_at IS NULL OR e.expires_at > clock_timestamp()));
    IF v_missing IS NOT NULL THEN RETURN 'MISSING_EVIDENCE:' || array_to_string(v_missing, ','); END IF;
    SELECT count(DISTINCT approval_role), count(DISTINCT approver_id), bool_or(approver_id = r.created_by)
      INTO v_roles, v_distinct, v_creator_signed
      FROM authorization_approvals WHERE authorization_id=p_auth AND target_state=p_to;
    IF v_roles < 3 OR v_distinct < 3 THEN RETURN 'MISSING_APPROVALS'; END IF;
    IF v_creator_signed OR v_actor = r.created_by THEN RETURN 'CREATOR_EXCLUDED'; END IF;
    IF p_from_ts IS NULL OR p_to_ts IS NULL OR p_to_ts <= p_from_ts THEN RETURN 'INVALID_INTERVAL'; END IF;
    UPDATE country_product_authorizations SET state=p_to, effective_from=p_from_ts, effective_to=p_to_ts WHERE id=p_auth;
  ELSE
    UPDATE country_product_authorizations SET state=p_to WHERE id=p_auth;
  END IF;
  PERFORM audit(r.legal_entity_id, 'authorization.transition', p_auth, jsonb_build_object('from', r.state, 'to', p_to));
  RETURN 'OK';
END $$;

CREATE FUNCTION approve_authorization(p_auth uuid, p_role text, p_target text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v_roles text[];
BEGIN
  SELECT roles INTO v_roles FROM staff_users WHERE id=current_actor() AND legal_entity_id=current_entity() AND active;
  IF v_roles IS NULL OR NOT (p_role = ANY(v_roles)) THEN RETURN 'ROLE_NOT_HELD'; END IF;
  INSERT INTO authorization_approvals(authorization_id, legal_entity_id, approval_role, approver_id, target_state)
    VALUES (p_auth, current_entity(), p_role, current_actor(), p_target);
  PERFORM audit(current_entity(), 'authorization.approve', p_auth, jsonb_build_object('role', p_role, 'target', p_target));
  RETURN 'OK';
END $$;

-- ---------- Critical acceptance transaction ----------
-- Linearization point: the row lock on the competition. Close takes the same lock, so an entry is
-- either committed with seq <= high_water before close, or it observes state <> OPEN and is rejected.
CREATE FUNCTION accept_entry(p_competition uuid, p_customer uuid, p_selection int, p_idem text,
                             p_channel text, p_payment_intent uuid DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE c record; cu record; pi record; e record; v_entity uuid := current_entity();
        v_now timestamptz; v_digest char(64); v_gate text; v_count int; v_seq bigint;
        v_receipt char(64); v_rule char(64); v_id uuid := gen_random_uuid();
BEGIN
  IF v_entity IS NULL THEN RETURN jsonb_build_object('ok',false,'code','NO_ENTITY_CONTEXT'); END IF;
  SELECT * INTO c FROM competitions WHERE id=p_competition AND legal_entity_id=v_entity FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'code','NOT_FOUND'); END IF;

  v_digest := encode(sha256(convert_to(concat_ws('|', p_competition, p_customer, p_selection, p_channel, coalesce(p_payment_intent::text,'')),'UTF8')),'hex');
  SELECT * INTO e FROM entries WHERE competition_id=p_competition AND customer_id=p_customer AND idempotency_key=p_idem;
  IF FOUND THEN
    IF e.request_digest = v_digest THEN
      RETURN jsonb_build_object('ok',true,'replay',true,'entry_id',e.id,'seq',e.seq,'receipt_hash',e.receipt_hash,'accepted_at',e.accepted_at);
    END IF;
    RETURN jsonb_build_object('ok',false,'code','IDEMPOTENCY_CONFLICT');
  END IF;

  v_now := clock_timestamp();
  IF c.state <> 'OPEN' OR v_now < c.opens_at OR v_now >= c.closes_at THEN
    RETURN jsonb_build_object('ok',false,'code','COMPETITION_NOT_OPEN'); END IF;
  v_gate := authz_check(v_entity, c.country_code, c.product_type, p_channel);
  IF v_gate <> 'OK' THEN RETURN jsonb_build_object('ok',false,'code',v_gate); END IF;
  IF NOT c.prize_secured OR c.prize_reserve_minor < c.prize_obligation_minor THEN
    RETURN jsonb_build_object('ok',false,'code','RESERVE_SHORTFALL'); END IF;

  SELECT * INTO cu FROM customers WHERE id=p_customer AND legal_entity_id=v_entity;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'code','CUSTOMER_NOT_FOUND'); END IF;
  IF cu.country_code <> c.country_code THEN RETURN jsonb_build_object('ok',false,'code','DENIED_COUNTRY'); END IF;
  IF NOT cu.age_verified OR cu.kyc_state <> 'VERIFIED' THEN RETURN jsonb_build_object('ok',false,'code','ELIGIBILITY_INCOMPLETE'); END IF;
  IF cu.terms_consent_at IS NULL THEN RETURN jsonb_build_object('ok',false,'code','CONSENT_REQUIRED'); END IF;
  IF cu.self_excluded_until IS NOT NULL AND cu.self_excluded_until > v_now THEN
    RETURN jsonb_build_object('ok',false,'code','SELF_EXCLUDED'); END IF;
  IF p_selection < c.number_min OR p_selection > c.number_max THEN RETURN jsonb_build_object('ok',false,'code','SELECTION_OUT_OF_RANGE'); END IF;
  SELECT count(*) INTO v_count FROM entries WHERE competition_id=p_competition AND customer_id=p_customer;
  IF v_count >= c.per_customer_cap THEN RETURN jsonb_build_object('ok',false,'code','ENTRY_CAP_REACHED'); END IF;

  IF c.product_type = 'SPONSOR_FREE' THEN
    IF p_payment_intent IS NOT NULL OR c.entry_fee_minor <> 0 THEN RETURN jsonb_build_object('ok',false,'code','FREE_ENTRY_MUST_NOT_CHARGE'); END IF;
  ELSE
    IF p_payment_intent IS NULL THEN RETURN jsonb_build_object('ok',false,'code','PAYMENT_REQUIRED'); END IF;
    SELECT p.*, pp.state AS provider_state, pp.gaming_model_accepted INTO pi
      FROM payment_intents p JOIN payment_providers pp ON pp.code=p.provider
     WHERE p.id=p_payment_intent AND p.legal_entity_id=v_entity AND p.customer_id=p_customer FOR UPDATE OF p;
    IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'code','PAYMENT_NOT_FOUND'); END IF;
    IF pi.provider_state <> 'ACTIVE' OR NOT pi.gaming_model_accepted THEN RETURN jsonb_build_object('ok',false,'code','PROVIDER_SUSPENDED'); END IF;
    IF pi.state NOT IN ('CONFIRMED','RECONCILED') THEN RETURN jsonb_build_object('ok',false,'code','PAYMENT_NOT_CONFIRMED'); END IF;
    IF pi.amount_minor <> c.entry_fee_minor OR pi.currency <> c.currency THEN RETURN jsonb_build_object('ok',false,'code','PAYMENT_AMOUNT_MISMATCH'); END IF;
    UPDATE payment_intents SET state='APPLIED' WHERE id=p_payment_intent;
  END IF;

  SELECT rule_hash INTO v_rule FROM rule_versions WHERE id=c.rule_version_id AND state='APPROVED';
  IF v_rule IS NULL THEN RETURN jsonb_build_object('ok',false,'code','RULE_NOT_APPROVED'); END IF;

  v_seq := c.next_seq;
  v_receipt := encode(sha256(convert_to(concat_ws('|', c.chain_head, v_id, p_competition, v_seq, p_selection, v_rule,
                 to_char(v_now AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US')),'UTF8')),'hex');
  INSERT INTO entries(id, legal_entity_id, competition_id, customer_id, seq, selection, channel, idempotency_key,
                      request_digest, payment_intent_id, rule_hash, accepted_at, prev_receipt_hash, receipt_hash)
  VALUES (v_id, v_entity, p_competition, p_customer, v_seq, p_selection, p_channel, p_idem, v_digest,
          p_payment_intent, v_rule, v_now, c.chain_head, v_receipt);
  UPDATE competitions SET next_seq = v_seq + 1, accepted_count = v_seq, chain_head = v_receipt WHERE id=p_competition;
  INSERT INTO outbox(legal_entity_id,country_code,aggregate_type,aggregate_id,event_type,payload,classification)
    VALUES (v_entity, c.country_code, 'entry', v_id, 'entry.accepted.v1',
            jsonb_build_object('competition_id',p_competition,'seq',v_seq,'receipt_hash',v_receipt), 'NO_PII');
  RETURN jsonb_build_object('ok',true,'replay',false,'entry_id',v_id,'seq',v_seq,'receipt_hash',v_receipt,'accepted_at',v_now,'rule_hash',v_rule);
END $$;

-- ---------- Close / freeze ----------
CREATE FUNCTION close_competition(p_competition uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE c record; v_n bigint; v_min bigint; v_max bigint; v_roles text[]; v_now timestamptz;
BEGIN
  SELECT roles INTO v_roles FROM staff_users WHERE id=current_actor() AND legal_entity_id=current_entity() AND active;
  IF v_roles IS NULL OR NOT ('COMP_OPS' = ANY(v_roles)) THEN RETURN jsonb_build_object('ok',false,'code','ROLE_NOT_HELD'); END IF;
  SELECT * INTO c FROM competitions WHERE id=p_competition AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'code','NOT_FOUND'); END IF;
  IF c.state <> 'OPEN' THEN RETURN jsonb_build_object('ok',false,'code','NOT_OPEN'); END IF;
  v_now := clock_timestamp();
  UPDATE competitions SET state='CLOSING', closed_at=v_now WHERE id=p_competition;
  SELECT count(*), min(seq), max(seq) INTO v_n, v_min, v_max FROM entries WHERE competition_id=p_competition;
  IF v_n <> c.accepted_count OR (v_n > 0 AND (v_min <> 1 OR v_max <> v_n)) THEN
    RAISE EXCEPTION 'CLOSE_RECONCILIATION_FAILED n=% count=% min=% max=%', v_n, c.accepted_count, v_min, v_max USING ERRCODE='VQ901';
  END IF;
  UPDATE competitions SET state='FROZEN', high_water=v_n WHERE id=p_competition;
  PERFORM audit(c.legal_entity_id, 'competition.frozen', p_competition, jsonb_build_object('high_water', v_n, 'chain_head', c.chain_head));
  INSERT INTO outbox(legal_entity_id,country_code,aggregate_type,aggregate_id,event_type,payload)
    VALUES (c.legal_entity_id, c.country_code, 'competition', p_competition, 'competition.frozen.v1',
            jsonb_build_object('high_water', v_n, 'chain_head', c.chain_head));
  RETURN jsonb_build_object('ok',true,'high_water',v_n,'chain_head',c.chain_head,'closed_at',v_now);
END $$;

RESET ROLE;
