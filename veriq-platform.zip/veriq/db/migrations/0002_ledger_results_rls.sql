-- VERIQ 0002 — double-entry ledger, payment events, result evidence, RLS and least-privilege grants.
SET ROLE veriq_owner;
SET search_path = veriq, public;

-- ---------- Double-entry ledger (integer minor units only) ----------
CREATE TABLE accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL REFERENCES legal_entities,
  code text NOT NULL, currency char(3) NOT NULL,
  kind text NOT NULL CHECK (kind IN ('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE')),
  name text NOT NULL,
  UNIQUE (legal_entity_id, code, currency), UNIQUE (id, legal_entity_id, currency));

CREATE TABLE journals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL REFERENCES legal_entities,
  state text NOT NULL DEFAULT 'DRAFT' CHECK (state IN ('DRAFT','POSTED')),
  source text NOT NULL, source_ref text NOT NULL,
  reverses_journal_id uuid REFERENCES journals,
  memo text, posted_at timestamptz, posted_by uuid,
  UNIQUE (id, legal_entity_id), UNIQUE (legal_entity_id, source, source_ref));
CREATE UNIQUE INDEX one_reversal_per_journal ON journals(reverses_journal_id) WHERE reverses_journal_id IS NOT NULL;

CREATE TABLE journal_lines (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  journal_id uuid NOT NULL, legal_entity_id uuid NOT NULL,
  account_id uuid NOT NULL, currency char(3) NOT NULL,
  amount_minor bigint NOT NULL CHECK (amount_minor <> 0),   -- + debit, - credit
  FOREIGN KEY (journal_id, legal_entity_id) REFERENCES journals(id, legal_entity_id),
  FOREIGN KEY (account_id, legal_entity_id, currency) REFERENCES accounts(id, legal_entity_id, currency));

CREATE FUNCTION journal_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v_state text;
BEGIN
  IF TG_TABLE_NAME = 'journals' THEN
    IF TG_OP = 'DELETE' AND OLD.state = 'POSTED' THEN RAISE EXCEPTION 'IMMUTABLE_RECORD: posted journal' USING ERRCODE='VQ900'; END IF;
    IF TG_OP = 'UPDATE' AND OLD.state = 'POSTED' THEN RAISE EXCEPTION 'IMMUTABLE_RECORD: posted journal' USING ERRCODE='VQ900'; END IF;
    RETURN COALESCE(NEW, OLD);
  END IF;
  SELECT state INTO v_state FROM journals WHERE id = COALESCE(NEW.journal_id, OLD.journal_id);
  IF v_state = 'POSTED' THEN RAISE EXCEPTION 'IMMUTABLE_RECORD: lines of posted journal' USING ERRCODE='VQ900'; END IF;
  RETURN COALESCE(NEW, OLD);
END $$;
CREATE TRIGGER journals_guard BEFORE UPDATE OR DELETE ON journals FOR EACH ROW EXECUTE FUNCTION journal_guard();
CREATE TRIGGER lines_guard BEFORE INSERT OR UPDATE OR DELETE ON journal_lines FOR EACH ROW EXECUTE FUNCTION journal_guard();

-- Commit-time invariant: every POSTED journal balances per currency (defence in depth behind post_journal).
CREATE FUNCTION journal_balance_check() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.state = 'POSTED' AND EXISTS (
     SELECT 1 FROM journal_lines WHERE journal_id = NEW.id GROUP BY currency HAVING sum(amount_minor) <> 0) THEN
    RAISE EXCEPTION 'UNBALANCED_JOURNAL %', NEW.id USING ERRCODE='VQ902'; END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER journals_balanced AFTER INSERT OR UPDATE ON journals
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION journal_balance_check();

CREATE FUNCTION post_journal(p_source text, p_ref text, p_memo text, p_lines jsonb, p_reverses uuid DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v_id uuid; l jsonb; v_entity uuid := current_entity();
BEGIN
  IF v_entity IS NULL THEN RAISE EXCEPTION 'NO_ENTITY_CONTEXT' USING ERRCODE='VQ903'; END IF;
  IF jsonb_array_length(p_lines) < 2 THEN RAISE EXCEPTION 'JOURNAL_NEEDS_TWO_LINES' USING ERRCODE='VQ902'; END IF;
  INSERT INTO journals(legal_entity_id, source, source_ref, memo, reverses_journal_id)
    VALUES (v_entity, p_source, p_ref, p_memo, p_reverses) RETURNING id INTO v_id;
  FOR l IN SELECT * FROM jsonb_array_elements(p_lines) LOOP
    INSERT INTO journal_lines(journal_id, legal_entity_id, account_id, currency, amount_minor)
    SELECT v_id, v_entity, a.id, a.currency, (l->>'amount_minor')::bigint
      FROM accounts a WHERE a.legal_entity_id = v_entity AND a.code = l->>'account' AND a.currency = l->>'currency';
    IF NOT FOUND THEN RAISE EXCEPTION 'UNKNOWN_ACCOUNT %', l->>'account' USING ERRCODE='VQ902'; END IF;
  END LOOP;
  IF EXISTS (SELECT 1 FROM journal_lines WHERE journal_id=v_id GROUP BY currency HAVING sum(amount_minor) <> 0) THEN
    RAISE EXCEPTION 'UNBALANCED_JOURNAL' USING ERRCODE='VQ902'; END IF;
  UPDATE journals SET state='POSTED', posted_at=clock_timestamp(), posted_by=current_actor() WHERE id=v_id;
  PERFORM audit(v_entity, 'journal.posted', v_id, jsonb_build_object('source', p_source, 'ref', p_ref));
  RETURN v_id;
END $$;

CREATE FUNCTION reverse_journal(p_journal uuid, p_reason text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v_lines jsonb;
BEGIN
  SELECT jsonb_agg(jsonb_build_object('account', a.code, 'currency', l.currency, 'amount_minor', -l.amount_minor))
    INTO v_lines FROM journal_lines l JOIN accounts a ON a.id = l.account_id
   WHERE l.journal_id = p_journal AND l.legal_entity_id = current_entity();
  IF v_lines IS NULL THEN RAISE EXCEPTION 'JOURNAL_NOT_FOUND' USING ERRCODE='VQ902'; END IF;
  RETURN post_journal('reversal', p_journal::text, p_reason, v_lines, p_journal);
END $$;

-- ---------- Payment events: applied financially at most once ----------
CREATE TABLE payment_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL,
  provider text NOT NULL REFERENCES payment_providers,
  provider_event_id text NOT NULL,
  payment_intent_id uuid NOT NULL,
  kind text NOT NULL CHECK (kind IN ('PENDING','CONFIRMED','FAILED','SETTLED','DISPUTED','REVERSED','REFUNDED')),
  amount_minor bigint NOT NULL, currency char(3) NOT NULL,
  raw_digest char(64) NOT NULL,
  received_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  applied boolean NOT NULL,
  disposition text NOT NULL,
  FOREIGN KEY (payment_intent_id, legal_entity_id) REFERENCES payment_intents(id, legal_entity_id),
  UNIQUE (provider, provider_event_id));
CREATE TRIGGER payment_events_immutable BEFORE UPDATE OR DELETE ON payment_events FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- Caller (webhook adapter) MUST have verified provider signature, timestamp window and merchant ref first.
CREATE FUNCTION apply_payment_event(p_provider text, p_event_id text, p_merchant_ref text, p_kind text,
                                    p_amount bigint, p_currency char(3), p_raw_digest char(64)) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE pi record; v_to text; v_ok boolean := false; v_disp text;
BEGIN
  IF EXISTS (SELECT 1 FROM payment_events WHERE provider=p_provider AND provider_event_id=p_event_id) THEN
    RETURN jsonb_build_object('applied', false, 'disposition', 'DUPLICATE'); END IF;
  SELECT * INTO pi FROM payment_intents WHERE merchant_ref=p_merchant_ref AND provider=p_provider
     AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('applied', false, 'disposition', 'UNKNOWN_MERCHANT_REF'); END IF;
  v_to := CASE p_kind WHEN 'PENDING' THEN 'PENDING' WHEN 'CONFIRMED' THEN 'CONFIRMED' WHEN 'FAILED' THEN 'FAILED'
            WHEN 'SETTLED' THEN 'RECONCILED' WHEN 'DISPUTED' THEN 'DISPUTED' WHEN 'REVERSED' THEN 'REVERSED'
            WHEN 'REFUNDED' THEN 'REFUNDED' END;
  IF p_amount <> pi.amount_minor OR p_currency <> pi.currency THEN v_disp := 'AMOUNT_MISMATCH_EXCEPTION'; v_to := 'EXCEPTION';
  ELSIF (pi.state, v_to) IN (('INITIATED','PENDING'),('INITIATED','CONFIRMED'),('PENDING','CONFIRMED'),('INITIATED','FAILED'),
        ('PENDING','FAILED'),('CONFIRMED','RECONCILED'),('APPLIED','RECONCILED'),('CONFIRMED','DISPUTED'),('APPLIED','DISPUTED'),
        ('RECONCILED','DISPUTED'),('DISPUTED','REVERSED'),('CONFIRMED','REFUNDED'),('RECONCILED','REFUNDED')) THEN
    v_ok := true; v_disp := 'APPLIED';
  ELSE v_disp := 'OUT_OF_ORDER_HELD'; END IF;
  INSERT INTO payment_events(legal_entity_id, provider, provider_event_id, payment_intent_id, kind, amount_minor, currency, raw_digest, applied, disposition)
    VALUES (current_entity(), p_provider, p_event_id, pi.id, p_kind, p_amount, p_currency, p_raw_digest, v_ok OR v_to='EXCEPTION', v_disp);
  IF v_ok OR v_to = 'EXCEPTION' THEN UPDATE payment_intents SET state=v_to WHERE id=pi.id; END IF;
  IF v_ok AND v_to = 'CONFIRMED' THEN
    PERFORM post_journal('payment.confirmed', p_provider || ':' || p_event_id, 'Provider-confirmed entry fee',
      jsonb_build_array(jsonb_build_object('account','1100-PROVIDER-CLEARING','currency',p_currency,'amount_minor',p_amount),
                        jsonb_build_object('account','2100-CUSTOMER-LIABILITY','currency',p_currency,'amount_minor',-p_amount)));
    INSERT INTO outbox(legal_entity_id,aggregate_type,aggregate_id,event_type,payload,classification)
      VALUES (current_entity(),'payment',pi.id,'payment.confirmed.v1',jsonb_build_object('amount_minor',p_amount,'currency',p_currency),'NO_PII');
  ELSIF v_ok AND v_to = 'REFUNDED' THEN
    PERFORM post_journal('refund.posted', p_provider || ':' || p_event_id, 'Refund to customer',
      jsonb_build_array(jsonb_build_object('account','2100-CUSTOMER-LIABILITY','currency',p_currency,'amount_minor',p_amount),
                        jsonb_build_object('account','1100-PROVIDER-CLEARING','currency',p_currency,'amount_minor',-p_amount)));
  END IF;
  RETURN jsonb_build_object('applied', v_ok, 'disposition', v_disp, 'state', CASE WHEN v_ok OR v_to='EXCEPTION' THEN v_to ELSE pi.state END);
END $$;

-- ---------- Results and external witness ----------
CREATE TABLE result_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL, competition_id uuid NOT NULL UNIQUE,
  algorithm_version text NOT NULL, manifest jsonb NOT NULL, manifest_digest char(64) NOT NULL,
  signature text NOT NULL, key_id text NOT NULL,
  outcome text NOT NULL CHECK (outcome IN ('WINNER','NO_WINNER')),
  winning_number int, winning_entry_id uuid,
  verifier_attestation jsonb, published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  FOREIGN KEY (competition_id, legal_entity_id) REFERENCES competitions(id, legal_entity_id));
CREATE FUNCTION result_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'IMMUTABLE_RECORD: result' USING ERRCODE='VQ900'; END IF;
  IF OLD.published_at IS NOT NULL THEN RAISE EXCEPTION 'IMMUTABLE_RECORD: published result' USING ERRCODE='VQ900'; END IF;
  IF (NEW.manifest, NEW.manifest_digest, NEW.signature, NEW.outcome, NEW.winning_number, NEW.winning_entry_id)
     IS DISTINCT FROM (OLD.manifest, OLD.manifest_digest, OLD.signature, OLD.outcome, OLD.winning_number, OLD.winning_entry_id) THEN
    RAISE EXCEPTION 'IMMUTABLE_RECORD: result body' USING ERRCODE='VQ900'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER result_runs_guard BEFORE UPDATE OR DELETE ON result_runs FOR EACH ROW EXECUTE FUNCTION result_guard();

CREATE TABLE witness_roots (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  legal_entity_id uuid NOT NULL, competition_id uuid NOT NULL,
  through_seq bigint NOT NULL, chain_head char(64) NOT NULL,
  external_ref text NOT NULL, witnessed_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (competition_id, through_seq));
CREATE TRIGGER witness_immutable BEFORE UPDATE OR DELETE ON witness_roots FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

CREATE FUNCTION record_result(p_competition uuid, p_alg text, p_manifest jsonb, p_digest char(64), p_sig text, p_key text,
                              p_outcome text, p_number int, p_entry uuid) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v_id uuid; c record;
BEGIN
  SELECT * INTO c FROM competitions WHERE id=p_competition AND legal_entity_id=current_entity() FOR UPDATE;
  IF c.state <> 'FROZEN' THEN RAISE EXCEPTION 'NOT_FROZEN' USING ERRCODE='VQ904'; END IF;
  IF (p_manifest->>'high_water')::bigint <> c.high_water OR p_manifest->>'chain_head' <> c.chain_head THEN
    RAISE EXCEPTION 'MANIFEST_DOES_NOT_MATCH_FROZEN_STATE' USING ERRCODE='VQ904'; END IF;
  INSERT INTO result_runs(legal_entity_id, competition_id, algorithm_version, manifest, manifest_digest, signature, key_id, outcome, winning_number, winning_entry_id)
    VALUES (current_entity(), p_competition, p_alg, p_manifest, p_digest, p_sig, p_key, p_outcome, p_number, p_entry) RETURNING id INTO v_id;
  INSERT INTO witness_roots(legal_entity_id, competition_id, through_seq, chain_head, external_ref)
    VALUES (current_entity(), p_competition, c.high_water, c.chain_head, 'pending-external-witness:' || p_digest);
  PERFORM audit(current_entity(), 'result.recorded', v_id, jsonb_build_object('digest', p_digest, 'outcome', p_outcome));
  RETURN v_id;
END $$;

-- Publication requires an attestation produced by the independent verifier package.
CREATE FUNCTION publish_result(p_competition uuid, p_attestation jsonb) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE r record;
BEGIN
  SELECT * INTO r FROM result_runs WHERE competition_id=p_competition AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND THEN RETURN 'NOT_FOUND'; END IF;
  IF (p_attestation->>'verified')::boolean IS NOT TRUE OR p_attestation->>'manifest_digest' <> r.manifest_digest
     OR (p_attestation->>'winning_number')::int IS DISTINCT FROM r.winning_number THEN RETURN 'VERIFICATION_MISMATCH'; END IF;
  UPDATE result_runs SET verifier_attestation=p_attestation, published_at=clock_timestamp() WHERE id=r.id;
  UPDATE competitions SET state='RESULT_PUBLISHED' WHERE id=p_competition;
  INSERT INTO outbox(legal_entity_id,aggregate_type,aggregate_id,event_type,payload)
    VALUES (current_entity(),'competition',p_competition,'result.verified.v1',jsonb_build_object('digest',r.manifest_digest));
  PERFORM audit(current_entity(), 'result.published', r.id, p_attestation);
  RETURN 'OK';
END $$;

-- ---------- Row-level security on every tenant table (FORCE applies even to the owner) ----------
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['staff_users','country_product_authorizations','authorization_evidence','authorization_approvals',
    'customers','channel_links','rule_versions','competitions','payment_intents','entries','outbox','audit_log',
    'accounts','journals','journal_lines','payment_events','result_runs','witness_roots'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_scope ON %I AS PERMISSIVE USING (legal_entity_id = veriq.current_entity()) WITH CHECK (legal_entity_id = veriq.current_entity())', t);
    EXECUTE format('CREATE POLICY tenant_guard ON %I AS RESTRICTIVE USING (veriq.current_entity() IS NOT NULL) WITH CHECK (veriq.current_entity() IS NOT NULL)', t);
    EXECUTE format('GRANT SELECT ON %I TO veriq_app, veriq_auditor', t);
  END LOOP;
END $$;
GRANT SELECT ON countries, legal_entities, payment_providers TO veriq_app, veriq_auditor;
-- Narrow direct writes for non-critical, mutable records only.
GRANT INSERT, UPDATE ON customers, channel_links, payment_intents TO veriq_app;
GRANT INSERT ON authorization_evidence, rule_versions TO veriq_app;
GRANT UPDATE (published_at) ON outbox TO veriq_app;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA veriq FROM PUBLIC;
GRANT EXECUTE ON FUNCTION current_entity(), current_actor(), authz_check(uuid,char,text,text),
  accept_entry(uuid,uuid,int,text,text,uuid), close_competition(uuid), approve_authorization(uuid,text,text),
  transition_authorization(uuid,text,timestamptz,timestamptz), post_journal(text,text,text,jsonb,uuid),
  reverse_journal(uuid,text), apply_payment_event(text,text,text,text,bigint,char,char),
  record_result(uuid,text,jsonb,char,text,text,text,int,uuid), publish_result(uuid,jsonb) TO veriq_app;
GRANT EXECUTE ON FUNCTION current_entity(), current_actor() TO veriq_auditor;
RESET ROLE;
