-- VERIQ 0003 — close privilege gaps found in self-review; add rule approval and competition lifecycle commands.
SET ROLE veriq_owner;
SET search_path = veriq, public;

-- Gap 1: app could set age/KYC directly. Gap 2: app could UPDATE payment_intents.state.
REVOKE INSERT, UPDATE ON customers, payment_intents FROM veriq_app;
GRANT INSERT (id, legal_entity_id, country_code, pii_ciphertext, terms_consent_at) ON customers TO veriq_app;
GRANT UPDATE (terms_consent_at, self_excluded_until) ON customers TO veriq_app;
GRANT INSERT (id, legal_entity_id, customer_id, provider, merchant_ref, amount_minor, currency) ON payment_intents TO veriq_app;

-- Self-exclusion can be extended at any time but never shortened before it expires.
CREATE FUNCTION exclusion_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.self_excluded_until IS NOT NULL AND OLD.self_excluded_until > clock_timestamp()
     AND (NEW.self_excluded_until IS NULL OR NEW.self_excluded_until < OLD.self_excluded_until) THEN
    RAISE EXCEPTION 'SELF_EXCLUSION_CANNOT_BE_SHORTENED' USING ERRCODE='VQ905'; END IF;
  IF NEW.age_verified IS DISTINCT FROM OLD.age_verified OR NEW.kyc_state IS DISTINCT FROM OLD.kyc_state THEN
    IF current_setting('veriq.identity_cmd', true) IS DISTINCT FROM 'on' THEN
      RAISE EXCEPTION 'ELIGIBILITY_FIELDS_COMMAND_ONLY' USING ERRCODE='VQ905'; END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER customers_exclusion_guard BEFORE UPDATE ON customers FOR EACH ROW EXECUTE FUNCTION exclusion_guard();

CREATE FUNCTION staff_has(p_role text) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = veriq, pg_temp AS
$$ SELECT EXISTS (SELECT 1 FROM staff_users WHERE id=current_actor() AND legal_entity_id=current_entity() AND active AND p_role = ANY(roles)) $$;

CREATE FUNCTION verify_customer_identity(p_customer uuid, p_age_ok boolean, p_kyc text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v_n int;
BEGIN
  IF NOT staff_has('COMPLIANCE') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  PERFORM set_config('veriq.identity_cmd', 'on', true);
  UPDATE customers SET age_verified=p_age_ok, kyc_state=p_kyc WHERE id=p_customer AND legal_entity_id=current_entity();
  GET DIAGNOSTICS v_n = ROW_COUNT;
  PERFORM set_config('veriq.identity_cmd', 'off', true);
  IF v_n = 0 THEN RETURN 'NOT_FOUND'; END IF;
  PERFORM audit(current_entity(), 'customer.identity_verified', p_customer, jsonb_build_object('age_ok', p_age_ok, 'kyc', p_kyc));
  RETURN 'OK';
END $$;

CREATE FUNCTION approve_rule(p_rule uuid) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE r record;
BEGIN
  IF NOT staff_has('COMPLIANCE') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  SELECT * INTO r FROM rule_versions WHERE id=p_rule AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND THEN RETURN 'NOT_FOUND'; END IF;
  IF r.created_by = current_actor() THEN RETURN 'CREATOR_EXCLUDED'; END IF;
  UPDATE rule_versions SET state='APPROVED', approved_by=current_actor(), approved_at=clock_timestamp() WHERE id=p_rule;
  PERFORM audit(current_entity(), 'rule.approved', p_rule, jsonb_build_object('rule_hash', r.rule_hash));
  RETURN 'OK';
END $$;

CREATE FUNCTION create_competition(p_country char(2), p_product text, p_title text, p_rule uuid, p_opens timestamptz,
  p_closes timestamptz, p_fee bigint, p_currency char(3), p_min int, p_max int, p_cap int, p_obligation bigint) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v_id uuid;
BEGIN
  IF NOT staff_has('COMP_OPS') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  INSERT INTO competitions(legal_entity_id, country_code, product_type, title, rule_version_id, opens_at, closes_at,
     entry_fee_minor, currency, number_min, number_max, per_customer_cap, prize_obligation_minor, created_by)
  VALUES (current_entity(), p_country, p_product, p_title, p_rule, p_opens, p_closes, p_fee, p_currency, p_min, p_max, p_cap, p_obligation, current_actor())
  RETURNING id INTO v_id;
  PERFORM audit(current_entity(), 'competition.created', v_id, jsonb_build_object('product', p_product));
  RETURN v_id;
END $$;

-- Prize security is a CFO decision backed by evidence; it is separate from the operator who opens the competition.
CREATE FUNCTION secure_prize(p_competition uuid, p_reserve bigint, p_evidence_sha256 char(64)) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
BEGIN
  IF NOT staff_has('CFO') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  IF p_evidence_sha256 !~ '^[0-9a-f]{64}$' THEN RETURN 'EVIDENCE_REQUIRED'; END IF;
  UPDATE competitions SET prize_reserve_minor=p_reserve, prize_secured=(p_reserve >= prize_obligation_minor)
   WHERE id=p_competition AND legal_entity_id=current_entity() AND state='DRAFT';
  IF NOT FOUND THEN RETURN 'NOT_DRAFT'; END IF;
  PERFORM audit(current_entity(), 'prize.secured', p_competition, jsonb_build_object('reserve', p_reserve, 'evidence', p_evidence_sha256));
  RETURN 'OK';
END $$;

CREATE FUNCTION open_competition(p_competition uuid) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE c record;
BEGIN
  IF NOT staff_has('COMP_OPS') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  SELECT * INTO c FROM competitions WHERE id=p_competition AND legal_entity_id=current_entity() FOR UPDATE;
  IF c.state <> 'DRAFT' THEN RETURN 'NOT_DRAFT'; END IF;
  IF NOT EXISTS (SELECT 1 FROM rule_versions WHERE id=c.rule_version_id AND state='APPROVED') THEN RETURN 'RULE_NOT_APPROVED'; END IF;
  IF NOT c.prize_secured THEN RETURN 'RESERVE_SHORTFALL'; END IF;
  UPDATE competitions SET state='OPEN' WHERE id=p_competition;
  PERFORM audit(current_entity(), 'competition.opened', p_competition, '{}');
  RETURN 'OK';
END $$;

-- Hash-chain verification of the audit log for an entity (auditor-callable).
CREATE FUNCTION verify_audit_chain() RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE r record; v_prev char(64) := repeat('0',64); v_calc char(64); v_n int := 0;
BEGIN
  FOR r IN SELECT * FROM audit_log WHERE legal_entity_id=current_entity() ORDER BY id LOOP
    v_calc := encode(sha256(convert_to(v_prev || '|' || coalesce(r.actor_id::text,'') || '|' || r.action || '|' ||
      coalesce(r.object_id::text,'') || '|' || r.payload::text || '|' || to_char(r.at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US'),'UTF8')),'hex');
    IF r.prev_hash <> v_prev OR r.hash <> v_calc THEN
      RETURN jsonb_build_object('ok', false, 'broken_at', r.id, 'checked', v_n); END IF;
    v_prev := r.hash; v_n := v_n + 1;
  END LOOP;
  RETURN jsonb_build_object('ok', true, 'checked', v_n, 'head', v_prev);
END $$;

REVOKE ALL ON FUNCTION staff_has(text), verify_customer_identity(uuid,boolean,text), approve_rule(uuid),
  create_competition(char,text,text,uuid,timestamptz,timestamptz,bigint,char,int,int,int,bigint),
  secure_prize(uuid,bigint,char), open_competition(uuid), verify_audit_chain() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION staff_has(text), verify_customer_identity(uuid,boolean,text), approve_rule(uuid),
  create_competition(char,text,text,uuid,timestamptz,timestamptz,bigint,char,int,int,int,bigint),
  secure_prize(uuid,bigint,char), open_competition(uuid), verify_audit_chain() TO veriq_app;
GRANT EXECUTE ON FUNCTION verify_audit_chain() TO veriq_auditor;
RESET ROLE;

-- Gap 3 (found by tests): trigger/helper functions resolved tables via the caller's search_path.
-- A lookalike table in another schema could have hijacked the posted-journal guard. Pin every function.
SET ROLE veriq_owner;
DO $$ DECLARE f record; BEGIN
  FOR f IN SELECT p.oid::regprocedure AS sig FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='veriq' LOOP
    EXECUTE format('ALTER FUNCTION %s SET search_path = veriq, pg_temp', f.sig);
  END LOOP;
END $$;
RESET ROLE;
