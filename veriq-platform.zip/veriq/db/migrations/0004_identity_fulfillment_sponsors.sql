-- VERIQ 0004 — passkey identity + revocable sessions, single-use challenges, encrypted PII with blind index,
-- sponsors (privacy-safe reporting), serial prize inventory, claims, dual-control delivery, Telegram linking,
-- RFC 3161 witness receipts. Also closes two grants: evidence and rule drafts now require a role-checked command.
SET ROLE veriq_owner;
SET search_path = veriq, public;

ALTER TABLE staff_users DROP CONSTRAINT staff_users_roles_check;
ALTER TABLE staff_users ADD CONSTRAINT staff_users_roles_check CHECK (roles <@ ARRAY['CEO','CFO','CTO','COMPLIANCE','DEPLOYMENT',
  'COMP_OPS','FINANCE','SUPPORT','FRAUD','AUDITOR','INFRA_ADMIN','INVENTORY','FULFILLMENT','SPONSOR']::text[]);

-- ---------- Close grants: evidence and rules only through role-checked commands ----------
REVOKE INSERT ON authorization_evidence, rule_versions FROM veriq_app;

CREATE FUNCTION record_evidence(p_auth uuid, p_kind text, p_sha256 char(64), p_uri text, p_expires timestamptz) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid;
BEGIN
  IF NOT staff_has('COMPLIANCE') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  INSERT INTO authorization_evidence(authorization_id, legal_entity_id, kind, sha256, storage_uri, expires_at, recorded_by)
    VALUES (p_auth, current_entity(), p_kind, p_sha256, p_uri, p_expires, current_actor()) RETURNING id INTO v;
  PERFORM audit(current_entity(), 'authorization.evidence', p_auth, jsonb_build_object('kind', p_kind, 'sha256', p_sha256));
  RETURN v;
END $$;

CREATE FUNCTION draft_rule(p_body jsonb) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid;
BEGIN
  IF NOT staff_has('COMP_OPS') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  INSERT INTO rule_versions(legal_entity_id, body, rule_hash, created_by) VALUES (current_entity(), p_body, 'pending', current_actor()) RETURNING id INTO v;
  PERFORM audit(current_entity(), 'rule.drafted', v, '{}');
  RETURN v;
END $$;

-- ---------- Encrypted PII + blind index ----------
ALTER TABLE customers ADD COLUMN pii_key_id text, ADD COLUMN pii_wrapped_dek bytea, ADD COLUMN phone_blind_index char(64);
CREATE UNIQUE INDEX customers_phone_bidx ON customers(legal_entity_id, phone_blind_index) WHERE phone_blind_index IS NOT NULL;
GRANT INSERT (pii_key_id, pii_wrapped_dek, phone_blind_index) ON customers TO veriq_app;
GRANT UPDATE (pii_ciphertext, pii_key_id, pii_wrapped_dek) ON customers TO veriq_app;   -- re-encryption on key rotation

-- ---------- Single-use challenges (WebAuthn, Telegram link) ----------
CREATE TABLE auth_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL REFERENCES legal_entities,
  purpose text NOT NULL CHECK (purpose IN ('WEBAUTHN_REGISTER','WEBAUTHN_AUTH','TELEGRAM_LINK')),
  subject_id uuid, subject_kind text CHECK (subject_kind IN ('customer','staff')),
  challenge_hash char(64) NOT NULL,
  expires_at timestamptz NOT NULL, consumed_at timestamptz,
  attempts int NOT NULL DEFAULT 0,
  UNIQUE (legal_entity_id, purpose, challenge_hash));

CREATE FUNCTION issue_challenge(p_purpose text, p_subject uuid, p_kind text, p_hash char(64), p_ttl_seconds int) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid;
BEGIN
  IF p_ttl_seconds NOT BETWEEN 30 AND 600 THEN RAISE EXCEPTION 'BAD_TTL' USING ERRCODE='VQ907'; END IF;
  INSERT INTO auth_challenges(legal_entity_id, purpose, subject_id, subject_kind, challenge_hash, expires_at)
    VALUES (current_entity(), p_purpose, p_subject, p_kind, p_hash, clock_timestamp() + make_interval(secs => p_ttl_seconds)) RETURNING id INTO v;
  RETURN v;
END $$;

-- Atomic single use: concurrent consumers race on the row lock; only one succeeds.
CREATE FUNCTION consume_challenge(p_purpose text, p_hash char(64)) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE c record;
BEGIN
  SELECT * INTO c FROM auth_challenges WHERE legal_entity_id=current_entity() AND purpose=p_purpose AND challenge_hash=p_hash FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'CHALLENGE_UNKNOWN'); END IF;
  IF c.consumed_at IS NOT NULL THEN RETURN jsonb_build_object('ok', false, 'code', 'CHALLENGE_REPLAYED'); END IF;
  IF c.expires_at <= clock_timestamp() THEN RETURN jsonb_build_object('ok', false, 'code', 'CHALLENGE_EXPIRED'); END IF;
  UPDATE auth_challenges SET consumed_at = clock_timestamp() WHERE id = c.id;
  RETURN jsonb_build_object('ok', true, 'subject_id', c.subject_id, 'subject_kind', c.subject_kind);
END $$;

-- ---------- Passkeys ----------
CREATE TABLE passkey_credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL REFERENCES legal_entities,
  principal_id uuid NOT NULL, principal_kind text NOT NULL CHECK (principal_kind IN ('customer','staff')),
  credential_id bytea NOT NULL UNIQUE, public_key bytea NOT NULL,
  sign_count bigint NOT NULL DEFAULT 0, aaguid text, backed_up boolean NOT NULL DEFAULT false,
  user_verified_at_registration boolean NOT NULL,
  label text, created_at timestamptz NOT NULL DEFAULT clock_timestamp(), last_used_at timestamptz, revoked_at timestamptz);

CREATE FUNCTION register_passkey(p_principal uuid, p_kind text, p_cred bytea, p_pub bytea, p_count bigint, p_aaguid text,
                                 p_backed_up boolean, p_uv boolean, p_label text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid;
BEGIN
  IF p_kind = 'staff' AND NOT p_uv THEN RAISE EXCEPTION 'STAFF_REQUIRES_USER_VERIFICATION' USING ERRCODE='VQ908'; END IF;
  IF p_kind = 'staff' AND NOT EXISTS (SELECT 1 FROM staff_users WHERE id=p_principal AND legal_entity_id=current_entity() AND active) THEN
    RAISE EXCEPTION 'UNKNOWN_PRINCIPAL' USING ERRCODE='VQ908'; END IF;
  IF p_kind = 'customer' AND NOT EXISTS (SELECT 1 FROM customers WHERE id=p_principal AND legal_entity_id=current_entity()) THEN
    RAISE EXCEPTION 'UNKNOWN_PRINCIPAL' USING ERRCODE='VQ908'; END IF;
  INSERT INTO passkey_credentials(legal_entity_id, principal_id, principal_kind, credential_id, public_key, sign_count, aaguid,
                                  backed_up, user_verified_at_registration, label)
    VALUES (current_entity(), p_principal, p_kind, p_cred, p_pub, p_count, p_aaguid, p_backed_up, p_uv, p_label) RETURNING id INTO v;
  PERFORM audit(current_entity(), 'passkey.registered', p_principal, jsonb_build_object('kind', p_kind, 'label', p_label));
  RETURN v;
END $$;

-- Counter regression => possible cloned authenticator => credential revoked, login refused.
CREATE FUNCTION record_passkey_use(p_cred bytea, p_new_count bigint) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE c record;
BEGIN
  SELECT * INTO c FROM passkey_credentials WHERE credential_id=p_cred AND legal_entity_id=current_entity() FOR UPDATE;
  IF NOT FOUND OR c.revoked_at IS NOT NULL THEN RETURN jsonb_build_object('ok', false, 'code', 'CREDENTIAL_REVOKED_OR_UNKNOWN'); END IF;
  IF (p_new_count > 0 OR c.sign_count > 0) AND p_new_count <= c.sign_count THEN
    UPDATE passkey_credentials SET revoked_at = clock_timestamp() WHERE id = c.id;
    PERFORM audit(current_entity(), 'passkey.clone_suspected', c.principal_id, jsonb_build_object('stored', c.sign_count, 'presented', p_new_count));
    RETURN jsonb_build_object('ok', false, 'code', 'CLONE_SUSPECTED');
  END IF;
  UPDATE passkey_credentials SET sign_count = p_new_count, last_used_at = clock_timestamp() WHERE id = c.id;
  RETURN jsonb_build_object('ok', true, 'principal_id', c.principal_id, 'principal_kind', c.principal_kind);
END $$;

-- ---------- Sessions: opaque tokens, only SHA-256 stored, revocable, short ----------
CREATE TABLE sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL REFERENCES legal_entities,
  principal_id uuid NOT NULL, principal_kind text NOT NULL CHECK (principal_kind IN ('customer','staff')),
  token_hash char(64) NOT NULL UNIQUE, auth_method text NOT NULL CHECK (auth_method IN ('passkey','telegram','recovery')),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(), expires_at timestamptz NOT NULL, revoked_at timestamptz,
  device_label text);

CREATE FUNCTION create_session(p_principal uuid, p_kind text, p_token_hash char(64), p_method text, p_device text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid; v_ttl interval;
BEGIN
  IF p_kind = 'staff' AND p_method <> 'passkey' THEN RAISE EXCEPTION 'STAFF_REQUIRES_PASSKEY' USING ERRCODE='VQ908'; END IF;
  v_ttl := CASE WHEN p_kind = 'staff' THEN interval '30 minutes' ELSE interval '12 hours' END;
  INSERT INTO sessions(legal_entity_id, principal_id, principal_kind, token_hash, auth_method, expires_at, device_label)
    VALUES (current_entity(), p_principal, p_kind, p_token_hash, p_method, clock_timestamp() + v_ttl, p_device) RETURNING id INTO v;
  PERFORM audit(current_entity(), 'session.created', p_principal, jsonb_build_object('method', p_method));
  RETURN v;
END $$;

CREATE FUNCTION resolve_session(p_token_hash char(64)) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE s record; v_roles text[];
BEGIN
  SELECT * INTO s FROM sessions WHERE token_hash=p_token_hash AND legal_entity_id=current_entity();
  IF NOT FOUND OR s.revoked_at IS NOT NULL OR s.expires_at <= clock_timestamp() THEN RETURN NULL; END IF;
  IF s.principal_kind = 'staff' THEN
    SELECT roles INTO v_roles FROM staff_users WHERE id=s.principal_id AND legal_entity_id=current_entity() AND active;
    IF v_roles IS NULL THEN RETURN NULL; END IF;   -- deactivated staff lose access immediately
  END IF;
  RETURN jsonb_build_object('session_id', s.id, 'principal_id', s.principal_id, 'kind', s.principal_kind, 'roles', coalesce(to_jsonb(v_roles), '[]'::jsonb));
END $$;

CREATE FUNCTION revoke_sessions(p_principal uuid, p_except uuid DEFAULT NULL) RETURNS int
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE n int;
BEGIN
  UPDATE sessions SET revoked_at = clock_timestamp()
   WHERE legal_entity_id=current_entity() AND principal_id=p_principal AND revoked_at IS NULL AND (p_except IS NULL OR id <> p_except);
  GET DIAGNOSTICS n = ROW_COUNT;
  PERFORM audit(current_entity(), 'session.revoked', p_principal, jsonb_build_object('count', n));
  RETURN n;
END $$;

-- ---------- Telegram ----------
CREATE TABLE telegram_updates (legal_entity_id uuid NOT NULL, update_id bigint NOT NULL, received_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (legal_entity_id, update_id));
CREATE FUNCTION telegram_seen(p_update bigint) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
BEGIN
  INSERT INTO telegram_updates(legal_entity_id, update_id) VALUES (current_entity(), p_update) ON CONFLICT DO NOTHING;
  RETURN NOT FOUND;   -- true => duplicate delivery, ignore
END $$;

CREATE FUNCTION link_telegram(p_code_hash char(64), p_tg_user text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE r jsonb;
BEGIN
  r := consume_challenge('TELEGRAM_LINK', p_code_hash);
  IF NOT (r->>'ok')::boolean THEN RETURN r; END IF;
  IF EXISTS (SELECT 1 FROM channel_links WHERE channel='TELEGRAM' AND external_principal=p_tg_user AND unlinked_at IS NULL) THEN
    RETURN jsonb_build_object('ok', false, 'code', 'TELEGRAM_ALREADY_LINKED'); END IF;
  UPDATE channel_links SET unlinked_at = clock_timestamp()
   WHERE legal_entity_id=current_entity() AND customer_id=(r->>'subject_id')::uuid AND channel='TELEGRAM' AND unlinked_at IS NULL;
  INSERT INTO channel_links(legal_entity_id, customer_id, channel, external_principal) VALUES (current_entity(), (r->>'subject_id')::uuid, 'TELEGRAM', p_tg_user);
  PERFORM audit(current_entity(), 'telegram.linked', (r->>'subject_id')::uuid, '{}');
  RETURN jsonb_build_object('ok', true, 'customer_id', r->>'subject_id');
END $$;

CREATE FUNCTION unlink_telegram(p_customer uuid) RETURNS int
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE n int;
BEGIN
  UPDATE channel_links SET unlinked_at = clock_timestamp()
   WHERE legal_entity_id=current_entity() AND customer_id=p_customer AND channel='TELEGRAM' AND unlinked_at IS NULL;
  GET DIAGNOSTICS n = ROW_COUNT;
  PERFORM revoke_sessions(p_customer);
  RETURN n;
END $$;
REVOKE INSERT, UPDATE ON channel_links FROM veriq_app;

-- ---------- Sponsors ----------
CREATE TABLE sponsors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL REFERENCES legal_entities, name text NOT NULL,
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','SUSPENDED')),
  UNIQUE (id, legal_entity_id));
CREATE TABLE sponsor_members (
  sponsor_id uuid NOT NULL, staff_id uuid NOT NULL, legal_entity_id uuid NOT NULL,
  PRIMARY KEY (sponsor_id, staff_id),
  FOREIGN KEY (sponsor_id, legal_entity_id) REFERENCES sponsors(id, legal_entity_id),
  FOREIGN KEY (staff_id, legal_entity_id) REFERENCES staff_users(id, legal_entity_id));
ALTER TABLE competitions ADD COLUMN sponsor_id uuid, ADD COLUMN claim_period interval NOT NULL DEFAULT interval '30 days',
  ADD CONSTRAINT competitions_sponsor_fk FOREIGN KEY (sponsor_id, legal_entity_id) REFERENCES sponsors(id, legal_entity_id);

CREATE FUNCTION assign_sponsor(p_competition uuid, p_sponsor uuid) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
BEGIN
  IF NOT staff_has('COMP_OPS') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  UPDATE competitions SET sponsor_id = p_sponsor WHERE id=p_competition AND legal_entity_id=current_entity() AND state='DRAFT';
  IF NOT FOUND THEN RETURN 'NOT_DRAFT'; END IF;
  RETURN 'OK';
END $$;

-- Privacy-safe sponsor report: aggregate only, own campaigns only, small cells suppressed (k=10). No participant identity.
CREATE FUNCTION sponsor_report(p_competition uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE c record; v_entries bigint; v_people bigint; v_channels jsonb; k constant int := 10;
BEGIN
  IF NOT staff_has('SPONSOR') THEN RETURN jsonb_build_object('ok', false, 'code', 'ROLE_NOT_HELD'); END IF;
  SELECT cp.* INTO c FROM competitions cp JOIN sponsor_members m ON m.sponsor_id=cp.sponsor_id AND m.staff_id=current_actor()
   WHERE cp.id=p_competition AND cp.legal_entity_id=current_entity();
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'NOT_FOUND'); END IF;
  SELECT count(*), count(DISTINCT customer_id) INTO v_entries, v_people FROM entries WHERE competition_id=p_competition;
  SELECT coalesce(jsonb_object_agg(channel, CASE WHEN n < k THEN NULL ELSE n END), '{}') INTO v_channels
    FROM (SELECT channel, count(*) n FROM entries WHERE competition_id=p_competition GROUP BY channel) x;
  RETURN jsonb_build_object('ok', true, 'title', c.title, 'state', c.state,
    'entries', CASE WHEN v_entries < k THEN NULL ELSE v_entries END,
    'entrants', CASE WHEN v_people < k THEN NULL ELSE v_people END,
    'by_channel', v_channels, 'suppression_threshold', k, 'prize_secured', c.prize_secured,
    'delivered', EXISTS (SELECT 1 FROM claims cl WHERE cl.competition_id=p_competition AND cl.state='DELIVERED'));
END $$;

-- ---------- Prize inventory (serial-controlled) ----------
CREATE TABLE prize_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL, competition_id uuid NOT NULL,
  model text NOT NULL, serial text NOT NULL, warranty_months int NOT NULL CHECK (warranty_months >= 0),
  valuation_minor bigint NOT NULL CHECK (valuation_minor > 0), currency char(3) NOT NULL DEFAULT 'ETB',
  evidence_sha256 char(64) NOT NULL CHECK (evidence_sha256 ~ '^[0-9a-f]{64}$'),
  state text NOT NULL DEFAULT 'IN_STOCK' CHECK (state IN ('IN_STOCK','ALLOCATED','DISPATCHED','DELIVERED','RETURNED')),
  received_by uuid NOT NULL,
  FOREIGN KEY (competition_id, legal_entity_id) REFERENCES competitions(id, legal_entity_id),
  UNIQUE (legal_entity_id, model, serial), UNIQUE (id, legal_entity_id));

CREATE FUNCTION receive_prize_item(p_competition uuid, p_model text, p_serial text, p_warranty int, p_value bigint, p_evidence char(64)) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid;
BEGIN
  IF NOT staff_has('INVENTORY') THEN RAISE EXCEPTION 'ROLE_NOT_HELD' USING ERRCODE='VQ906'; END IF;
  INSERT INTO prize_items(legal_entity_id, competition_id, model, serial, warranty_months, valuation_minor, evidence_sha256, received_by)
    VALUES (current_entity(), p_competition, p_model, p_serial, p_warranty, p_value, p_evidence, current_actor()) RETURNING id INTO v;
  PERFORM audit(current_entity(), 'prize.received', v, jsonb_build_object('serial', p_serial));
  RETURN v;
END $$;

-- ---------- Claims and delivery ----------
CREATE TABLE claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL, competition_id uuid NOT NULL UNIQUE, entry_id uuid NOT NULL, customer_id uuid NOT NULL,
  state text NOT NULL DEFAULT 'OPENED' CHECK (state IN ('OPENED','APPROVED','REJECTED','ALLOCATED','DISPATCHED','DELIVERED','EXPIRED')),
  opened_at timestamptz NOT NULL DEFAULT clock_timestamp(), deadline timestamptz NOT NULL,
  reviewed_by uuid, review_note text, prize_item_id uuid,
  delivery_address_ciphertext bytea,
  FOREIGN KEY (competition_id, legal_entity_id) REFERENCES competitions(id, legal_entity_id),
  FOREIGN KEY (customer_id, legal_entity_id) REFERENCES customers(id, legal_entity_id),
  FOREIGN KEY (prize_item_id, legal_entity_id) REFERENCES prize_items(id, legal_entity_id),
  UNIQUE (id, legal_entity_id));

CREATE TABLE deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_entity_id uuid NOT NULL, claim_id uuid NOT NULL UNIQUE,
  carrier text NOT NULL, tracking_ref text NOT NULL,
  dispatched_by uuid NOT NULL, dispatched_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  scanned_serial text, recipient_signature_sha256 char(64), handover_photo_sha256 char(64),
  confirmed_by uuid, delivered_at timestamptz,
  CHECK (delivered_at IS NULL OR (confirmed_by IS NOT NULL AND confirmed_by <> dispatched_by
         AND scanned_serial IS NOT NULL AND recipient_signature_sha256 IS NOT NULL AND handover_photo_sha256 IS NOT NULL)),
  FOREIGN KEY (claim_id, legal_entity_id) REFERENCES claims(id, legal_entity_id));

CREATE FUNCTION open_claim(p_competition uuid, p_customer uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE r record; v uuid; c record;
BEGIN
  SELECT rr.*, e.customer_id AS winner_customer INTO r FROM result_runs rr JOIN entries e ON e.id = rr.winning_entry_id
   WHERE rr.competition_id=p_competition AND rr.legal_entity_id=current_entity() AND rr.published_at IS NOT NULL AND rr.outcome='WINNER';
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'NO_PUBLISHED_WINNER'); END IF;
  IF r.winner_customer <> p_customer THEN RETURN jsonb_build_object('ok', false, 'code', 'NOT_THE_WINNER'); END IF;
  SELECT * INTO c FROM competitions WHERE id=p_competition;
  IF clock_timestamp() > r.published_at + c.claim_period THEN RETURN jsonb_build_object('ok', false, 'code', 'CLAIM_PERIOD_ENDED'); END IF;
  INSERT INTO claims(legal_entity_id, competition_id, entry_id, customer_id, deadline)
    VALUES (current_entity(), p_competition, r.winning_entry_id, p_customer, r.published_at + c.claim_period)
    ON CONFLICT (competition_id) DO NOTHING RETURNING id INTO v;
  IF v IS NULL THEN SELECT id INTO v FROM claims WHERE competition_id=p_competition; END IF;
  PERFORM audit(current_entity(), 'claim.opened', v, '{}');
  RETURN jsonb_build_object('ok', true, 'claim_id', v);
END $$;

CREATE FUNCTION review_claim(p_claim uuid, p_approve boolean, p_note text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
BEGIN
  IF NOT staff_has('COMPLIANCE') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  UPDATE claims SET state = CASE WHEN p_approve THEN 'APPROVED' ELSE 'REJECTED' END, reviewed_by=current_actor(), review_note=p_note
   WHERE id=p_claim AND legal_entity_id=current_entity() AND state='OPENED'
     AND EXISTS (SELECT 1 FROM customers cu WHERE cu.id=claims.customer_id AND cu.kyc_state='VERIFIED' AND cu.age_verified);
  IF NOT FOUND THEN RETURN 'NOT_REVIEWABLE'; END IF;
  PERFORM audit(current_entity(), 'claim.reviewed', p_claim, jsonb_build_object('approved', p_approve));
  RETURN 'OK';
END $$;

CREATE FUNCTION allocate_prize(p_claim uuid, p_item uuid) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE cl record; it record;
BEGIN
  IF NOT staff_has('INVENTORY') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  SELECT * INTO cl FROM claims WHERE id=p_claim AND legal_entity_id=current_entity() FOR UPDATE;
  SELECT * INTO it FROM prize_items WHERE id=p_item AND legal_entity_id=current_entity() FOR UPDATE;
  IF cl.state <> 'APPROVED' THEN RETURN 'CLAIM_NOT_APPROVED'; END IF;
  IF it.state <> 'IN_STOCK' OR it.competition_id <> cl.competition_id THEN RETURN 'ITEM_NOT_AVAILABLE'; END IF;
  UPDATE prize_items SET state='ALLOCATED' WHERE id=p_item;
  UPDATE claims SET state='ALLOCATED', prize_item_id=p_item WHERE id=p_claim;
  INSERT INTO outbox(legal_entity_id,aggregate_type,aggregate_id,event_type,payload,classification)
    VALUES (current_entity(),'claim',p_claim,'prize.allocated.v1',jsonb_build_object('item',p_item),'NO_PII');
  PERFORM audit(current_entity(), 'prize.allocated', p_claim, jsonb_build_object('item', p_item, 'serial', it.serial));
  RETURN 'OK';
END $$;

CREATE FUNCTION dispatch_prize(p_claim uuid, p_carrier text, p_tracking text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE cl record;
BEGIN
  IF NOT staff_has('FULFILLMENT') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  SELECT * INTO cl FROM claims WHERE id=p_claim AND legal_entity_id=current_entity() FOR UPDATE;
  IF cl.state <> 'ALLOCATED' THEN RETURN 'NOT_ALLOCATED'; END IF;
  INSERT INTO deliveries(legal_entity_id, claim_id, carrier, tracking_ref, dispatched_by) VALUES (current_entity(), p_claim, p_carrier, p_tracking, current_actor());
  UPDATE claims SET state='DISPATCHED' WHERE id=p_claim;
  UPDATE prize_items SET state='DISPATCHED' WHERE id=cl.prize_item_id;
  PERFORM audit(current_entity(), 'prize.dispatched', p_claim, jsonb_build_object('carrier', p_carrier));
  RETURN 'OK';
END $$;

-- "Delivered" requires: serial scan matches allocated item, recipient signature + handover photo evidence,
-- and a different person from the dispatcher. Posts Dr prize obligation / Cr prize inventory.
CREATE FUNCTION confirm_delivery(p_claim uuid, p_scanned_serial text, p_sig_sha char(64), p_photo_sha char(64)) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE cl record; d record; it record;
BEGIN
  IF NOT staff_has('FULFILLMENT') THEN RETURN 'ROLE_NOT_HELD'; END IF;
  SELECT * INTO cl FROM claims WHERE id=p_claim AND legal_entity_id=current_entity() FOR UPDATE;
  IF cl.state <> 'DISPATCHED' THEN RETURN 'NOT_DISPATCHED'; END IF;
  SELECT * INTO d FROM deliveries WHERE claim_id=p_claim FOR UPDATE;
  SELECT * INTO it FROM prize_items WHERE id=cl.prize_item_id FOR UPDATE;
  IF d.dispatched_by = current_actor() THEN RETURN 'DUAL_CONTROL_REQUIRED'; END IF;
  IF p_scanned_serial IS DISTINCT FROM it.serial THEN RETURN 'SERIAL_MISMATCH'; END IF;
  IF p_sig_sha !~ '^[0-9a-f]{64}$' OR p_photo_sha !~ '^[0-9a-f]{64}$' THEN RETURN 'PROOF_REQUIRED'; END IF;
  UPDATE deliveries SET scanned_serial=p_scanned_serial, recipient_signature_sha256=p_sig_sha, handover_photo_sha256=p_photo_sha,
         confirmed_by=current_actor(), delivered_at=clock_timestamp() WHERE id=d.id;
  UPDATE claims SET state='DELIVERED' WHERE id=p_claim;
  UPDATE prize_items SET state='DELIVERED' WHERE id=it.id;
  PERFORM post_journal('prize.delivered', p_claim::text, 'Prize handed over',
    jsonb_build_array(jsonb_build_object('account','2200-PRIZE-OBLIGATION','currency',it.currency,'amount_minor',it.valuation_minor),
                      jsonb_build_object('account','1300-PRIZE-INVENTORY','currency',it.currency,'amount_minor',-it.valuation_minor)));
  INSERT INTO outbox(legal_entity_id,aggregate_type,aggregate_id,event_type,payload,classification)
    VALUES (current_entity(),'claim',p_claim,'prize.delivered.v1',jsonb_build_object('item',it.id),'NO_PII');
  RETURN 'OK';
END $$;

CREATE FUNCTION expire_claims() RETURNS int
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE n int;
BEGIN
  UPDATE claims SET state='EXPIRED' WHERE legal_entity_id=current_entity() AND state IN ('OPENED','APPROVED') AND deadline < clock_timestamp();
  GET DIAGNOSTICS n = ROW_COUNT; RETURN n;
END $$;

-- ---------- RFC 3161 witness receipts (append-only) ----------
CREATE TABLE witness_receipts (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  legal_entity_id uuid NOT NULL, witness_root_id bigint NOT NULL REFERENCES witness_roots,
  tsa_name text NOT NULL, message_imprint_sha256 char(64) NOT NULL, gen_time timestamptz NOT NULL,
  serial_number text NOT NULL, token_der bytea NOT NULL, recorded_at timestamptz NOT NULL DEFAULT clock_timestamp());
CREATE TRIGGER witness_receipts_immutable BEFORE UPDATE OR DELETE ON witness_receipts FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

CREATE FUNCTION attach_witness(p_competition uuid, p_tsa text, p_imprint char(64), p_gen timestamptz, p_serial text, p_token bytea) RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE w record; v bigint;
BEGIN
  SELECT * INTO w FROM witness_roots WHERE competition_id=p_competition AND legal_entity_id=current_entity() ORDER BY through_seq DESC LIMIT 1;
  IF NOT FOUND THEN RAISE EXCEPTION 'NO_WITNESS_ROOT' USING ERRCODE='VQ909'; END IF;
  INSERT INTO witness_receipts(legal_entity_id, witness_root_id, tsa_name, message_imprint_sha256, gen_time, serial_number, token_der)
    VALUES (current_entity(), w.id, p_tsa, p_imprint, p_gen, p_serial, p_token) RETURNING id INTO v;
  PERFORM audit(current_entity(), 'witness.timestamped', p_competition, jsonb_build_object('tsa', p_tsa, 'serial', p_serial));
  RETURN v;
END $$;

-- ---------- RLS + grants for new tables ----------
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['auth_challenges','passkey_credentials','sessions','telegram_updates','sponsors','sponsor_members',
                           'prize_items','claims','deliveries','witness_receipts'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_scope ON %I AS PERMISSIVE USING (legal_entity_id = veriq.current_entity()) WITH CHECK (legal_entity_id = veriq.current_entity())', t);
    EXECUTE format('CREATE POLICY tenant_guard ON %I AS RESTRICTIVE USING (veriq.current_entity() IS NOT NULL) WITH CHECK (veriq.current_entity() IS NOT NULL)', t);
  END LOOP;
END $$;
-- Secrets never readable by the app role: token hashes, public keys and challenge hashes are reached only via functions.
GRANT SELECT ON sponsors, prize_items, claims, deliveries, witness_receipts TO veriq_app, veriq_auditor;
GRANT SELECT (id, legal_entity_id, principal_id, principal_kind, label, created_at, last_used_at, revoked_at, backed_up) ON passkey_credentials TO veriq_app;
GRANT SELECT (id, legal_entity_id, principal_id, principal_kind, auth_method, created_at, expires_at, revoked_at, device_label) ON sessions TO veriq_app;
GRANT SELECT (credential_id, public_key, sign_count) ON passkey_credentials TO veriq_app;  -- needed to verify assertions
GRANT UPDATE (delivery_address_ciphertext) ON claims TO veriq_app;

DO $$ DECLARE f record; BEGIN
  FOR f IN SELECT p.oid::regprocedure AS sig FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='veriq' LOOP
    EXECUTE format('ALTER FUNCTION %s SET search_path = veriq, pg_temp', f.sig);
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', f.sig);
  END LOOP;
END $$;
GRANT EXECUTE ON FUNCTION record_evidence(uuid,text,char,text,timestamptz), draft_rule(jsonb),
  issue_challenge(text,uuid,text,char,int), consume_challenge(text,char),
  register_passkey(uuid,text,bytea,bytea,bigint,text,boolean,boolean,text), record_passkey_use(bytea,bigint),
  create_session(uuid,text,char,text,text), resolve_session(char), revoke_sessions(uuid,uuid),
  telegram_seen(bigint), link_telegram(char,text), unlink_telegram(uuid),
  assign_sponsor(uuid,uuid), sponsor_report(uuid), receive_prize_item(uuid,text,text,int,bigint,char),
  open_claim(uuid,uuid), review_claim(uuid,boolean,text), allocate_prize(uuid,uuid), dispatch_prize(uuid,text,text),
  confirm_delivery(uuid,text,char,char), expire_claims(), attach_witness(uuid,text,char,timestamptz,text,bytea) TO veriq_app;
RESET ROLE;
