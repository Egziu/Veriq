-- VERIQ 0005 — revoke exactly one session by token hash; audit every staff read of decrypted PII.
SET ROLE veriq_owner;
SET search_path = veriq, public;

CREATE FUNCTION revoke_session(p_token_hash char(64)) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
DECLARE v uuid; p uuid;
BEGIN
  UPDATE sessions SET revoked_at = clock_timestamp()
   WHERE token_hash = p_token_hash AND legal_entity_id = current_entity() AND revoked_at IS NULL
   RETURNING id, principal_id INTO v, p;
  IF v IS NULL THEN RETURN false; END IF;
  PERFORM audit(current_entity(), 'session.signed_out', p, jsonb_build_object('session', v));
  RETURN true;
END $$;

CREATE FUNCTION audit_pii_read(p_object uuid, p_purpose text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = veriq, pg_temp AS $$
BEGIN
  IF current_actor() IS NULL THEN RAISE EXCEPTION 'NO_ACTOR' USING ERRCODE='VQ910'; END IF;
  PERFORM audit(current_entity(), 'pii.read', p_object, jsonb_build_object('purpose', p_purpose));
END $$;

REVOKE ALL ON FUNCTION revoke_session(char), audit_pii_read(uuid,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION revoke_session(char), audit_pii_read(uuid,text) TO veriq_app;

GRANT SELECT ON sponsor_members TO veriq_app, veriq_auditor;   -- RLS-scoped; needed for the sponsor's own campaign list
RESET ROLE;
