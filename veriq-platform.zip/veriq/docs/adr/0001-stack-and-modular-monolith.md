# ADR 0001 — Python/FastAPI modular monolith on PostgreSQL; critical logic in DB command functions

Status: Accepted for pilot (revisit at measured load). Date: 2026-10-15.

## Decision
- Transactional core: Python 3.12 + FastAPI 0.143 as a modular monolith. Pure rules (`packages/rules`) and an
  independent verifier (`packages/verifier`) have no HTTP/ORM dependency.
- Truth: PostgreSQL 16. Acceptance, close, ledger posting, payment application, authorization transitions and
  result publication are SECURITY DEFINER command functions. The app role has no direct write path to those tables.
- Redis (later) only for ephemeral rate limits. Never the record of money or entries.

## FastAPI vs Go
| Criterion | FastAPI | Go |
|---|---|---|
| Deterministic correctness | Equal: correctness lives in SQL + pure rules lib, both language-agnostic | Equal |
| Latency | Measured locally: p95 312 ms at 16 concurrent clients on one hot competition, dominated by per-call connection setup and the per-competition lock — not by Python | Would not remove the lock bound |
| Team skills / hiring in Ethiopia | Broader Python pool | Smaller pool |
| Ops cost | One runtime | One runtime |
Go is reconsidered only for a measured hot path after connection pooling is in place.

## Consequences
Per-competition acceptance is serialized by design (contiguous sequence + linearizable close). Ceiling must be
measured with pooling (PgBouncer transaction mode) against the pilot profile before setting customer-facing limits.
