# ADR 0002 — Tenancy: FORCE RLS + RESTRICTIVE guard + composite foreign keys

Entity context = `SET LOCAL veriq.entity_id` from verified token claims, inside each transaction (no session leakage
through pools). Every tenant table: ENABLE + FORCE RLS, a PERMISSIVE `legal_entity_id = current_entity()` policy and a
RESTRICTIVE policy requiring non-null context. Composite FKs `(id, legal_entity_id)` make cross-entity references
impossible even if RLS were disabled. App role: LOGIN, NOSUPERUSER, NOBYPASSRLS, owns nothing (asserted in tests).

Residual risk: the server process chooses the entity from claims. A compromised API process can act within any entity
whose tokens it can mint. Mitigation for production: per-entity signing keys in KMS, entity-scoped service identities.
