# ADR 0003 — Acceptance linearization point and contiguous sequence

`accept_entry` takes `SELECT … FOR UPDATE` on the competition row. `close_competition` takes the same lock.
Therefore every committed entry has seq ≤ high_water and every later attempt observes state ≠ OPEN.
Sequence = `next_seq` column updated in the same transaction (never a PostgreSQL SEQUENCE, which can gap on abort).
Each receipt hash chains to the previous (`prev_receipt_hash`), so the chain head at freeze commits to the entire
ordered dataset; it is recorded in `witness_roots` for external timestamping.
Rejections return a code without side effects and consume no sequence number.
Evidence: tests/integration/test_acceptance.py::test_close_race_no_entry_after_close, ::test_concurrent_entries_get_contiguous_sequence.
