# ADR 0004 — Identity (development stub vs production)

Development uses HMAC compact tokens (`veriq_core/security.py`) so the server-claims contract can be tested.
Production: OIDC provider with passkeys (WebAuthn) for customers, phishing-resistant MFA (FIDO2) for staff,
short sessions, revocation, no SMS-only admin recovery, assurance levels per NIST SP 800-63-4. NOT IMPLEMENTED YET.
