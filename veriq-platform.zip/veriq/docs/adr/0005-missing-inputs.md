# ADR 0005 — Missing inputs recorded at audit

The VERIQ Enterprise Package (blueprint, delivery register, reference verifier, draft schema, draft OpenAPI) was not
provided in this session. This build follows the master prompt only. When the package arrives: diff its schema and
OpenAPI against `db/migrations` and `openapi/`, record each divergence here, and choose the safer behaviour.
No legal opinion, regulator approval, provider acceptance or supplier contract exists; all such evidence in fixtures is synthetic.
