# ADR 0006 — Passkeys and opaque sessions (supersedes the identity stub in ADR 0004)

Customers and staff authenticate with WebAuthn passkeys (py_webauthn 3.0.1). RP ID `veriq.et`; allowed origins are an
explicit list. Challenges: 32 random bytes, SHA-256 stored, 5-minute expiry, consumed atomically and **committed even when
authentication fails** (regression-tested). Staff: user verification required at registration and every login; sessions
30 min; deactivation ends sessions at the next request. Customers: UV preferred; sessions 12 h. Sign-count regression
revokes the credential. Tokens are `vq1.<entity>.<256-bit>`; only SHA-256 is stored. Browsers get HttpOnly/Secure/
SameSite=Strict cookies plus a double-submit CSRF token; native apps get the token for Keystore/Keychain storage.
Development HMAC tokens are refused when `VERIQ_ENV=production`.
Not built: account recovery after losing every passkey (needs an in-person or KYC-provider re-verification process).
