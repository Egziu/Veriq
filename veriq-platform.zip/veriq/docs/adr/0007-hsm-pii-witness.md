# ADR 0007 — HSM keys, envelope encryption, RFC 3161 witnesses

Per legal entity, three non-extractable keys in a PKCS#11 HSM, created at a witnessed ceremony (scripts/ops/hsm_ceremony.py):
ECDSA P-256 (manifest signatures; P-256 rather than Ed25519 because mainstream HSMs and cloud KMS support it), AES-256
KEK (wraps per-record data keys with AES-GCM; AAD binds ciphertext to entity + record), HMAC-SHA256 (blind index for phone
lookup). Development keyring is refused in production. Tested with SoftHSM2; production uses a certified HSM via its PKCS#11
library — run the same suite against it before go-live. **HSM key backup is separate from database backup** (vendor
cloning/backup to a second HSM); a database restore is worthless for results verification without the public key.

Witness: each published result's commitment (competition, manifest digest, chain head, high-water) is time-stamped by
>= `VERIQ_TSA_MIN` (default 2) independent RFC 3161 TSAs. The token verifier lives in `packages/verifier` so any auditor
can run it. Production publication is refused without the witnesses.
