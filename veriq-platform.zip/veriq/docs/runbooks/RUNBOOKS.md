# VERIQ operational runbooks (v1)

## R1 Restore / failover (rehearsed: scripts/drills/backup_restore_drill.py — run monthly and after major changes)
1. Primary lost: confirm the synchronous standby is current (`pg_stat_replication` before the incident; drill proved RPO=0).
2. Promote: `pg_ctl promote -D <standby>`; repoint `VERIQ_APP_DSN`; restart API pods; check `/ready`.
3. Suspend acceptance first if in doubt: transition every LIVE authorization to SUSPENDED (one command per row; reads stay up).
4. Verify before reopening: run the drill's integrity checks against the new primary (ledger, audit chains, receipt chains, RLS, results).
5. Point-in-time recovery (e.g. after destructive operator error): base backup + WAL archive with `recovery_target_time`.
6. Never "fix" entries, journals or results by hand. Corrections are reversal journals, cancellations, or new competitions.

## R2 Key events
- Signing-key rotation: ceremony creates a new key under a new label; new manifests use it; old public keys stay published forever.
- Suspected signing-key compromise: suspend publication, rotate, re-witness affected commitments, publish an incident notice.
- KEK rotation: create new KEK, re-wrap data keys (`pii_wrapped_dek`, `pii_key_id` are updatable), destroy old KEK after verification.

## R3 Telegram
- Bot token leak: revoke with @BotFather, set the new token in the secrets manager, `setWebhook` with a NEW secret_token, rotate `VERIQ_TELEGRAM_WEBHOOK_SECRET`.
- Bot outage: no impact on entries or results; customers use app/web.

## R4 Payment provider (paid products only, currently BLOCKED)
- Outage: provider row -> SUSPENDED (acceptance returns PROVIDER_SUSPENDED instantly). Late confirmations after close are refunded, never backdated.

## R5 Incident severity
SEV1: result integrity, ledger, PII exposure, cross-entity access -> suspend affected authorizations, preserve evidence, notify per legal advice.
SEV2: availability of acceptance; SEV3: degraded non-critical channels.
