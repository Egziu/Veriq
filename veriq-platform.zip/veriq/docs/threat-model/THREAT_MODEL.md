# VERIQ threat model and adversarial evidence (v0.2)

Assets: accepted entries and their order; frozen datasets; results; ledger; customer identity; country authorizations;
signing keys; prize inventory. Trust boundary: everything outside the DB command functions is untrusted for decisions.

| # | Attack | Control | Evidence (test) | Observed | Residual risk |
|---|---|---|---|---|---|
| 1 | Malicious admin replaces winner | result_runs immutable after publish (trigger, superuser too) | adversarial/…::test_malicious_admin_cannot_replace_published_winner | Denied | Trigger can be disabled by superuser → see #2 |
| 2 | DBA disables triggers and edits a frozen selection | Receipt hash chain + witnessed chain head + independent verifier | …::test_dba_snapshot_tamper_is_detected_by_independent_verifier | Detected (RECEIPT_TAMPERED) even with attacker-held signing key | Needs real external witness (timestamp authority) — NOT RUN |
| 3 | Close race / entry after close | Shared row lock, server clock | integration/test_acceptance.py::test_close_race… | 0 late entries; contiguous seq | Validated on one node only |
| 4 | Duplicate / reordered provider callback | UNIQUE(provider,event_id); transition table | …::test_duplicate_and_reordered_callbacks_apply_once | Applied once; late PENDING held | Real provider semantics unknown |
| 5 | "Mark paid" / fake screenshot | No app UPDATE on payment state; signed webhook only | …::test_app_cannot_mark_paid_directly, ::test_webhook_signature_replay_window | permission denied / rejected | Provider key custody |
| 6 | Forged Telegram initData / injected flags / stale / wrong bot | HMAC per official spec, duplicate-field and freshness checks | …::test_telegram_forgeries (5 cases), ::test_telegram_stale_and_wrong_bot | All rejected | Bot-token rotation runbook pending |
| 7 | Cross-entity read/write/command | FORCE RLS + restrictive policy + composite FKs | integration/test_rls_isolation.py | 0 rows; RLS violation; NOT_FOUND | Compromised API process (ADR 0002) |
| 8 | App self-verifies KYC / shortens self-exclusion | Column grants + trigger | …::test_app_cannot_self_verify_kyc, ::test_self_exclusion… | Denied | — |
| 9 | Forged approval / creator self-activation | Role check, 3 distinct approvers, creator excluded | integration/test_country_gate.py | Denied | Staff MFA not yet implemented |
| 10 | search_path hijack of guard triggers | All functions pinned `search_path = veriq, pg_temp` | adversarial/test_search_path_hijack.py | Denied (found by our own tests, fixed) | — |
| 11 | Omitted receipt in published dataset | Verifier COUNT + customer receipt inclusion | …::test_omitted_entry_detected | Detected | Customers must actually check |
| 12 | Audit log rewrite | Hash-chained audit_log + verify_audit_chain | …::test_audit_chain_detects_tamper | Detected | Chain head not yet externally witnessed |
| 13 | BOLA on receipts | Ownership predicate; identical 404 for absent/not-yours | e2e/test_api.py | 404 | — |
| 14 | Token tamper | HMAC verify (dev) | e2e/test_api.py::test_tampered_and_missing_tokens | 401 | Dev tokens ≠ production identity |
| 15 | Phishing site relays passkey login | WebAuthn origin + RP ID binding | test_passkeys_sessions::test_phishing_origin_and_wrong_rp_rejected | Rejected | — |
| 16 | Replayed / retried login challenge | Single-use challenge committed even on failure | ::test_login_then_assertion_replay_rejected, ::test_failed_assertion_still_burns_the_challenge | Rejected (bug found and fixed) | — |
| 17 | Cloned authenticator | Sign-count regression revokes credential (committed) | ::test_counter_regression_revokes_credential | Revoked permanently | Authenticators reporting counter 0 cannot be clone-checked |
| 18 | Stolen session cookie used cross-site | SameSite=Strict + double-submit CSRF | ::test_cookie_sessions_require_csrf_on_writes | Rejected | XSS on our origin would defeat CSRF; CSP nonce mitigates |
| 19 | Fired staff keeps access | Session resolution checks active flag | ::test_deactivated_staff_lose_access_immediately | 401 | — |
| 20 | Signing key exfiltration | Non-extractable HSM key | test_hsm_pii_witness::test_hsm_private_key_is_not_extractable | Read refused | HSM admin compromise is out of scope; ceremony + dual control |
| 21 | Ciphertext swapped between customers / entities | AES-GCM AAD binding + per-entity KEK | ::test_pii_roundtrip_and_record_binding | Decrypt fails | — |
| 22 | Backdated or forged timestamp | RFC 3161 verify: imprint, nonce, CMS signature, EKU, trusted root | ::test_tampered_token_and_untrusted_tsa | Rejected | TSA trust is external |
| 23 | Publish without external witness | Production gate | ::test_production_refuses_publication_without_witnesses | Refused | — |
| 24 | Courier pockets prize | Dual control + serial scan + proof hashes + ledger posting | test_claims_delivery_sponsor::test_full_claim_to_delivery_with_controls | Denied | Collusion of two staff |
| 25 | Non-winner claims / redirects delivery | Winner check, owner-only address write | same | Denied | — |
| 26 | Sponsor sees participants / other sponsor | Scoped aggregates, k=10 suppression | ::test_sponsor_portal_is_scoped_aggregated_and_suppressed | Denied / suppressed | Repeated-query differencing on live counts |
| 27 | Telegram webhook spoof / replay | Secret token + update_id dedupe | test_telegram_bot::test_webhook_secret_and_update_dedupe | 401 / ignored | — |
| 28 | Link-code brute force | 40-bit single-use code, 5 min, 5 tries / 10 min per user | ::test_group_chats_refused_and_link_bruteforce_limited | Limited | Many Telegram accounts in parallel: add global limiter at edge |
| 29 | HTML injection via campaign title in bot | Escaping | ::test_link_flow_single_use_and_receipts | Escaped | — |
| 30 | Anonymous access to any private route | Route sweep | test_route_sweep::test_every_private_route_requires_authentication | 401/403 on all | New routes covered automatically |
| 31 | Hostile input crashes API (NUL, traversal, JNDI, emoji floods) | Edge NUL rejection, typed validation | ::test_hostile_inputs_never_cause_server_errors | No 5xx (NUL crash found and fixed) | — |
| 32 | Primary database loss | Sync standby + WAL archive + PITR | scripts/drills/backup_restore_drill.py | RPO 0 for committed entries; all integrity checks pass | Measured on small data; re-measure at scale |

NOT RUN (must be done before any live decision): external DAST/SQLi/SSRF scanning, file-upload malware (portal hashes files client-side; no uploads stored yet), WAF bypass, CI/dependency
compromise drill, backup-restore with missing latest entries, insider prize theft, multi-account collusion analytics,
offline double submission on real devices, independent penetration test, independent fairness review.
