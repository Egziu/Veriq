# Measured contrast (WCAG 2.x relative luminance)

| Pair | Ratio | AA text |
|---|---|---|
| ivory-50 on forest-950 | 16.69:1 | PASS |
| sage-400 on forest-950 | 7.82:1 | PASS |
| sage-400 on forest-900 | 7.14:1 | PASS |
| gold-500 on forest-950 | 7.85:1 | PASS |
| gold-500 on forest-800 | 6.10:1 | PASS |
| forest-950 on gold-500 | 7.85:1 | PASS |
| forest-950 on ivory-50 | 16.69:1 | PASS |
| #4C6457 on ivory-50 | 5.69:1 | PASS |
| gold-600 on ivory-50 (large/UI only) | 3.10:1 | UI/large only |
| signal-stop on forest-900 | 5.61:1 | PASS |
