"""VERIQ deterministic competition rules. Pure: no I/O, no clock, no randomness, no ORM.

Lowest-unique: for eligible selections x_i, c(k)=count of k; S={k | c(k)=1};
winner number = min(S) if S non-empty, else NO_WINNER. Repeated entries by one
person count as repeated selections (the approved per-customer cap bounds them).
"""
from __future__ import annotations
import hashlib, json
from collections import Counter
from dataclasses import dataclass
from typing import Iterable, Sequence

ALGORITHM_VERSION = "lowest-unique/1.0.0"
MANIFEST_SCHEMA = "veriq.manifest/1"
GENESIS = "0" * 64


@dataclass(frozen=True)
class Outcome:
    kind: str                 # "WINNER" | "NO_WINNER"
    number: int | None
    seq: int | None           # accepted sequence of the winning entry


def lowest_unique(entries: Sequence[tuple[int, int]]) -> Outcome:
    """entries: (seq, selection) pairs from the frozen dataset."""
    counts = Counter(sel for _, sel in entries)
    unique = [k for k, c in counts.items() if c == 1]
    if not unique:
        return Outcome("NO_WINNER", None, None)
    n = min(unique)
    seq = next(s for s, sel in entries if sel == n)
    return Outcome("WINNER", n, seq)


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def digest(obj) -> str:
    return hashlib.sha256(canonical(obj)).hexdigest()


def receipt_hash(prev: str, entry_id: str, competition_id: str, seq: int, selection: int, rule_hash: str, accepted_at_utc: str) -> str:
    """Must match accept_entry() in db/migrations/0001 byte-for-byte."""
    s = "|".join([prev, entry_id, competition_id, str(seq), str(selection), rule_hash, accepted_at_utc])
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def build_manifest(competition_id: str, rule_hash: str, chain_head: str, high_water: int, rows: Iterable[dict], exclusions: list[dict] | None = None) -> dict:
    rows = sorted(rows, key=lambda r: r["seq"])
    return {
        "schema": MANIFEST_SCHEMA,
        "algorithm": ALGORITHM_VERSION,
        "competition_id": competition_id,
        "rule_hash": rule_hash,
        "high_water": high_water,
        "chain_head": chain_head,
        "count": len(rows),
        "seq_range": [rows[0]["seq"], rows[-1]["seq"]] if rows else [0, 0],
        "exclusions": exclusions or [],
        "entries": [{k: r[k] for k in ("seq", "entry_id", "selection", "accepted_at_utc", "prev_receipt_hash", "receipt_hash")} for r in rows],
    }
