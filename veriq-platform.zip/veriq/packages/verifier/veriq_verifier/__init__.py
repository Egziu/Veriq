"""Independent VERIQ result verifier.

Deliberately shares NO code with veriq_rules or the core service: it re-implements
hashing, canonical JSON and the lowest-unique rule from the published specification,
so a defect or tampering in one implementation cannot silently agree with itself.
Fails closed: any discrepancy -> verified=False with reasons.
"""
from __future__ import annotations
import base64, hashlib, json

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.serialization import load_der_public_key
from cryptography.exceptions import InvalidSignature


def _verify_sig(public_key: bytes, sig: bytes, body: bytes):
    """Ed25519 (32-byte raw key, development) or ECDSA P-256/SHA-256 (DER SubjectPublicKeyInfo, HSM)."""
    if len(public_key) == 32:
        Ed25519PublicKey.from_public_bytes(public_key).verify(sig, body)
        return
    k = load_der_public_key(public_key)
    if not isinstance(k, ec.EllipticCurvePublicKey) or k.curve.name != "secp256r1":
        raise InvalidSignature("unsupported key")
    k.verify(sig, body, ec.ECDSA(hashes.SHA256()))


def _canon(o) -> bytes:
    return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def _winner(selections: list[int]):
    # Sort-and-scan, intentionally different from the Counter approach in veriq_rules.
    s = sorted(selections)
    i = 0
    while i < len(s):
        j = i
        while j + 1 < len(s) and s[j + 1] == s[i]:
            j += 1
        if j == i:
            return s[i]
        i = j + 1
    return None


def verify(manifest: dict, signature_b64: str, public_key_raw: bytes, claimed: dict,
           witnessed_chain_head: str | None = None, customer_receipts: list[str] | None = None) -> dict:
    reasons: list[str] = []
    body = _canon(manifest)
    dig = hashlib.sha256(body).hexdigest()
    try:
        _verify_sig(public_key_raw, base64.b64decode(signature_b64), body)
    except (InvalidSignature, ValueError, TypeError):
        reasons.append("SIGNATURE_INVALID")
    if claimed.get("manifest_digest") != dig:
        reasons.append("DIGEST_MISMATCH")

    ents = manifest.get("entries", [])
    n = manifest.get("high_water")
    if len(ents) != n or manifest.get("count") != n:
        reasons.append("COUNT_MISMATCH")
    if [e["seq"] for e in ents] != list(range(1, len(ents) + 1)):
        reasons.append("SEQUENCE_NOT_CONTIGUOUS")

    prev = "0" * 64
    for e in ents:
        if e["prev_receipt_hash"] != prev:
            reasons.append(f"CHAIN_BROKEN_AT_SEQ_{e['seq']}"); break
        recomputed = hashlib.sha256("|".join([prev, e["entry_id"], manifest["competition_id"], str(e["seq"]),
                     str(e["selection"]), manifest["rule_hash"], e["accepted_at_utc"]]).encode()).hexdigest()
        if recomputed != e["receipt_hash"]:
            reasons.append(f"RECEIPT_TAMPERED_AT_SEQ_{e['seq']}"); break
        prev = e["receipt_hash"]
    if prev != manifest.get("chain_head"):
        reasons.append("CHAIN_HEAD_MISMATCH")
    if witnessed_chain_head is not None and witnessed_chain_head != manifest.get("chain_head"):
        reasons.append("WITNESS_MISMATCH")
    if customer_receipts:
        present = {e["receipt_hash"] for e in ents}
        missing = [r for r in customer_receipts if r not in present]
        if missing:
            reasons.append(f"RECEIPT_OMITTED:{len(missing)}")

    w = _winner([e["selection"] for e in ents])
    if w != claimed.get("winning_number"):
        reasons.append("OUTCOME_MISMATCH")
    return {"verified": not reasons, "reasons": reasons, "manifest_digest": dig,
            "winning_number": w, "entries_checked": len(ents), "verifier": "veriq-independent-verifier/1.0.0"}
