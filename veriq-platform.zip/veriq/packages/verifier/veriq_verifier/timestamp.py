"""Independent RFC 3161 time-stamp token verification (no dependency on VERIQ core).
Checks: status granted, eContentType = id-ct-TSTInfo, message imprint (SHA-256) equals the expected value,
nonce matches (if given), signed-attribute message digest equals hash(TSTInfo), CMS signature valid under the
TSA certificate, TSA certificate has critical EKU id-kp-timeStamping, is valid at genTime, and is signed by a
trusted root. Fails closed with a reason."""
from __future__ import annotations
import hashlib
from asn1crypto import cms, tsp, x509 as ax509
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa

_HASH = {"sha256": (hashlib.sha256, hashes.SHA256()), "sha384": (hashlib.sha384, hashes.SHA384()), "sha512": (hashlib.sha512, hashes.SHA512())}


class TimestampInvalid(Exception):
    pass


def _check_sig(pub, sig: bytes, data: bytes, h):
    if isinstance(pub, rsa.RSAPublicKey):
        pub.verify(sig, data, padding.PKCS1v15(), h)
    elif isinstance(pub, ec.EllipticCurvePublicKey):
        pub.verify(sig, data, ec.ECDSA(h))
    else:
        raise TimestampInvalid("UNSUPPORTED_KEY")


def verify_token(token_der: bytes, expected_imprint: bytes, trusted_roots_pem: list[bytes], nonce: int | None = None) -> dict:
    try:
        ci = cms.ContentInfo.load(token_der)
        sd = ci["content"]
        if ci["content_type"].native != "signed_data":
            raise TimestampInvalid("NOT_SIGNED_DATA")
        if sd["encap_content_info"]["content_type"].native != "tst_info":
            raise TimestampInvalid("NOT_TST_INFO")
        tst_bytes = sd["encap_content_info"]["content"].parsed.dump()
        tst = tsp.TSTInfo.load(tst_bytes)
    except TimestampInvalid:
        raise
    except Exception as e:
        raise TimestampInvalid(f"MALFORMED:{type(e).__name__}")

    mi = tst["message_imprint"]
    if mi["hash_algorithm"]["algorithm"].native != "sha256" or mi["hashed_message"].native != expected_imprint:
        raise TimestampInvalid("IMPRINT_MISMATCH")
    if nonce is not None and tst["nonce"].native != nonce:
        raise TimestampInvalid("NONCE_MISMATCH")

    si = sd["signer_infos"][0]
    halg = si["digest_algorithm"]["algorithm"].native
    if halg not in _HASH:
        raise TimestampInvalid("WEAK_OR_UNKNOWN_DIGEST")
    hf, ch = _HASH[halg]
    attrs = si["signed_attrs"]
    md = next((a["values"][0].native for a in attrs if a["type"].native == "message_digest"), None)
    if md != hf(tst_bytes).digest():
        raise TimestampInvalid("CONTENT_DIGEST_MISMATCH")
    signed_bytes = b"\x31" + attrs.dump()[1:]  # [0] IMPLICIT -> SET OF for signature input

    sid = si["sid"]
    certs = [c.chosen for c in sd["certificates"]] if sd["certificates"] else []
    signer = None
    for c in certs:
        if sid.name == "issuer_and_serial_number" and c.issuer == sid.chosen["issuer"] and c.serial_number == sid.chosen["serial_number"].native:
            signer = c
        elif sid.name == "subject_key_identifier" and c.key_identifier == sid.chosen.native:
            signer = c
    if signer is None:
        raise TimestampInvalid("SIGNER_CERT_NOT_INCLUDED")
    cert = x509.load_der_x509_certificate(signer.dump())
    try:
        _check_sig(cert.public_key(), si["signature"].native, signed_bytes, ch)
    except Exception:
        raise TimestampInvalid("BAD_SIGNATURE")

    try:
        eku = cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage)
    except x509.ExtensionNotFound:
        raise TimestampInvalid("NO_TIMESTAMPING_EKU")
    if not eku.critical or x509.oid.ExtendedKeyUsageOID.TIME_STAMPING not in eku.value:
        raise TimestampInvalid("NO_TIMESTAMPING_EKU")
    gen = tst["gen_time"].native
    if not (cert.not_valid_before_utc <= gen <= cert.not_valid_after_utc):
        raise TimestampInvalid("CERT_NOT_VALID_AT_GENTIME")

    for pem in trusted_roots_pem:
        root = x509.load_pem_x509_certificate(pem)
        if root.subject == cert.issuer:
            try:
                h = cert.signature_hash_algorithm
                _check_sig(root.public_key(), cert.signature, cert.tbs_certificate_bytes, h)
                break
            except Exception:
                continue
    else:
        raise TimestampInvalid("UNTRUSTED_TSA")
    return {"gen_time": gen, "serial": str(tst["serial_number"].native), "policy": tst["policy"].native,
            "tsa_subject": cert.subject.rfc4514_string()}


def build_request(imprint: bytes, nonce: int) -> bytes:
    return tsp.TimeStampReq({"version": 1, "message_imprint": {"hash_algorithm": {"algorithm": "sha256"}, "hashed_message": imprint},
                             "nonce": nonce, "cert_req": True}).dump()


def token_from_response(resp_der: bytes) -> bytes:
    r = tsp.TimeStampResp.load(resp_der)
    if r["status"]["status"].native not in ("granted", "granted_with_mods"):
        raise TimestampInvalid(f"TSA_REFUSED:{r['status']['status'].native}")
    return r["time_stamp_token"].dump()
