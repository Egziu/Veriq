# VERIQ production-readiness matrix — 2026-10-15 (round 2)

**Engineering status: release candidate (1.0.0-rc1) for a controlled, free sponsor-campaign pilot.**
**Launch decision: NO GO** until the BLOCKING rows are closed. Paid competitions remain BLOCKED by design.

Evidence: 100 automated tests on real PostgreSQL 16 + SoftHSM2 (PKCS#11), last run in reports/readiness/last_test_run.txt;
backup/restore/failover drill report: reports/drills/20261015T014640Z.md; bandit 0 high/0 medium; pip-audit and npm audit 0 known vulnerabilities.

| Area | Status | Evidence | Owner / next step |
|---|---|---|---|
| Country/product gate, separated approvals | PASS | test_country_gate.py | — |
| Atomic acceptance, idempotency, caps across web/app/Telegram, self-exclusion | PASS | test_acceptance.py, test_telegram_bot.py | — |
| Close race, contiguous sequence | PASS (single node) | close-race tests | Re-run at pilot load |
| Double-entry ledger, payments idempotency | PASS (fake provider) | test_ledger_payments.py | **You:** real provider integration |
| Tenant isolation (RLS + composite FKs) | PASS | test_rls_isolation.py | — |
| Deterministic result + independent verifier | PASS | adversarial + 2,500 property cases | Independent fairness review |
| Passkey login, sessions, CSRF, staff UV, clone detection | PASS | test_passkeys_sessions.py (18) | Real-device test (Android/iOS/browsers) |
| HSM signing / KEK / blind index | PASS on SoftHSM2 | test_hsm_pii_witness.py | **Before go-live:** run suite against the production HSM; key ceremony; HSM backup |
| PII envelope encryption, audited reads | PASS | same + claims tests | — |
| RFC 3161 external witness (2 TSAs required in production) | PASS against local TSAs | same | Contract 2 independent TSAs; set VERIQ_TSA_URLS/ROOTS |
| Claims, allocation, dual-control delivery, ledger posting | PASS | test_claims_delivery_sponsor.py | Courier SOP + training |
| Sponsor portal (scoped, k=10 suppression) | PASS | same | — |
| Telegram bot + Mini App entry | PASS (offline harness) | test_telegram_bot.py (7) | Register bot, setWebhook with secret, live smoke test |
| Web portals (Next.js 16.3.8) | PASS build, typecheck; CSP nonce verified on served pages | build log | Browser E2E + accessibility audit |
| Route-wide auth + hostile-input sweep | PASS | test_route_sweep.py | **You:** external pentest |
| Backup, PITR, failover | PASS (RPO 0 sync standby; RTO <1 s at drill size) | drill report | Repeat at production data size; offsite archive |
| Flutter mobile app | WRITTEN, NOT COMPILED | apps/mobile (cross-language test vectors included) | Run `flutter analyze && flutter test`, device tests, store review |
| Lost-passkey account recovery | NOT BUILT | — | Design with KYC provider |
| KYC/identity-provider integration | NOT BUILT (manual compliance command exists) | — | **You:** API integration |
| Monitoring, alerting, tracing | NOT BUILT | — | OpenTelemetry + alert routing before pilot |
| Load test at pilot profile | NOT RUN | local micro-benchmark only | Define pilot profile, test with pooling |
| Human-reviewed Amharic / Tigrinya / Afaan Oromo | NOT DONE | drafts labelled | Native-speaker review |
| Ethiopian legal opinion / regulator position | MISSING | — | **BLOCKING** |
| Independent penetration test | NOT RUN | — | **BLOCKING** (your role) |
| Payment provider written acceptance | MISSING | — | Blocking for paid only |

Defects found and fixed during round 2 (each has a regression test): failed login rolled back challenge burn and clone
revocation; dev keyring regenerated keys per call; validation errors echoed input; sponsor list lacked grant; NUL byte
caused HTTP 500. Round 1: paid gate crash; search_path hijack of guard triggers.
