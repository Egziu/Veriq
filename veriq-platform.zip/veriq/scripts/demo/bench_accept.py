"""Local micro-benchmark of the acceptance transaction. NOT a pilot SLO measurement:
single container, local socket, no network, no provider, no TLS. Use for regression tracking only."""
import os, statistics, sys, threading, time
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
for p in ("tests", "services/core", "packages/rules", "packages/verifier"): sys.path.insert(0, os.path.join(ROOT, p))
import conftest  # noqa: sets DSN
from conftest import World

THREADS, PER = int(os.environ.get("T", 16)), int(os.environ.get("N", 60))
w = World(); w.activate(); comp, _ = w.competition(cap=PER, hi=100000, minutes=30)
custs = [w.customer() for _ in range(THREADS)]; lat = []; lock = threading.Lock()
def run(c):
    for i in range(PER):
        t = time.perf_counter(); r = w.enter(comp, c, (hash(c) + i) % 100000 + 1); d = time.perf_counter() - t
        assert r["ok"], r
        with lock: lat.append(d)
t0 = time.perf_counter(); ts = [threading.Thread(target=run, args=(c,)) for c in custs]
[t.start() for t in ts]; [t.join() for t in ts]; wall = time.perf_counter() - t0
lat.sort(); q = lambda p: lat[int(p * (len(lat) - 1))] * 1000
closed = w.close(comp)
print(f"entries={len(lat)} threads={THREADS} wall={wall:.2f}s throughput={len(lat)/wall:.0f}/s "
      f"p50={q(.5):.1f}ms p95={q(.95):.1f}ms p99={q(.99):.1f}ms max={lat[-1]*1000:.1f}ms high_water={closed['high_water']}")
