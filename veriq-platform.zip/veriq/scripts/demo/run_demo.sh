#!/usr/bin/env bash
# One-command synthetic demo: migrate -> test suite -> vertical slice narrative -> benchmark.
set -euo pipefail
cd "$(dirname "$0")/../.."
scripts/migrate.sh veriq_test
python3 -m pytest -q
python3 scripts/demo/vertical_slice.py
python3 scripts/demo/bench_accept.py
