"""Narrated vertical slice with SYNTHETIC data:
country gate -> rule -> secured prize -> eligibility -> receipt -> atomic close -> deterministic result
-> independent verification -> publication. Prints each step's evidence."""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
for p in ("tests", "services/core", "packages/rules", "packages/verifier"): sys.path.insert(0, os.path.join(ROOT, p))
import conftest  # noqa
from conftest import World, call
from veriq_core.modules import fairness

w = World("Synthetic Sponsor Campaign Entity")
with w.as_staff("ops") as cur: print("1. Default gate:", call(cur, "authz_check", w.entity, "ET", "SPONSOR_FREE", "WEB"))
w.activate(); print("2. After 11 evidence items + Compliance/CFO/Deployment approvals: LIMITED_PILOT")
comp, rid = w.competition(cap=2, hi=50, title="Synthetic: Smartphone giveaway")
print("3. Rule approved by a different person; prize reserve secured by CFO; competition OPEN")
people = {n: w.customer() for n in ("Abeba", "Dawit", "Hiwot", "Kidus", "Selam")}
picks = {"Abeba": [3, 11], "Dawit": [3], "Hiwot": [7, 11], "Kidus": [9], "Selam": [7]}
for n, sels in picks.items():
    for s in sels:
        r = w.enter(comp, people[n], s); print(f"   {n:6} picks {s:2} -> seq {r['seq']:>2} receipt {r['receipt_hash'][:16]}…")
print("4. Over-cap attempt:", w.enter(comp, people["Abeba"], 40)["code"])
c = w.close(comp); print(f"5. Closed atomically: high_water={c['high_water']} chain_head={c['chain_head'][:16]}…")
print("   Late attempt:", w.enter(comp, people["Kidus"], 1)["code"])
with w.as_staff("ops") as cur:
    r = fairness.compute_and_publish(cur, comp, fairness.Signer())
print(f"6. Result: {r['outcome']} number={r['winning_number']}  (3,7,11 repeated; 9 is the lowest unique)")
print(f"7. Independent verifier: verified={r['attestation']['verified']} reasons={r['attestation']['reasons']} digest={r['manifest_digest'][:16]}…")
print("8. Publication:", r["publish"])
with w.as_staff("ops") as cur: print("9. Audit chain:", call(cur, "verify_audit_chain"))
