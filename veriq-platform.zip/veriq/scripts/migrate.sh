#!/usr/bin/env bash
# Apply migrations in order to a fresh database. Usage: scripts/migrate.sh <dbname>
set -euo pipefail
DB=${1:-veriq}; H=${PGHOST:-/tmp/pg}
psql -h "$H" -U postgres -qc "DROP DATABASE IF EXISTS $DB" -c "CREATE DATABASE $DB"
for f in "$(dirname "$0")"/../db/migrations/*.sql; do
  psql -h "$H" -U postgres -d "$DB" -v ON_ERROR_STOP=1 -q -f "$f" >/dev/null && echo "applied $(basename "$f")"
done
