"""Staff passkey enrolment (run by an INFRA_ADMIN on the bastion, never exposed as a public endpoint).
Issues a single-use, 5-minute WebAuthn registration challenge bound to the staff member; the options are delivered
to the staff member's device in person (QR). The device completes /v1/auth/passkey/register/finish.
User verification is REQUIRED for staff; the database rejects staff credentials without it."""
import json, sys
sys.path.insert(0, __file__.rsplit("/scripts/", 1)[0] + "/services/core")
from veriq_core.db import tx
from veriq_core.modules import identity

entity, staff_id, admin_id = sys.argv[1], sys.argv[2], sys.argv[3]
with tx(entity, admin_id) as cur:
    cur.execute("SELECT display_name FROM veriq.staff_users WHERE id=%s AND active", (staff_id,))
    row = cur.fetchone()
    if not row:
        sys.exit("unknown or inactive staff member")
    print(json.dumps(identity.begin_registration(cur, staff_id, "staff", row["display_name"]), indent=2))
