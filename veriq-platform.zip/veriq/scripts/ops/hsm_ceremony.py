"""Key ceremony: provision per-entity signing (ECDSA P-256), KEK (AES-256) and blind-index (HMAC) keys inside the
HSM. Run once per legal entity with two witnesses present; record the output (public key fingerprint) in the
ceremony log and in the authorization dossier. Keys are SENSITIVE + NON-EXTRACTABLE.
Usage: VERIQ_PKCS11_LIB=... VERIQ_PKCS11_TOKEN=... VERIQ_PKCS11_PIN=... python hsm_ceremony.py <entity-uuid>"""
import hashlib, sys, uuid
sys.path.insert(0, __file__.rsplit("/scripts/", 1)[0] + "/services/core")
from veriq_core.kms import HsmKeyring

entity = str(uuid.UUID(sys.argv[1]))
k = HsmKeyring.from_env(prefix=f"veriq.{entity}")
try:
    k.public_key_der(); print("Keys already exist for this entity; refusing to overwrite."); sys.exit(2)
except Exception:
    pass
k.provision()
print("entity:", entity)
print("signing key id:", k.key_id)
print("public key SHA-256:", hashlib.sha256(k.public_key_der()).hexdigest())
print("Record this in the ceremony log with both witness signatures.")
