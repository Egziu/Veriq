"""Database access. Entity/actor context is set with SET LOCAL from *verified* server claims only,
inside the transaction, so it cannot leak across pooled connections or be chosen by a client."""
from __future__ import annotations
import os, uuid
from contextlib import contextmanager
import psycopg
from psycopg.rows import dict_row

APP_DSN = os.environ.get("VERIQ_APP_DSN", "host=/tmp/pg dbname=veriq_test user=veriq_app")


@contextmanager
def tx(entity_id, actor_id=None, dsn: str | None = None):
    with psycopg.connect(dsn or APP_DSN, row_factory=dict_row, autocommit=False) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT set_config('veriq.entity_id', %s, true), set_config('veriq.actor_id', %s, true)",
                        (str(entity_id), str(actor_id) if actor_id else ""))
            cur.execute("SET LOCAL search_path = veriq, pg_temp")
            cur.execute("SET LOCAL statement_timeout = '10s'")
            cur.execute("SET LOCAL lock_timeout = '5s'")
            yield cur
        conn.commit()


def call(cur, fn: str, *args):
    ph = ",".join(["%s"] * len(args))
    cur.execute(f"SELECT veriq.{fn}({ph}) AS r", args)
    return cur.fetchone()["r"]
