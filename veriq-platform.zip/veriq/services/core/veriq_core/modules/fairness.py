"""Result pipeline: export frozen dataset -> canonical manifest -> HSM signature (ECDSA P-256) -> deterministic
compute -> record -> RFC 3161 witness of the commitment -> independent verification -> publish.
Production (VERIQ_ENV=production) refuses to publish without >= VERIQ_TSA_MIN (default 2) witness receipts."""
from __future__ import annotations
import base64, json, os
from veriq_rules import build_manifest, canonical, digest, lowest_unique, ALGORITHM_VERSION
import veriq_verifier
from ..db import call
from ..kms import keyring_for
from . import witness as witness_mod


class Signer:
    """Adapter from a keyring (HSM in production) to manifest signing."""
    def __init__(self, keyring=None, entity: str | None = None):
        from ..kms import DevKeyring
        self.k = keyring or (keyring_for(entity) if entity else DevKeyring())
        self.key_id = self.k.key_id

    def sign(self, body: bytes) -> str:
        return base64.b64encode(self.k.sign(body)).decode()

    def public_raw(self) -> bytes:
        return self.k.public_key_der()


EXPORT_SQL = """
SELECT e.seq, e.id::text AS entry_id, e.selection, e.prev_receipt_hash, e.receipt_hash,
       to_char(e.accepted_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US') AS accepted_at_utc
  FROM veriq.entries e WHERE e.competition_id = %s ORDER BY e.seq"""


def export_frozen(cur, competition_id: str) -> dict:
    cur.execute("SELECT c.state, c.high_water, c.chain_head, r.rule_hash FROM veriq.competitions c "
                "JOIN veriq.rule_versions r ON r.id=c.rule_version_id WHERE c.id=%s", (competition_id,))
    c = cur.fetchone()
    if not c or c["state"] not in ("FROZEN", "RESULT_PUBLISHED"):
        raise RuntimeError("NOT_FROZEN")
    cur.execute(EXPORT_SQL, (competition_id,))
    return build_manifest(competition_id, c["rule_hash"], c["chain_head"], c["high_water"], cur.fetchall())


def _tsa_config():
    urls = [u for u in os.environ.get("VERIQ_TSA_URLS", "").split(",") if u]
    roots = [open(p, "rb").read() for p in os.environ.get("VERIQ_TSA_ROOTS", "").split(",") if p]
    return urls, roots


def compute_and_publish(cur, competition_id: str, signer: Signer, tsa_urls=None, tsa_roots=None, min_witness=None) -> dict:
    manifest = export_frozen(cur, competition_id)
    sig, dig = signer.sign(canonical(manifest)), digest(manifest)
    out = lowest_unique([(e["seq"], e["selection"]) for e in manifest["entries"]])
    entry_id = next((e["entry_id"] for e in manifest["entries"] if e["seq"] == out.seq), None)
    call(cur, "record_result", competition_id, ALGORITHM_VERSION, json.dumps(manifest), dig, sig,
         signer.key_id, out.kind, out.number, entry_id)

    urls, roots = (tsa_urls, tsa_roots) if tsa_urls is not None else _tsa_config()
    production = os.environ.get("VERIQ_ENV") == "production"
    need = min_witness if min_witness is not None else (int(os.environ.get("VERIQ_TSA_MIN", "2")) if production else 0)
    witnesses = []
    if urls:
        witnesses = witness_mod.witness_competition(cur, competition_id, dig, manifest["chain_head"], manifest["high_water"],
                                                    urls, roots, min_success=max(need, 1))
    if len(witnesses) < need:
        return {"outcome": out.kind, "winning_number": out.number, "manifest_digest": dig, "publish": "WITNESS_REQUIRED",
                "attestation": None, "signature": sig, "manifest": manifest, "witnesses": []}

    cur.execute("SELECT chain_head FROM veriq.witness_roots WHERE competition_id=%s ORDER BY through_seq DESC LIMIT 1", (competition_id,))
    att = veriq_verifier.verify(manifest, sig, signer.public_raw(),
                                {"manifest_digest": dig, "winning_number": out.number}, witnessed_chain_head=cur.fetchone()["chain_head"])
    att["witnesses"] = [{"tsa": w["tsa"], "gen_time": w["gen_time"].isoformat(), "serial": w["serial"]} for w in witnesses]
    status = call(cur, "publish_result", competition_id, json.dumps(att))
    return {"outcome": out.kind, "winning_number": out.number, "manifest_digest": dig, "attestation": att,
            "publish": status, "signature": sig, "manifest": manifest, "witnesses": witnesses}
