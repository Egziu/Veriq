"""Passkey (WebAuthn) identity and opaque, revocable sessions.
- Challenges: 32 random bytes; only SHA-256 stored; single use, 5-minute expiry, consumed atomically in the DB.
- Staff: user verification REQUIRED at registration and every authentication (phishing-resistant MFA in one step).
- Customers: user verification preferred; sessions 12 h. Staff sessions 30 min, deactivation kills them immediately.
- Sign-count regression revokes the credential (possible clone).
- Session token: "vq1.<entity>.<256-bit random>"; DB stores SHA-256 only."""
from __future__ import annotations
import base64, hashlib, json, os, secrets
from webauthn import (generate_authentication_options, generate_registration_options, options_to_json,
                      verify_authentication_response, verify_registration_response)
from webauthn.helpers.structs import (AuthenticatorSelectionCriteria, PublicKeyCredentialDescriptor,
                                      ResidentKeyRequirement, UserVerificationRequirement)
from ..db import call

RP_ID = os.environ.get("VERIQ_RP_ID", "veriq.et")
RP_NAME = "VERIQ"
ORIGINS = [o for o in os.environ.get("VERIQ_ORIGINS", "https://veriq.et,https://app.veriq.et,https://portal.veriq.et").split(",") if o]
CHALLENGE_TTL = 300


class AuthError(Exception):
    pass


def _h(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _challenge_from_client_data(credential: dict) -> bytes:
    cd = json.loads(_b64u_dec(credential["response"]["clientDataJSON"]))
    return _b64u_dec(cd["challenge"])


def begin_registration(cur, principal_id: str, kind: str, display_name: str) -> dict:
    challenge = secrets.token_bytes(32)
    call(cur, "issue_challenge", "WEBAUTHN_REGISTER", principal_id, kind, _h(challenge), CHALLENGE_TTL)
    cur.execute("SELECT credential_id FROM veriq.passkey_credentials WHERE principal_id=%s AND revoked_at IS NULL", (principal_id,))
    exclude = [PublicKeyCredentialDescriptor(id=bytes(r["credential_id"])) for r in cur.fetchall()]
    opts = generate_registration_options(
        rp_id=RP_ID, rp_name=RP_NAME, user_id=principal_id.encode(), user_name=display_name, user_display_name=display_name,
        challenge=challenge, exclude_credentials=exclude, timeout=CHALLENGE_TTL * 1000,
        authenticator_selection=AuthenticatorSelectionCriteria(
            resident_key=ResidentKeyRequirement.PREFERRED,
            user_verification=UserVerificationRequirement.REQUIRED if kind == "staff" else UserVerificationRequirement.PREFERRED))
    return json.loads(options_to_json(opts))


def finish_registration(cur, credential: dict, label: str = "passkey") -> str:
    challenge = _challenge_from_client_data(credential)
    c = call(cur, "consume_challenge", "WEBAUTHN_REGISTER", _h(challenge))
    if not c["ok"]:
        raise AuthError(c["code"])
    staff = c["subject_kind"] == "staff"
    try:
        v = verify_registration_response(credential=credential, expected_challenge=challenge, expected_rp_id=RP_ID,
                                         expected_origin=ORIGINS, require_user_verification=staff)
    except Exception as e:
        raise AuthError(f"REGISTRATION_INVALID:{type(e).__name__}")
    uv = bool(v.user_verified)
    call(cur, "register_passkey", c["subject_id"], c["subject_kind"], v.credential_id, v.credential_public_key, v.sign_count,
         str(v.aaguid), bool(v.credential_backed_up), uv, label)
    return str(c["subject_id"])


def begin_authentication(cur, principal_id: str | None = None, kind: str | None = None) -> dict:
    challenge = secrets.token_bytes(32)
    call(cur, "issue_challenge", "WEBAUTHN_AUTH", principal_id, kind, _h(challenge), CHALLENGE_TTL)
    allow = []
    if principal_id:
        cur.execute("SELECT credential_id FROM veriq.passkey_credentials WHERE principal_id=%s AND revoked_at IS NULL", (principal_id,))
        allow = [PublicKeyCredentialDescriptor(id=bytes(r["credential_id"])) for r in cur.fetchall()]
    opts = generate_authentication_options(rp_id=RP_ID, challenge=challenge, allow_credentials=allow, timeout=CHALLENGE_TTL * 1000,
                                           user_verification=UserVerificationRequirement.REQUIRED if kind == "staff" else UserVerificationRequirement.PREFERRED)
    return json.loads(options_to_json(opts))


def finish_authentication(cur, entity: str, credential: dict, device: str = "") -> dict:
    challenge = _challenge_from_client_data(credential)
    c = call(cur, "consume_challenge", "WEBAUTHN_AUTH", _h(challenge))
    if not c["ok"]:
        raise AuthError(c["code"])
    raw_id = _b64u_dec(credential["rawId"])
    cur.execute("SELECT principal_id, principal_kind, public_key, sign_count, revoked_at FROM veriq.passkey_credentials "
                "WHERE credential_id=%s", (raw_id,))
    row = cur.fetchone()
    if not row or row["revoked_at"] is not None:
        raise AuthError("CREDENTIAL_REVOKED_OR_UNKNOWN")
    if c["subject_id"] and str(c["subject_id"]) != str(row["principal_id"]):
        raise AuthError("CREDENTIAL_NOT_FOR_SUBJECT")
    staff = row["principal_kind"] == "staff"
    try:
        v = verify_authentication_response(credential=credential, expected_challenge=challenge, expected_rp_id=RP_ID,
                                           expected_origin=ORIGINS, credential_public_key=bytes(row["public_key"]),
                                           credential_current_sign_count=0, require_user_verification=staff)
    except Exception as e:
        raise AuthError(f"ASSERTION_INVALID:{type(e).__name__}")
    use = call(cur, "record_passkey_use", raw_id, v.new_sign_count)
    if not use["ok"]:
        raise AuthError(use["code"])
    token = new_session(cur, entity, str(row["principal_id"]), row["principal_kind"], "passkey", device)
    return {"token": token, "principal_id": str(row["principal_id"]), "kind": row["principal_kind"]}


def new_session(cur, entity: str, principal_id: str, kind: str, method: str, device: str = "") -> str:
    secret = secrets.token_urlsafe(32)
    token = f"vq1.{entity}.{secret}"
    call(cur, "create_session", principal_id, kind, _h(token.encode()), method, device[:80])
    return token


def parse_token(token: str) -> tuple[str, str]:
    parts = token.split(".")
    if len(parts) != 3 or parts[0] != "vq1" or len(parts[2]) < 40:
        raise AuthError("MALFORMED_TOKEN")
    return parts[1], _h(token.encode())
