"""Payment webhook adapter. Verifies provider signature, timestamp window and replay BEFORE the
database applies the event. A screenshot, client flag or unsigned body is never evidence of payment."""
from __future__ import annotations
import hashlib, hmac, json, time
from ..db import call

REPLAY_WINDOW = 300


class WebhookRejected(Exception):
    pass


def verify_webhook(raw_body: bytes, signature: str, timestamp: str, secret: bytes, now: float | None = None) -> dict:
    try:
        ts = int(timestamp)
    except ValueError:
        raise WebhookRejected("BAD_TIMESTAMP")
    if abs((now or time.time()) - ts) > REPLAY_WINDOW:
        raise WebhookRejected("OUTSIDE_REPLAY_WINDOW")
    expected = hmac.new(secret, f"{ts}.".encode() + raw_body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        raise WebhookRejected("BAD_SIGNATURE")
    return json.loads(raw_body)


def sign_for_tests(raw_body: bytes, secret: bytes, ts: int) -> str:
    return hmac.new(secret, f"{ts}.".encode() + raw_body, hashlib.sha256).hexdigest()


def apply(cur, provider: str, event: dict, raw_body: bytes) -> dict:
    return call(cur, "apply_payment_event", provider, event["event_id"], event["merchant_ref"], event["kind"],
                int(event["amount_minor"]), event["currency"], hashlib.sha256(raw_body).hexdigest())
