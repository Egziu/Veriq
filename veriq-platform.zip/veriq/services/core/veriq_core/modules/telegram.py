"""Telegram Mini App initData validation per https://core.telegram.org/bots/webapps
secret_key = HMAC_SHA256(key="WebAppData", msg=bot_token); hash = hex(HMAC_SHA256(secret_key, data_check_string)).
Never trust initDataUnsafe, a client user_id, eligibility or payment flags."""
from __future__ import annotations
import hashlib, hmac, json, time
from urllib.parse import parse_qsl, urlencode

MAX_AGE_SECONDS = 300


class TelegramAuthError(Exception):
    pass


def validate_init_data(init_data: str, bot_token: str, now: float | None = None, max_age: int = MAX_AGE_SECONDS) -> dict:
    try:
        pairs = parse_qsl(init_data, keep_blank_values=True, strict_parsing=True)
    except ValueError:
        raise TelegramAuthError("MALFORMED")
    data = dict(pairs)
    if len(data) != len(pairs):
        raise TelegramAuthError("DUPLICATE_FIELD")
    received = data.pop("hash", None)
    if not received:
        raise TelegramAuthError("MISSING_HASH")
    data.pop("signature", None)  # third-party Ed25519 field; excluded from the bot-token HMAC check string
    check = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received):
        raise TelegramAuthError("BAD_SIGNATURE")
    auth_date = int(data.get("auth_date", "0"))
    if (now or time.time()) - auth_date > max_age:
        raise TelegramAuthError("STALE_AUTH_DATE")
    user = json.loads(data.get("user", "{}"))
    if "id" not in user:
        raise TelegramAuthError("NO_USER")
    return {"telegram_user_id": str(user["id"]), "auth_date": auth_date, "query_id": data.get("query_id")}


def sign_for_tests(fields: dict, bot_token: str) -> str:
    check = "\n".join(f"{k}={v}" for k, v in sorted(fields.items()))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    return urlencode({**fields, "hash": hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()})
