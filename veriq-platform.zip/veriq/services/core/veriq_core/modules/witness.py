"""External witness: RFC 3161 timestamp of each frozen dataset's commitment.
Production configuration: VERIQ_TSA_URLS lists >= 2 independent, trusted TSAs; VERIQ_TSA_ROOTS lists their roots.
The commitment (imprint) = SHA-256 of canonical {competition_id, manifest_digest, chain_head, high_water}."""
from __future__ import annotations
import json, os, secrets
from datetime import datetime
import httpx
from veriq_verifier.timestamp import build_request, token_from_response, verify_token, TimestampInvalid
from veriq_rules import canonical
import hashlib
from ..db import call


def commitment(competition_id: str, manifest_digest: str, chain_head: str, high_water: int) -> bytes:
    return hashlib.sha256(canonical({"competition_id": competition_id, "manifest_digest": manifest_digest,
                                     "chain_head": chain_head, "high_water": high_water})).digest()


def timestamp(imprint: bytes, url: str, roots: list[bytes], timeout: float = 10.0) -> dict:
    nonce = secrets.randbits(63)
    r = httpx.post(url, content=build_request(imprint, nonce), headers={"Content-Type": "application/timestamp-query"}, timeout=timeout)
    if r.status_code != 200:
        raise TimestampInvalid(f"TSA_HTTP_{r.status_code}")
    token = token_from_response(r.content)
    info = verify_token(token, imprint, roots, nonce=nonce)
    return {**info, "token": token, "tsa": url}


def witness_competition(cur, competition_id: str, manifest_digest: str, chain_head: str, high_water: int,
                        urls: list[str], roots: list[bytes], min_success: int = 1) -> list[dict]:
    imprint = commitment(competition_id, manifest_digest, chain_head, high_water)
    done, errors = [], []
    for url in urls:
        try:
            t = timestamp(imprint, url, roots)
            call(cur, "attach_witness", competition_id, url, imprint.hex(), t["gen_time"], t["serial"], t["token"])
            done.append(t)
        except Exception as e:  # one TSA down must not hide the others
            errors.append(f"{url}:{e}")
    if len(done) < min_success:
        raise TimestampInvalid("INSUFFICIENT_WITNESSES:" + ";".join(errors))
    return done
