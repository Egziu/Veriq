"""Field-level envelope encryption for customer identity data.
Each record: fresh 256-bit DEK -> AES-256-GCM(payload); DEK wrapped by the entity KEK in the HSM.
AAD binds ciphertext to (version, entity, customer): a ciphertext copied onto another customer fails to decrypt.
Phone numbers are looked up via an HMAC blind index computed inside the HSM; the plaintext is never stored."""
from __future__ import annotations
import json, os, re
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

VERSION = b"veriq.pii.v1"


class PiiError(Exception):
    pass


def normalize_et_phone(raw: str) -> str:
    d = re.sub(r"[^\d+]", "", raw or "")
    if d.startswith("+251"):
        d = d[4:]
    elif d.startswith("251"):
        d = d[3:]
    elif d.startswith("0"):
        d = d[1:]
    if not re.fullmatch(r"[79]\d{8}", d):
        raise PiiError("INVALID_ET_MOBILE")
    return "+251" + d


def _aad(entity: str, customer: str) -> bytes:
    return b"|".join([VERSION, entity.encode(), customer.encode()])


def encrypt(keyring, entity: str, customer: str, payload: dict) -> tuple[bytes, bytes, str]:
    dek = AESGCM.generate_key(256); nonce = os.urandom(12); aad = _aad(entity, customer)
    ct = nonce + AESGCM(dek).encrypt(nonce, json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode(), aad)
    return ct, keyring.wrap(dek, aad), keyring.key_id


def decrypt(keyring, entity: str, customer: str, ciphertext: bytes, wrapped_dek: bytes) -> dict:
    aad = _aad(entity, customer)
    dek = keyring.unwrap(wrapped_dek, aad)
    try:
        return json.loads(AESGCM(dek).decrypt(ciphertext[:12], ciphertext[12:], aad))
    except Exception:
        raise PiiError("DECRYPT_FAILED")


def phone_index(keyring, entity: str, raw_phone: str) -> str:
    return keyring.blind_index(f"phone|{entity}|{normalize_et_phone(raw_phone)}")
