"""VERIQ Telegram bot — a thin channel adapter over the canonical backend (aiogram 3).

Security posture:
- Webhook only; requests must carry X-Telegram-Bot-Api-Secret-Token (checked in the API, constant-time).
- update_id de-duplicated in the database (replayed deliveries are ignored).
- The chat surface is READ-ONLY: browse prizes and rules, see receipts and results, link/unlink, help.
  Entries are submitted only via the Mini App, which re-validates Telegram initData on every request and calls
  the same accept_entry() as web and mobile, so caps, exclusions and country gates are shared.
- Account linking: a one-time 8-character code issued inside the signed-in app (5 min, single use, hashed at rest).
- No PII, payment data or tokens in messages or deep links. All dynamic text is HTML-escaped.
- Per-user rate limits on link attempts and commands.
"""
from __future__ import annotations
import hashlib, os, time
from collections import defaultdict

from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message, WebAppInfo
from aiogram.utils.text_decorations import html_decoration as hd

from .db import call, tx

MINI_APP_URL = os.environ.get("VERIQ_MINI_APP_URL", "https://app.veriq.et/tg")
SUPPORT = "Reply here with /help, or write to support inside the VERIQ app. Every complaint gets a reference number."

TEXT = {
    "en": {"welcome": "Welcome to <b>VERIQ</b> — trust in every win.\nFree sponsor campaigns with published rules, a secured prize and a result anyone can check.",
           "not_linked": "Your Telegram is not linked to a VERIQ account yet. In the VERIQ app open <b>Settings → Telegram</b>, get a code, then send <code>/link CODE</code>.",
           "linked": "Linked. You can now see your receipts and results here.",
           "no_prizes": "No campaigns are open on Telegram right now.",
           "no_receipts": "You have no entries yet.",
           "unlinked": "Unlinked. Your sessions on Telegram were signed out.",
           "rate": "Too many attempts. Please wait a few minutes.",
           "enter": "Enter in the app"},
    "am": {"welcome": "እንኳን ወደ <b>VERIQ</b> በደህና መጡ። (ትርጉም፡ በሰው ግምገማ ይጠብቃል)"},
    "ti": {"welcome": "እንቋዕ ናብ <b>VERIQ</b> ብደሓን መጻእኩም። (ትርጉም፡ ብሰብ ክርአ ይጽበ ኣሎ)"},
    "om": {"welcome": "Baga gara <b>VERIQ</b> dhuftan. (Hiikkaan sakatta'iinsa namaa eegaa jira)"},
}


def t(lang: str, key: str) -> str:
    return TEXT.get(lang, {}).get(key) or TEXT["en"][key]


class Limiter:
    def __init__(self, n: int, window: float):
        self.n, self.w, self.hits = n, window, defaultdict(list)

    def allow(self, key) -> bool:
        now = time.monotonic(); h = self.hits[key]; h[:] = [x for x in h if now - x < self.w]
        if len(h) >= self.n:
            return False
        h.append(now); return True


def _menu(lang="en") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Prizes", callback_data="m:prizes"), InlineKeyboardButton(text="Rules", callback_data="m:rules")],
        [InlineKeyboardButton(text="My receipts", callback_data="m:receipts"), InlineKeyboardButton(text="Results", callback_data="m:results")],
        [InlineKeyboardButton(text=t(lang, "enter"), web_app=WebAppInfo(url=MINI_APP_URL))],
        [InlineKeyboardButton(text="English", callback_data="l:en"), InlineKeyboardButton(text="ትግርኛ", callback_data="l:ti"),
         InlineKeyboardButton(text="አማርኛ", callback_data="l:am"), InlineKeyboardButton(text="Oromoo", callback_data="l:om")]])


def build_dispatcher(entity: str) -> Dispatcher:
    r = Router()
    link_limit, cmd_limit = Limiter(5, 600), Limiter(30, 60)
    langs: dict[str, str] = {}

    def customer_for(tg_id: int) -> str | None:
        with tx(entity) as cur:
            cur.execute("SELECT customer_id FROM veriq.channel_links WHERE channel='TELEGRAM' AND external_principal=%s AND unlinked_at IS NULL",
                        (str(tg_id),))
            row = cur.fetchone()
        return str(row["customer_id"]) if row else None

    def do_link(tg_id: int, code: str) -> str:
        if not link_limit.allow(tg_id):
            return t(langs.get(str(tg_id), "en"), "rate")
        code = (code or "").strip().upper().replace("-", "")
        if not (len(code) == 8 and code.isalnum()):
            return "That code doesn't look right. Codes are 8 letters and numbers."
        with tx(entity) as cur:
            res = call(cur, "link_telegram", hashlib.sha256(code.encode()).hexdigest(), str(tg_id))
        if res["ok"]:
            return t(langs.get(str(tg_id), "en"), "linked")
        return {"CHALLENGE_EXPIRED": "That code expired. Get a new one in the app.",
                "CHALLENGE_REPLAYED": "That code was already used. Get a new one in the app.",
                "TELEGRAM_ALREADY_LINKED": "This Telegram account is already linked. Send /unlink first."}.get(res["code"], "That code was not recognised.")

    def prizes_text() -> str:
        with tx(entity) as cur:
            cur.execute("SELECT id, title, closes_at, product_type, country_code FROM veriq.competitions WHERE state='OPEN' ORDER BY closes_at LIMIT 10")
            rows = [x for x in cur.fetchall() if call(cur, "authz_check", entity, x["country_code"], x["product_type"], "TELEGRAM") == "OK"]
        if not rows:
            return t("en", "no_prizes")
        return "<b>Open campaigns</b>\n" + "\n".join(f"• {hd.quote(x['title'])} — closes {x['closes_at']:%d %b %H:%M} UTC · Free" for x in rows)

    def rules_text() -> str:
        with tx(entity) as cur:
            cur.execute("SELECT c.title, c.number_min, c.number_max, c.per_customer_cap, r.rule_hash FROM veriq.competitions c "
                        "JOIN veriq.rule_versions r ON r.id=c.rule_version_id WHERE c.state='OPEN' LIMIT 5")
            rows = cur.fetchall()
        if not rows:
            return t("en", "no_prizes")
        return "\n\n".join(f"<b>{hd.quote(x['title'])}</b>\nPick a whole number {x['number_min']}–{x['number_max']}. "
                           f"The lowest number picked by exactly one entry wins. Up to {x['per_customer_cap']} entries per person across all channels. "
                           f"If no number is unique there is no winner.\nRule version <code>{x['rule_hash'][:12]}</code>" for x in rows)

    def receipts_text(cust: str) -> str:
        with tx(entity) as cur:
            cur.execute("SELECT c.title, e.seq, e.selection, e.receipt_hash FROM veriq.entries e JOIN veriq.competitions c ON c.id=e.competition_id "
                        "WHERE e.customer_id=%s ORDER BY e.accepted_at DESC LIMIT 5", (cust,))
            rows = cur.fetchall()
        if not rows:
            return t("en", "no_receipts")
        return "<b>Your latest receipts</b>\n" + "\n".join(
            f"• {hd.quote(x['title'])}: entry #{x['seq']}, number {x['selection']}, receipt <code>{x['receipt_hash'][:12]}</code>" for x in rows)

    def results_text(cust: str) -> str:
        with tx(entity) as cur:
            cur.execute("SELECT DISTINCT c.title, rr.outcome, rr.winning_number, rr.manifest_digest, (w.customer_id = %s) AS mine "
                        "FROM veriq.entries e JOIN veriq.competitions c ON c.id=e.competition_id "
                        "JOIN veriq.result_runs rr ON rr.competition_id=c.id AND rr.published_at IS NOT NULL "
                        "LEFT JOIN veriq.entries w ON w.id = rr.winning_entry_id WHERE e.customer_id=%s LIMIT 5", (cust, cust))
            rows = cur.fetchall()
        if not rows:
            return "No published results for campaigns you entered."
        out = []
        for x in rows:
            line = f"<b>{hd.quote(x['title'])}</b>: " + ("no winner" if x["outcome"] == "NO_WINNER" else f"winning number {x['winning_number']}")
            if x["mine"]:
                line += "\nYour entry won. Open the VERIQ app to claim — we will never ask for payment to release a prize."
            out.append(line + f"\nVerified result <code>{x['manifest_digest'][:12]}</code>")
        return "\n\n".join(out)

    async def guard(m: Message) -> bool:
        if m.chat.type != "private":
            await m.answer("For your privacy VERIQ only works in a private chat with the bot.")
            return False
        if not cmd_limit.allow(m.from_user.id):
            await m.answer(t("en", "rate")); return False
        return True

    @r.message(CommandStart())
    async def start(m: Message, command: CommandObject):
        if not await guard(m):
            return
        if command.args and command.args.startswith("link_"):
            await m.answer(do_link(m.from_user.id, command.args[5:])); return
        await m.answer(t(langs.get(str(m.from_user.id), "en"), "welcome"), reply_markup=_menu())

    @r.message(Command("link"))
    async def link(m: Message, command: CommandObject):
        if await guard(m):
            await m.answer(do_link(m.from_user.id, command.args or ""))

    @r.message(Command("unlink"))
    async def unlink(m: Message):
        if not await guard(m):
            return
        cust = customer_for(m.from_user.id)
        if cust:
            with tx(entity) as cur:
                call(cur, "unlink_telegram", cust)
        await m.answer(t("en", "unlinked") if cust else t("en", "not_linked"))

    @r.message(Command("prizes"))
    async def prizes(m: Message):
        if await guard(m):
            await m.answer(prizes_text())

    @r.message(Command("rules"))
    async def rules(m: Message):
        if await guard(m):
            await m.answer(rules_text())

    @r.message(Command("receipts"))
    async def receipts(m: Message):
        if not await guard(m):
            return
        cust = customer_for(m.from_user.id)
        await m.answer(receipts_text(cust) if cust else t("en", "not_linked"))

    @r.message(Command("result"))
    async def result(m: Message):
        if not await guard(m):
            return
        cust = customer_for(m.from_user.id)
        await m.answer(results_text(cust) if cust else t("en", "not_linked"))

    @r.message(Command("help"))
    async def help_(m: Message):
        if await guard(m):
            await m.answer("<b>Help</b>\n/prizes · /rules · /receipts · /result · /link CODE · /unlink\n\n" + SUPPORT +
                           "\n\nVERIQ staff will never ask for your password, a payment, or a code by message.")

    @r.callback_query(F.data.startswith("m:"))
    async def menu(cq: CallbackQuery):
        what = cq.data[2:]; cust = customer_for(cq.from_user.id)
        text = {"prizes": prizes_text, "rules": rules_text}.get(what, lambda: None)()
        if text is None:
            text = (receipts_text(cust) if what == "receipts" else results_text(cust)) if cust else t("en", "not_linked")
        await cq.message.answer(text); await cq.answer()

    @r.callback_query(F.data.startswith("l:"))
    async def lang(cq: CallbackQuery):
        code = cq.data[2:]
        if code in TEXT:
            langs[str(cq.from_user.id)] = code
        await cq.message.answer(t(code, "welcome")); await cq.answer()

    @r.message()
    async def fallback(m: Message):
        if await guard(m):
            await m.answer("I didn't understand that. Send /help to see what I can do.")

    dp = Dispatcher()
    dp.include_router(r)
    return dp
