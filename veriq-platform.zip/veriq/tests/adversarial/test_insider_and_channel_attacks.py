"""Adversarial scenarios. Each test documents attack -> expected denial/detection -> observed."""
import copy, json, time
import pytest
from conftest import World, call, superuser
from veriq_core.db import tx
from veriq_core.modules import fairness, telegram, payments
import veriq_verifier

BOT = "123456:SYNTHETIC-test-token"


def published_world(selections=(5, 5, 7, 9, 9, 12)):
    w = World(); w.activate(); comp, _ = w.competition(cap=10)
    custs = [w.customer() for _ in selections]
    receipts = [w.enter(comp, c, s)["receipt_hash"] for c, s in zip(custs, selections)]
    w.close(comp); signer = fairness.Signer()
    with w.as_staff("ops") as cur:
        res = fairness.compute_and_publish(cur, comp, signer)
    return w, comp, signer, res, receipts


def test_honest_result_verifies():
    w, comp, signer, res, _ = published_world()
    assert res["publish"] == "OK" and res["attestation"]["verified"] and res["winning_number"] == 7


def test_no_winner_when_all_selections_repeat():
    w, comp, signer, res, _ = published_world((3, 3, 8, 8))
    assert res["outcome"] == "NO_WINNER" and res["winning_number"] is None and res["publish"] == "OK"


def test_malicious_admin_cannot_replace_published_winner():
    w, comp, *_ = published_world()
    with superuser() as c:  # even a superuser hits the immutability trigger
        with pytest.raises(Exception, match="IMMUTABLE_RECORD"):
            c.execute("UPDATE veriq.result_runs SET winning_number=5 WHERE competition_id=%s", (comp,))


def test_dba_snapshot_tamper_is_detected_by_independent_verifier():
    """Attacker with superuser disables triggers and edits an accepted selection after freeze.
    Expected: re-export no longer matches witnessed chain head / receipts -> verifier fails closed."""
    w, comp, signer, res, receipts = published_world()
    with superuser() as c:
        c.execute("SET session_replication_role = replica")  # bypasses triggers: the strongest insider
        c.execute("UPDATE veriq.entries SET selection = 1 WHERE competition_id=%s AND seq = 2", (comp,))
    with w.as_staff("ops") as cur:
        m = fairness.export_frozen(cur, comp)
    from veriq_rules import canonical, digest
    forged_sig = signer.sign(canonical(m))  # even if the attacker also controls the signing key
    v = veriq_verifier.verify(m, forged_sig, signer.public_raw(), {"manifest_digest": digest(m), "winning_number": 1},
                              witnessed_chain_head=res["manifest"]["chain_head"], customer_receipts=receipts)
    assert not v["verified"] and any(r.startswith("RECEIPT_TAMPERED") for r in v["reasons"])


def test_omitted_entry_detected():
    w, comp, signer, res, receipts = published_world()
    m = copy.deepcopy(res["manifest"]); m["entries"].pop(2); m["count"] -= 1
    from veriq_rules import canonical, digest
    v = veriq_verifier.verify(m, signer.sign(canonical(m)), signer.public_raw(), {"manifest_digest": digest(m), "winning_number": 7},
                              customer_receipts=receipts)
    assert not v["verified"] and "COUNT_MISMATCH" in v["reasons"] and any(r.startswith("RECEIPT_OMITTED") for r in v["reasons"])


def test_forged_signature_and_wrong_claim_rejected():
    w, comp, signer, res, _ = published_world()
    other = fairness.Signer()
    v = veriq_verifier.verify(res["manifest"], other.sign(b"x"), signer.public_raw(), {"manifest_digest": res["manifest_digest"], "winning_number": 9})
    assert "SIGNATURE_INVALID" in v["reasons"] and "OUTCOME_MISMATCH" in v["reasons"]


def test_publication_refused_without_matching_attestation():
    w = World(); w.activate(); comp, _ = w.competition(); w.enter(comp, w.customer(), 4); w.close(comp)
    s = fairness.Signer()
    with w.as_staff("ops") as cur:
        m = fairness.export_frozen(cur, comp)
        from veriq_rules import canonical, digest
        call(cur, "record_result", comp, "lowest-unique/1.0.0", json.dumps(m), digest(m), s.sign(canonical(m)), "k", "WINNER", 4, None)
        assert call(cur, "publish_result", comp, json.dumps({"verified": True, "manifest_digest": "f" * 64, "winning_number": 4})) == "VERIFICATION_MISMATCH"
        assert call(cur, "publish_result", comp, json.dumps({"verified": False, "manifest_digest": digest(m), "winning_number": 4})) == "VERIFICATION_MISMATCH"


def test_result_cannot_be_recorded_before_freeze():
    w = World(); w.activate(); comp, _ = w.competition()
    with pytest.raises(Exception, match="NOT_FROZEN"):
        with w.as_staff("ops") as cur:
            call(cur, "record_result", comp, "a", "{}", "0" * 64, "s", "k", "NO_WINNER", None, None)


def test_audit_chain_detects_tamper():
    w = World(); w.activate()
    with w.as_staff("ops") as cur:
        assert call(cur, "verify_audit_chain")["ok"]
    with superuser() as c:
        c.execute("SET session_replication_role = replica")
        c.execute("UPDATE veriq.audit_log SET payload='{\"forged\":true}' WHERE id=(SELECT min(id) FROM veriq.audit_log WHERE legal_entity_id=%s)", (w.entity,))
    with w.as_staff("ops") as cur:
        r = call(cur, "verify_audit_chain"); assert not r["ok"]


# ---------- Telegram ----------
def fields(uid=777, age=0):
    return {"auth_date": str(int(time.time()) - age), "query_id": "AAH-synthetic", "user": json.dumps({"id": uid, "first_name": "Test"})}


def test_telegram_valid():
    assert telegram.validate_init_data(telegram.sign_for_tests(fields(), BOT), BOT)["telegram_user_id"] == "777"


@pytest.mark.parametrize("mutate,code", [
    (lambda s: s.replace("777", "778"), "BAD_SIGNATURE"),                   # forged user id
    (lambda s: s + "&is_winner=true", "BAD_SIGNATURE"),                      # injected client flag
    (lambda s: s.replace("hash=", "hash=0"), "BAD_SIGNATURE"),
    (lambda s: s.split("&hash=")[0], "MISSING_HASH"),
    (lambda s: s + "&user=x", "DUPLICATE_FIELD"),
])
def test_telegram_forgeries(mutate, code):
    with pytest.raises(telegram.TelegramAuthError, match=code):
        telegram.validate_init_data(mutate(telegram.sign_for_tests(fields(), BOT)), BOT)


def test_telegram_stale_and_wrong_bot():
    with pytest.raises(telegram.TelegramAuthError, match="STALE_AUTH_DATE"):
        telegram.validate_init_data(telegram.sign_for_tests(fields(age=3600), BOT), BOT)
    with pytest.raises(telegram.TelegramAuthError, match="BAD_SIGNATURE"):
        telegram.validate_init_data(telegram.sign_for_tests(fields(), "999:other-bot"), BOT)


# ---------- Payment webhooks ----------
SECRET = b"synthetic-provider-secret"


def test_webhook_signature_replay_window():
    body = b'{"event_id":"e1"}'; ts = int(time.time())
    assert payments.verify_webhook(body, payments.sign_for_tests(body, SECRET, ts), str(ts), SECRET)["event_id"] == "e1"
    with pytest.raises(payments.WebhookRejected, match="BAD_SIGNATURE"):
        payments.verify_webhook(b'{"event_id":"e2"}', payments.sign_for_tests(body, SECRET, ts), str(ts), SECRET)
    old = ts - 3600
    with pytest.raises(payments.WebhookRejected, match="OUTSIDE_REPLAY_WINDOW"):
        payments.verify_webhook(body, payments.sign_for_tests(body, SECRET, old), str(old), SECRET)
