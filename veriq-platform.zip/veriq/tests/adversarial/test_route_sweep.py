"""Sweep EVERY route: no route except the explicit public list works anonymously; hostile inputs never cause 5xx."""
import uuid
from fastapi.routing import APIRoute
from fastapi.testclient import TestClient
from conftest import World
from veriq_core import security
from veriq_core.api.app import app

client = TestClient(app, base_url="https://testserver", raise_server_exceptions=False)
# Routes that are intentionally reachable without a session, each with its own gate:
PUBLIC = {"/health", "/ready", "/v1/auth/customers", "/v1/auth/passkey/register/finish", "/v1/auth/passkey/login/begin",
          "/v1/auth/passkey/login/finish", "/v1/webhooks/payments/{provider}", "/v1/telegram/webhook/{entity}", "/v1/telegram/miniapp/entry"}
HOSTILE = ["' OR 1=1 --", "../../etc/passwd", "<script>alert(1)</script>", "\u0000", "%00", "${jndi:ldap://x}", "😀" * 50, "-1"]


def routes():
    for r in app.routes:
        if isinstance(r, APIRoute):
            for m in r.methods - {"HEAD", "OPTIONS"}:
                yield m, r.path


def fill(path, v):
    import re
    from urllib.parse import quote
    return re.sub(r"\{[^}]+\}", quote(v, safe=""), path)


def test_every_private_route_requires_authentication():
    leaks = []
    for m, p in routes():
        if p in PUBLIC:
            continue
        r = client.request(m, fill(p, str(uuid.uuid4())), json={})
        if r.status_code not in (401, 403):
            leaks.append((m, p, r.status_code))
    assert not leaks, leaks


def test_public_routes_have_their_own_gate():
    e = str(uuid.uuid4())
    assert client.post("/v1/webhooks/payments/fakepay", content=b"{}", headers={"X-Signature": "x", "X-Timestamp": "1", "X-Entity": e}).status_code in (401, 503)
    assert client.post(f"/v1/telegram/webhook/{e}", json={"update_id": 1}).status_code == 401
    assert client.post("/v1/telegram/miniapp/entry", headers={"X-Entity": e},
                       json={"init_data": "user=%7B%22id%22%3A1%7D&hash=00", "competition_id": e, "selection": 1, "idempotency_key": "xxxxxxxx"}).status_code == 401


def test_hostile_inputs_never_cause_server_errors():
    w = World()
    hdr = {"Authorization": "Bearer " + security.issue(w.staff["ops"], w.entity, "staff", roles=["COMP_OPS", "SPONSOR", "INVENTORY", "FULFILLMENT", "COMPLIANCE"])}
    errors = []
    for m, p in routes():
        for v in HOSTILE:
            r = client.request(m, fill(p, v), headers={**hdr, "X-Entity": w.entity, "Idempotency-Key": "hostile-key-1"},
                               params={"country": v, "product": v, "channel": v}, json={"selection": 1, "phone": v, "full_name": v})
            if r.status_code >= 500:
                errors.append((m, p, repr(v), r.status_code))
    assert not errors, errors[:10]


def test_injection_in_query_is_inert():
    w = World()
    hdr = {"Authorization": "Bearer " + security.issue(w.staff["ops"], w.entity, "staff", roles=["COMP_OPS"])}
    r = client.get("/v1/availability", params={"country": "ET' OR '1'='1", "product": "x", "channel": "WEB"}, headers=hdr)
    assert r.status_code in (200, 422) and r.json().get("decision", "DENIED_COUNTRY") != "OK"


def test_null_bytes_rejected_everywhere_with_400():
    w = World()
    hdr = {"Authorization": "Bearer " + security.issue(w.staff["ops"], w.entity, "staff", roles=["COMP_OPS"]), "X-Entity": w.entity}
    assert client.get("/v1/availability", params={"country": "\x00", "product": "x", "channel": "WEB"}, headers=hdr).status_code == 400
    r = client.post("/v1/auth/customers", headers={**hdr, "Content-Type": "application/json"},
                    content=b'{"phone":"0911\\u0000","full_name":"ab","birth_date":"1990-01-01","accept_terms":true}')
    assert r.status_code == 400 and r.json()["code"] == "INVALID_INPUT"
    assert client.get(f"/v1/entries/%00/receipt", headers=hdr).status_code == 400
