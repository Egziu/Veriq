"""Regression for Gap 3: a lookalike table earlier in search_path must not bypass ledger immutability."""
import pytest
from conftest import World, call, superuser


def test_lookalike_table_cannot_hijack_guard():
    w = World()
    with w.as_staff("cfo") as cur:
        j = call(cur, "post_journal", "x", "hijack-1", "", '[{"account":"1000-BANK","currency":"ETB","amount_minor":5},'
                 '{"account":"4000-SPONSOR-REVENUE","currency":"ETB","amount_minor":-5}]', None)
    with superuser() as c:
        c.execute("CREATE SCHEMA IF NOT EXISTS evil; CREATE TABLE IF NOT EXISTS evil.journals(id uuid, state text)")
        c.execute("INSERT INTO evil.journals VALUES (%s,'DRAFT')", (j,))
        c.execute("SET search_path = evil, veriq, public")
        with pytest.raises(Exception, match="IMMUTABLE_RECORD"):
            c.execute("UPDATE veriq.journal_lines SET amount_minor=999 WHERE journal_id=%s", (j,))
