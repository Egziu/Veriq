"""End-to-end through HTTP: auth, problem+json, idempotent replay, BOLA, close, verified result."""
import uuid
from fastapi.testclient import TestClient
from conftest import World
from veriq_core import security
from veriq_core.api.app import app

client = TestClient(app)


def hdr(tok, **kw):
    return {"Authorization": f"Bearer {tok}", **kw}


def test_full_vertical_slice_over_http():
    w = World(); w.activate(); comp, _ = w.competition(cap=2)
    a, b, c = w.customer(), w.customer(), w.customer()
    ta, tb, tc = (security.issue(x, w.entity, "customer") for x in (a, b, c))
    staff = security.issue(w.staff["ops"], w.entity, "staff", roles=["COMP_OPS"])

    assert client.get("/v1/availability", params={"country": "ET", "product": "PAID_COMPETITION", "channel": "WEB"},
                      headers=hdr(ta)).json()["decision"] == "DENIED_PRODUCT"
    r1 = client.post(f"/v1/competitions/{comp}/entries", json={"selection": 3}, headers=hdr(ta, **{"Idempotency-Key": "aaaa-0001"}))
    assert r1.status_code == 201 and r1.headers["strict-transport-security"]
    r1b = client.post(f"/v1/competitions/{comp}/entries", json={"selection": 3}, headers=hdr(ta, **{"Idempotency-Key": "aaaa-0001"}))
    assert r1b.status_code == 200 and r1b.json()["entry_id"] == r1.json()["entry_id"]
    client.post(f"/v1/competitions/{comp}/entries", json={"selection": 3}, headers=hdr(tb, **{"Idempotency-Key": "bbbb-0001"}))
    client.post(f"/v1/competitions/{comp}/entries", json={"selection": 8}, headers=hdr(tc, **{"Idempotency-Key": "cccc-0001"}))

    bola = client.get(f"/v1/entries/{r1.json()['entry_id']}/receipt", headers=hdr(tb))
    assert bola.status_code == 404 and bola.headers["content-type"].startswith("application/problem+json")
    assert client.get(f"/v1/entries/{r1.json()['entry_id']}/receipt", headers=hdr(ta)).status_code == 200

    assert client.post(f"/v1/staff/competitions/{comp}/close", headers=hdr(ta)).status_code == 403
    assert client.post(f"/v1/staff/competitions/{comp}/close", headers=hdr(staff)).json()["high_water"] == 3
    late = client.post(f"/v1/competitions/{comp}/entries", json={"selection": 1}, headers=hdr(ta, **{"Idempotency-Key": "aaaa-0002"}))
    assert late.status_code == 409 and late.json()["code"] == "COMPETITION_NOT_OPEN"

    res = client.post(f"/v1/staff/competitions/{comp}/result", headers=hdr(staff)).json()
    assert res["publish"] == "OK" and res["winning_number"] == 8 and res["attestation"]["verified"]
    man = client.get(f"/v1/competitions/{comp}/manifest", headers=hdr(tb)).json()
    assert man["manifest"]["count"] == 3


def test_tampered_and_missing_tokens():
    assert client.get("/v1/availability", params={"country": "ET", "product": "x", "channel": "WEB"}).status_code == 401
    tok = security.issue(str(uuid.uuid4()), str(uuid.uuid4()), "customer")
    body, sig = tok.split(".")
    forged = body[:-2] + ("AA" if body[-2:] != "AA" else "BB") + "." + sig
    assert client.get("/v1/availability", params={"country": "ET", "product": "x", "channel": "WEB"}, headers=hdr(forged)).status_code == 401


def test_staff_cannot_submit_entries_and_bad_channel_rejected():
    w = World(); w.activate(); comp, _ = w.competition()
    staff = security.issue(w.staff["ops"], w.entity, "staff", roles=["COMP_OPS"])
    assert client.post(f"/v1/competitions/{comp}/entries", json={"selection": 3}, headers=hdr(staff, **{"Idempotency-Key": "ssss-0001"})).status_code == 403
