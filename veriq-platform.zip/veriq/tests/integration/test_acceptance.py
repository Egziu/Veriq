"""Critical acceptance + close transaction."""
import threading, uuid
from conftest import call, World
from veriq_core.db import tx


def test_receipt_and_idempotent_replay(live_world):
    w = live_world; comp, _ = w.competition(); cu = w.customer()
    a = w.enter(comp, cu, 42, key="key-aaaaaaaa"); b = w.enter(comp, cu, 42, key="key-aaaaaaaa")
    assert a["ok"] and b["ok"] and b["replay"] and a["entry_id"] == b["entry_id"] and a["seq"] == b["seq"] == 1
    assert w.enter(comp, cu, 43, key="key-aaaaaaaa")["code"] == "IDEMPOTENCY_CONFLICT"


def test_eligibility_controls(live_world):
    w = live_world; comp, _ = w.competition(cap=2)
    assert w.enter(comp, w.customer(verified=False), 1)["code"] == "ELIGIBILITY_INCOMPLETE"
    assert w.enter(comp, w.customer(consent=False), 1)["code"] == "CONSENT_REQUIRED"
    cu = w.customer()
    assert w.enter(comp, cu, 0)["code"] == "SELECTION_OUT_OF_RANGE"
    assert w.enter(comp, cu, 1)["ok"] and w.enter(comp, cu, 2)["ok"]
    assert w.enter(comp, cu, 3)["code"] == "ENTRY_CAP_REACHED"


def test_cap_is_shared_across_channels(live_world):
    w = live_world; comp, _ = w.competition(cap=1); cu = w.customer()
    assert w.enter(comp, cu, 5, channel="WEB")["ok"]
    assert w.enter(comp, cu, 6, channel="TELEGRAM")["code"] == "ENTRY_CAP_REACHED"


def test_self_exclusion_enforced_and_cannot_be_shortened(live_world):
    w = live_world; comp, _ = w.competition(); cu = w.customer()
    with tx(w.entity) as cur:
        cur.execute("UPDATE veriq.customers SET self_excluded_until = now() + interval '180 days' WHERE id=%s", (cu,))
    assert w.enter(comp, cu, 5)["code"] == "SELF_EXCLUDED"
    try:
        with tx(w.entity) as cur:
            cur.execute("UPDATE veriq.customers SET self_excluded_until = NULL WHERE id=%s", (cu,))
        raise AssertionError("shortening allowed")
    except Exception as e:
        assert "SELF_EXCLUSION_CANNOT_BE_SHORTENED" in str(e)


def test_app_cannot_self_verify_kyc(live_world):
    w = live_world; cu = w.customer(verified=False)
    try:
        with tx(w.entity) as cur:
            cur.execute("UPDATE veriq.customers SET kyc_state='VERIFIED', age_verified=true WHERE id=%s", (cu,))
        raise AssertionError("direct KYC write allowed")
    except Exception as e:
        assert "permission denied" in str(e)


def test_prize_must_be_secured_before_open(live_world):
    w = live_world; comp, _ = w.competition(secure=False)
    with w.as_staff("ops") as cur:
        assert call(cur, "open_competition", comp) == "RESERVE_SHORTFALL"


def test_free_campaign_cannot_charge(live_world):
    w = live_world; comp, _ = w.competition(); cu = w.customer()
    assert w.enter(comp, cu, 4, pi=str(uuid.uuid4()))["code"] == "FREE_ENTRY_MUST_NOT_CHARGE"


def test_concurrent_entries_get_contiguous_sequence(live_world):
    w = live_world; comp, _ = w.competition(cap=5, hi=1000)
    custs = [w.customer() for _ in range(12)]; results = []
    def go(c):
        for _ in range(5): results.append(w.enter(comp, c, (hash(c) + _) % 1000 + 1))
    ts = [threading.Thread(target=go, args=(c,)) for c in custs]; [t.start() for t in ts]; [t.join() for t in ts]
    seqs = sorted(r["seq"] for r in results if r["ok"])
    assert seqs == list(range(1, 61))


def test_close_race_no_entry_after_close(live_world):
    w = live_world; comp, _ = w.competition(cap=50, hi=10000)
    custs = [w.customer() for _ in range(8)]; outcomes = []; stop = threading.Event()
    def spam(c):
        i = 0
        while not stop.is_set() and i < 50:
            outcomes.append(w.enter(comp, c, i + 1)); i += 1
    ts = [threading.Thread(target=spam, args=(c,)) for c in custs]; [t.start() for t in ts]
    import time; time.sleep(0.15)
    closed = w.close(comp); stop.set(); [t.join() for t in ts]
    assert closed["ok"]
    hw = closed["high_water"]
    accepted = [o for o in outcomes if o["ok"]]
    assert len(accepted) == hw, (len(accepted), hw)
    assert sorted(o["seq"] for o in accepted) == list(range(1, hw + 1))
    assert all(o["code"] == "COMPETITION_NOT_OPEN" for o in outcomes if not o["ok"])
    assert w.enter(comp, custs[0], 9999)["code"] == "COMPETITION_NOT_OPEN"


def test_only_comp_ops_can_close(live_world):
    w = live_world; comp, _ = w.competition()
    with w.as_staff("support") as cur:
        assert call(cur, "close_competition", comp)["code"] == "ROLE_NOT_HELD"


def test_approved_rule_is_immutable(live_world):
    w = live_world; _, rid = w.competition()
    try:
        with w.as_staff("compliance") as cur:
            cur.execute("UPDATE veriq.rule_versions SET body='{}' WHERE id=%s", (rid,))
        raise AssertionError
    except Exception as e:
        assert "permission denied" in str(e) or "IMMUTABLE" in str(e)


def test_rule_creator_cannot_approve_own_rule(world):
    with world.as_staff("creator") as cur:
        rid = call(cur, "draft_rule", '{"a":1}')
    with superuser_role_change(world) as cur:
        assert call(cur, "approve_rule", rid) == "CREATOR_EXCLUDED"


from contextlib import contextmanager
@contextmanager
def superuser_role_change(w):
    from conftest import superuser
    with superuser() as c:  # give the creator COMPLIANCE too: still excluded from approving own rule
        c.execute("UPDATE veriq.staff_users SET roles = ARRAY['COMP_OPS','COMPLIANCE'] WHERE id=%s", (w.staff["creator"],))
    with w.as_staff("creator") as cur:
        yield cur
