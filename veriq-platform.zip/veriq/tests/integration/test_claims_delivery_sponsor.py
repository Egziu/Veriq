"""Winner claim -> identity review -> serial allocation -> dispatch -> dual-control delivery -> ledger; sponsor portal."""
import hashlib, uuid
from fastapi.testclient import TestClient
from conftest import World, call, superuser, tx
from veriq_core import security
from veriq_core.api.app import app
from veriq_core.modules import fairness

client = TestClient(app, base_url="https://testserver")
H = lambda s: hashlib.sha256(s.encode()).hexdigest()


def tok(w, who, kind="staff", roles=()):
    return {"Authorization": "Bearer " + security.issue(w.staff.get(who, who), w.entity, kind, roles=roles)}


def ctok(w, cust):
    return {"Authorization": "Bearer " + security.issue(cust, w.entity, "customer")}


def published(w, sponsor=None, picks=(4, 4, 7, 9)):
    comp, _ = w.competition(cap=5, sponsor=sponsor, title="Synthetic <b>Phone</b> giveaway")
    custs = [w.customer() for _ in picks]
    for c, s in zip(custs, picks):
        w.enter(comp, c, s)
    w.close(comp)
    with w.as_staff("ops") as cur:
        r = fairness.compute_and_publish(cur, comp, fairness.Signer(entity=w.entity), tsa_urls=[], tsa_roots=[], min_witness=0)
    winner = custs[list(picks).index(r["winning_number"])] if r["winning_number"] is not None else None
    return comp, winner, custs


def stock(w, comp, serial="SN-0001"):
    with w.as_staff("inventory") as cur:
        return str(call(cur, "receive_prize_item", comp, "Synthetic X1 128GB", serial, 12, 2_500_000, H("delivery-note" + serial)))


def test_full_claim_to_delivery_with_controls():
    w = World(); w.activate(); comp, winner, custs = published(w)
    loser = [c for c in custs if c != winner][0]
    assert client.post(f"/v1/competitions/{comp}/claim", headers=ctok(w, loser)).json()["code"] == "NOT_THE_WINNER"
    claim = client.post(f"/v1/competitions/{comp}/claim", headers=ctok(w, winner)).json()["claim_id"]
    assert client.put(f"/v1/claims/{claim}/address", headers=ctok(w, winner),
                      json={"recipient": "Winner Synthetic", "phone": "+251911000009", "city": "Mekelle", "details": "Kebele 14"}).json()["saved"]
    assert client.put(f"/v1/claims/{claim}/address", headers=ctok(w, loser),
                      json={"recipient": "x", "phone": "x", "city": "x", "details": "x"}).status_code == 404   # cannot redirect a prize

    item = stock(w, comp)
    other_comp, *_ = published(w, picks=(1,))
    wrong_item = stock(w, other_comp, "SN-OTHER")
    assert client.post(f"/v1/staff/claims/{claim}/allocate", headers=tok(w, "inventory", roles=["INVENTORY"]),
                       json={"prize_item_id": item}).json()["code"] == "CLAIM_NOT_APPROVED"
    assert client.post(f"/v1/staff/claims/{claim}/review", headers=tok(w, "courier", roles=["FULFILLMENT"]),
                       json={"approve": True, "note": "x"}).status_code == 403
    assert client.post(f"/v1/staff/claims/{claim}/review", headers=tok(w, "compliance", roles=["COMPLIANCE"]),
                       json={"approve": True, "note": "ID checked in person (synthetic)"}).json()["result"] == "OK"
    assert client.post(f"/v1/staff/claims/{claim}/allocate", headers=tok(w, "inventory", roles=["INVENTORY"]),
                       json={"prize_item_id": wrong_item}).json()["code"] == "ITEM_NOT_AVAILABLE"
    assert client.post(f"/v1/staff/claims/{claim}/allocate", headers=tok(w, "inventory", roles=["INVENTORY"]),
                       json={"prize_item_id": item}).json()["result"] == "OK"

    addr = client.get(f"/v1/staff/claims/{claim}/address", headers=tok(w, "courier", roles=["FULFILLMENT"])).json()
    assert addr["city"] == "Mekelle"
    assert client.get(f"/v1/staff/claims/{claim}/address", headers=tok(w, "inventory", roles=["INVENTORY"])).status_code == 403
    assert client.post(f"/v1/staff/claims/{claim}/dispatch", headers=tok(w, "courier", roles=["FULFILLMENT"]),
                       json={"carrier": "Synthetic Courier", "tracking_ref": "TRK-1"}).json()["result"] == "OK"
    proof = {"scanned_serial": "SN-0001", "recipient_signature_sha256": H("sig"), "handover_photo_sha256": H("photo")}
    assert client.post(f"/v1/staff/claims/{claim}/delivered", headers=tok(w, "courier", roles=["FULFILLMENT"]),
                       json=proof).json()["code"] == "DUAL_CONTROL_REQUIRED"
    assert client.post(f"/v1/staff/claims/{claim}/delivered", headers=tok(w, "courier2", roles=["FULFILLMENT"]),
                       json={**proof, "scanned_serial": "SN-9999"}).json()["code"] == "SERIAL_MISMATCH"
    assert client.post(f"/v1/staff/claims/{claim}/delivered", headers=tok(w, "courier2", roles=["FULFILLMENT"]),
                       json=proof).json()["result"] == "OK"

    with superuser() as c:
        assert c.execute("SELECT state FROM veriq.prize_items WHERE id=%s", (item,)).fetchone()["state"] == "DELIVERED"
        bal = {r["code"]: r["s"] for r in c.execute("SELECT a.code, sum(l.amount_minor) s FROM veriq.journal_lines l JOIN veriq.accounts a "
               "ON a.id=l.account_id WHERE l.legal_entity_id=%s GROUP BY a.code", (w.entity,)).fetchall()}
        assert bal["2200-PRIZE-OBLIGATION"] == 2_500_000 and bal["1300-PRIZE-INVENTORY"] == -2_500_000
        reads = c.execute("SELECT count(*) n FROM veriq.audit_log WHERE legal_entity_id=%s AND action='pii.read'", (w.entity,)).fetchone()["n"]
        assert reads == 1
    mine = client.get("/v1/me/claims", headers=ctok(w, winner)).json()
    assert mine[0]["state"] == "DELIVERED" and mine[0]["tracking_ref"] == "TRK-1"


def test_no_winner_means_no_claim_and_claim_period_enforced():
    w = World(); w.activate()
    comp, winner, custs = published(w, picks=(3, 3))
    assert client.post(f"/v1/competitions/{comp}/claim", headers=ctok(w, custs[0])).json()["code"] == "NO_PUBLISHED_WINNER"
    comp2, winner2, _ = published(w)
    with superuser() as c:
        c.execute("ALTER TABLE veriq.result_runs DISABLE TRIGGER result_runs_guard")
        c.execute("UPDATE veriq.result_runs SET published_at = now() - interval '31 days' WHERE competition_id=%s", (comp2,))
        c.execute("ALTER TABLE veriq.result_runs ENABLE TRIGGER result_runs_guard")
    assert client.post(f"/v1/competitions/{comp2}/claim", headers=ctok(w, winner2)).json()["code"] == "CLAIM_PERIOD_ENDED"


def test_unverified_winner_cannot_be_approved():
    w = World(); w.activate(); comp, winner, _ = published(w)
    claim = client.post(f"/v1/competitions/{comp}/claim", headers=ctok(w, winner)).json()["claim_id"]
    with superuser() as c:
        c.execute("SET veriq.identity_cmd='on'"); c.execute("UPDATE veriq.customers SET kyc_state='REJECTED' WHERE id=%s", (winner,))
    assert client.post(f"/v1/staff/claims/{claim}/review", headers=tok(w, "compliance", roles=["COMPLIANCE"]),
                       json={"approve": True, "note": "x"}).json()["code"] == "NOT_REVIEWABLE"


def test_sponsor_portal_is_scoped_aggregated_and_suppressed():
    w = World(); w.activate(); w.activate("SPONSOR_FREE", "ANDROID")
    s1, s2 = w.sponsor("sponsor", "Synthetic Telecom"), w.sponsor("sponsor_other", "Synthetic Bank")
    comp, _ = w.competition(cap=2, hi=1000, sponsor=s1)
    for i in range(12):
        w.enter(comp, w.customer(), i + 1, channel="WEB")
    w.enter(comp, w.customer(), 500, channel="ANDROID")
    mine = client.get("/v1/sponsor/competitions", headers=tok(w, "sponsor", roles=["SPONSOR"])).json()
    assert [m["id"] for m in mine] == [comp]
    rep = client.get(f"/v1/sponsor/competitions/{comp}/report", headers=tok(w, "sponsor", roles=["SPONSOR"])).json()
    assert rep["entries"] == 13 and rep["by_channel"]["WEB"] == 12 and rep["by_channel"]["ANDROID"] is None  # cell < 10 suppressed
    assert "customer" not in str(rep).lower()
    assert client.get(f"/v1/sponsor/competitions/{comp}/report", headers=tok(w, "sponsor_other", roles=["SPONSOR"])).json()["code"] == "NOT_FOUND"
    assert client.get("/v1/sponsor/competitions", headers=tok(w, "ops", roles=["COMP_OPS"])).status_code == 403
    assert client.get("/v1/sponsor/competitions", headers=ctok(w, w.customer())).status_code == 403


def test_small_campaign_totals_suppressed():
    w = World(); w.activate(); s = w.sponsor()
    comp, _ = w.competition(sponsor=s)
    w.enter(comp, w.customer(), 5)
    rep = client.get(f"/v1/sponsor/competitions/{comp}/report", headers=tok(w, "sponsor", roles=["SPONSOR"])).json()
    assert rep["entries"] is None and rep["entrants"] is None
