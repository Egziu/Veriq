"""Go/no-go control plane: deny by default, evidence + separated approvals, expiry, suspension."""
from datetime import timedelta
from conftest import World, NOW, EVIDENCE, call, superuser


def test_everything_blocked_by_default(world):
    with world.as_staff("ops") as cur:
        assert call(cur, "authz_check", world.entity, "ET", "SPONSOR_FREE", "WEB") == "DENIED_COUNTRY"
    world.create_authorization("SPONSOR_FREE", "WEB")
    with world.as_staff("ops") as cur:
        assert call(cur, "authz_check", world.entity, "ET", "SPONSOR_FREE", "WEB") == "DENIED_PRODUCT"   # row exists but BLOCKED
        assert call(cur, "authz_check", world.entity, "ET", "PAID_COMPETITION", "WEB") == "DENIED_PRODUCT"
        assert call(cur, "authz_check", world.entity, "KE", "SPONSOR_FREE", "WEB") == "DENIED_COUNTRY"


def test_activation_requires_evidence_and_three_distinct_approvers(world):
    aid = world.create_authorization()
    with world.as_staff("compliance") as cur:
        call(cur, "transition_authorization", aid, "DOSSIER", None, None); call(cur, "transition_authorization", aid, "REVIEWED", None, None)
    with world.as_staff("deploy") as cur:
        r = call(cur, "transition_authorization", aid, "LIMITED_PILOT", NOW(), NOW() + timedelta(days=1))
    assert r.startswith("MISSING_EVIDENCE")
    world.add_evidence(aid, EVIDENCE)
    with world.as_staff("compliance") as cur:
        assert call(cur, "approve_authorization", aid, "COMPLIANCE", "LIMITED_PILOT") == "OK"
    with world.as_staff("deploy") as cur:
        assert call(cur, "transition_authorization", aid, "LIMITED_PILOT", NOW(), NOW() + timedelta(days=1)) == "MISSING_APPROVALS"


def test_forged_approval_role_rejected(world):
    aid = world.create_authorization()
    with world.as_staff("support") as cur:  # support staff tries to sign as CFO
        assert call(cur, "approve_authorization", aid, "CFO", "LIMITED_PILOT") == "ROLE_NOT_HELD"


def test_creator_cannot_finalize_activation(world):
    aid = world.create_authorization(); world.add_evidence(aid, EVIDENCE)
    with world.as_staff("compliance") as cur:
        call(cur, "transition_authorization", aid, "DOSSIER", None, None); call(cur, "transition_authorization", aid, "REVIEWED", None, None)
    world.approve_all(aid, "LIMITED_PILOT")
    with world.as_staff("creator") as cur:
        assert call(cur, "transition_authorization", aid, "LIMITED_PILOT", NOW(), NOW() + timedelta(days=1)) == "CREATOR_EXCLUDED"


def test_paid_requires_provider_acceptance_evidence(world):
    aid = world.create_authorization("PAID_COMPETITION"); world.add_evidence(aid, EVIDENCE)
    with world.as_staff("compliance") as cur:
        call(cur, "transition_authorization", aid, "DOSSIER", None, None); call(cur, "transition_authorization", aid, "REVIEWED", None, None)
    world.approve_all(aid, "LIMITED_PILOT")
    with world.as_staff("deploy") as cur:
        assert call(cur, "transition_authorization", aid, "LIMITED_PILOT", NOW(), NOW() + timedelta(days=1)) == "MISSING_EVIDENCE:PROVIDER_ACCEPTANCE"


def test_cannot_skip_states(world):
    aid = world.create_authorization()
    with world.as_staff("deploy") as cur:
        assert call(cur, "transition_authorization", aid, "LIVE", NOW(), NOW() + timedelta(days=1)) == "ILLEGAL_TRANSITION"


def test_suspension_stops_acceptance_immediately_but_history_stays_readable(live_world):
    w = live_world; comp, _ = w.competition(); cu = w.customer()
    first = w.enter(comp, cu, 7); assert first["ok"]
    with w.as_staff("compliance") as cur:
        assert call(cur, "transition_authorization", w.auth[("SPONSOR_FREE", "WEB")], "SUSPENDED", None, None) == "OK"
    assert w.enter(comp, cu, 8)["code"] == "DENIED_PRODUCT"
    from veriq_core.db import tx
    with tx(w.entity) as cur:
        cur.execute("SELECT count(*) n FROM veriq.entries WHERE competition_id=%s", (comp,)); assert cur.fetchone()["n"] == 1


def test_expired_scope_and_expired_evidence(live_world):
    w = live_world; comp, _ = w.competition(); cu = w.customer()
    with superuser() as c:  # simulate the clock passing effective_to (fixture-only manipulation)
        c.execute("ALTER TABLE veriq.country_product_authorizations DISABLE TRIGGER ALL")
        c.execute("UPDATE veriq.country_product_authorizations SET effective_to = now() - interval '1 second', "
                  "effective_from = now() - interval '2 days' WHERE id=%s", (w.auth[("SPONSOR_FREE", "WEB")],))
    assert w.enter(comp, cu, 9)["code"] == "EXPIRED_SCOPE"
    w2 = World(); aid = w2.activate()
    w2.add_evidence(aid, ["FAIRNESS_PROCESS"], expires=NOW() - timedelta(seconds=1))
    with w2.as_staff("ops") as cur:
        assert call(cur, "authz_check", w2.entity, "ET", "SPONSOR_FREE", "WEB") == "EXPIRED_SCOPE"


def test_channel_scoped(live_world):
    w = live_world; comp, _ = w.competition(); cu = w.customer()
    assert w.enter(comp, cu, 3, channel="ANDROID")["code"] == "DENIED_PRODUCT"
    assert w.enter(comp, cu, 3, channel="TELEGRAM")["ok"]
