"""HSM keys (SoftHSM2 via PKCS#11), envelope-encrypted PII, RFC 3161 witnessing of published results."""
import base64, json, uuid
import pytest
from conftest import World, call, superuser, tx
from support.local_tsa import LocalTSA
from veriq_core import pii
from veriq_core.kms import HsmKeyring, KeyringError, DevKeyring, keyring_for
from veriq_core.modules import fairness
from veriq_verifier.timestamp import verify_token, TimestampInvalid
import veriq_verifier


@pytest.fixture(scope="module")
def tsas():
    a, b = LocalTSA("Synthetic TSA A"), LocalTSA("Synthetic TSA B")
    yield a, b
    a.stop(); b.stop()


def test_hsm_private_key_is_not_extractable():
    import pkcs11, os
    from pkcs11 import Attribute, ObjectClass
    w = World(); k = keyring_for(w.entity)
    with k._session() as s:
        priv = s.get_key(object_class=ObjectClass.PRIVATE_KEY, label=f"veriq.{w.entity}.sign")
        assert priv[Attribute.EXTRACTABLE] is False and priv[Attribute.SENSITIVE] is True
        with pytest.raises(pkcs11.exceptions.AttributeSensitive):
            priv[Attribute.VALUE]


def test_unprovisioned_entity_fails_closed():
    with pytest.raises(KeyringError, match="KEY_NOT_PROVISIONED"):
        HsmKeyring.from_env(prefix=f"veriq.{uuid.uuid4()}").sign(b"x")


def test_dev_keyring_refused_in_production(monkeypatch):
    monkeypatch.setenv("VERIQ_ENV", "production")
    with pytest.raises(KeyringError, match="DEV_KEYRING_FORBIDDEN"):
        DevKeyring()


def test_pii_roundtrip_and_record_binding():
    w = World(); k = keyring_for(w.entity); a, b = str(uuid.uuid4()), str(uuid.uuid4())
    ct, wdek, kid = pii.encrypt(k, w.entity, a, {"full_name": "Hiwot Synthetic", "phone": "+251911000001"})
    assert pii.decrypt(k, w.entity, a, ct, wdek)["full_name"] == "Hiwot Synthetic" and kid.startswith("p256:")
    with pytest.raises((KeyringError, pii.PiiError)):          # ciphertext moved onto another customer
        pii.decrypt(k, w.entity, b, ct, wdek)
    other = World()
    with pytest.raises((KeyringError, pii.PiiError)):          # another entity's KEK cannot open it
        pii.decrypt(keyring_for(other.entity), other.entity, a, ct, wdek)
    flipped = bytearray(ct); flipped[-1] ^= 1
    with pytest.raises(pii.PiiError):
        pii.decrypt(k, w.entity, a, bytes(flipped), wdek)


def test_blind_index_normalizes_and_is_entity_scoped():
    w, v = World(), World(); k = keyring_for(w.entity)
    forms = ["+251911223344", "251911223344", "0911223344", "0911 22 33 44"]
    assert len({pii.phone_index(k, w.entity, f) for f in forms}) == 1
    assert pii.phone_index(k, w.entity, forms[0]) != pii.phone_index(keyring_for(v.entity), v.entity, forms[0])
    for bad in ["0811223344", "+25191122334", "+15551234567"]:
        with pytest.raises(pii.PiiError):
            pii.normalize_et_phone(bad)


def publish_with(w, urls, roots, min_witness=None, env=None, monkeypatch=None):
    if env and monkeypatch:
        monkeypatch.setenv("VERIQ_ENV", env)
    comp, _ = w.competition(cap=5)
    for s in (4, 4, 6, 9):
        w.enter(comp, w.customer(), s)
    w.close(comp)
    with w.as_staff("ops") as cur:
        r = fairness.compute_and_publish(cur, comp, fairness.Signer(entity=w.entity), tsa_urls=urls, tsa_roots=roots, min_witness=min_witness)
    return comp, r


def test_hsm_signed_result_witnessed_by_two_tsas_and_independently_verifiable(tsas):
    a, b = tsas; w = World(); w.activate()
    comp, r = publish_with(w, [a.url, b.url], [a.root_pem, b.root_pem], min_witness=2)
    assert r["publish"] == "OK" and r["winning_number"] == 6 and len(r["witnesses"]) == 2
    from fastapi.testclient import TestClient
    from veriq_core import security
    from veriq_core.api.app import app
    tok = security.issue(w.customer(), w.entity, "customer")
    m = TestClient(app, base_url="https://t").get(f"/v1/competitions/{comp}/manifest", headers={"Authorization": f"Bearer {tok}"}).json()
    # An outside auditor needs only: manifest, signature, public key, TSA roots.
    pub = base64.b64decode(m["public_key_der_b64"])
    v = veriq_verifier.verify(m["manifest"], m["signature"], pub, {"manifest_digest": m["manifest_digest"], "winning_number": m["winning_number"]})
    assert v["verified"] and m["key_id"].startswith("p256:")
    from veriq_core.modules.witness import commitment
    imprint = commitment(comp, m["manifest_digest"], m["manifest"]["chain_head"], m["manifest"]["high_water"])
    for wr in m["witness_receipts"]:
        info = verify_token(base64.b64decode(wr["token_der_b64"]), imprint, [a.root_pem, b.root_pem])
        assert info["serial"] == wr["serial_number"]


def test_production_refuses_publication_without_witnesses(monkeypatch):
    w = World(); w.activate()
    comp, r = publish_with(w, [], [], env="production", monkeypatch=monkeypatch)
    assert r["publish"] == "WITNESS_REQUIRED"
    with superuser() as c:
        assert c.execute("SELECT published_at FROM veriq.result_runs WHERE competition_id=%s", (comp,)).fetchone()["published_at"] is None


def test_one_tsa_down_still_witnessed_if_threshold_met(tsas):
    a, _ = tsas; w = World(); w.activate()
    comp, r = publish_with(w, ["http://127.0.0.1:9/down", a.url], [a.root_pem], min_witness=1)
    assert r["publish"] == "OK" and len(r["witnesses"]) == 1


def test_all_tsas_down_blocks(tsas):
    w = World(); w.activate()
    with pytest.raises(TimestampInvalid, match="INSUFFICIENT_WITNESSES"):
        publish_with(w, ["http://127.0.0.1:9/down"], [], min_witness=1)


def test_tampered_token_and_untrusted_tsa(tsas):
    a, b = tsas; w = World(); w.activate()
    comp, r = publish_with(w, [a.url], [a.root_pem], min_witness=1)
    t = r["witnesses"][0]["token"]
    from veriq_core.modules.witness import commitment
    imprint = commitment(comp, r["manifest_digest"], r["manifest"]["chain_head"], r["manifest"]["high_water"])
    with pytest.raises(TimestampInvalid, match="UNTRUSTED_TSA"):
        verify_token(t, imprint, [b.root_pem])
    gen = bytearray(t); i = gen.find(b"\x18\x0f")  # GeneralizedTime inside TSTInfo
    gen[i + 5] = ord("9") if gen[i + 5] != ord("9") else ord("8")
    with pytest.raises(TimestampInvalid):
        verify_token(bytes(gen), imprint, [a.root_pem])
