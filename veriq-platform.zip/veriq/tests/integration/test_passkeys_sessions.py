"""Passkeys (WebAuthn) and sessions end-to-end through HTTP with a real-crypto software authenticator."""
import os, uuid
import pytest
from fastapi.testclient import TestClient
from conftest import World, call, superuser, tx
from support.soft_authenticator import SoftAuthenticator
from veriq_core.api import app as api
from veriq_core.modules import identity

client = TestClient(api.app, base_url="https://testserver")


def onboard(w, phone=None, auth=None, birth="1990-05-01"):
    auth = auth or SoftAuthenticator()
    phone = phone or f"+2519{uuid.uuid4().int % 10**8:08d}"
    r = client.post("/v1/auth/customers", headers={"X-Entity": w.entity},
                    json={"phone": phone, "full_name": "Selam Synthetic", "birth_date": birth, "accept_terms": True})
    assert r.status_code == 200, r.text
    fin = client.post("/v1/auth/passkey/register/finish", headers={"X-Entity": w.entity, "X-Client": "mobile"},
                      json={"credential": auth.create(r.json()["registration_options"])})
    assert fin.status_code == 200, fin.text
    return r.json()["customer_id"], auth, fin.json()["token"], phone


def login(w, auth, principal=None, kind=None, **kw):
    opts = client.post("/v1/auth/passkey/login/begin", headers={"X-Entity": w.entity},
                       json={"principal_id": principal, "kind": kind}).json()
    return client.post("/v1/auth/passkey/login/finish", headers={"X-Entity": w.entity, "X-Client": "mobile"},
                       json={"credential": auth.get(opts, **kw)}), opts


def bearer(t): return {"Authorization": f"Bearer {t}"}


def test_onboard_register_and_profile_decrypts_for_owner_only():
    w = World(); cid, auth, token, phone = onboard(w)
    me = client.get("/v1/me", headers=bearer(token)).json()
    assert me["full_name"] == "Selam Synthetic" and me["phone_masked"].endswith(phone[-2:]) and "•••" in me["phone_masked"]
    with superuser() as c:  # nothing identifying is stored in clear
        row = c.execute("SELECT pii_ciphertext, phone_blind_index FROM veriq.customers WHERE id=%s", (cid,)).fetchone()
    assert phone[-8:].encode() not in bytes(row["pii_ciphertext"]) and b"Selam" not in bytes(row["pii_ciphertext"])
    assert len(row["phone_blind_index"]) == 64


def test_login_then_assertion_replay_rejected():
    w = World(); cid, auth, *_ = onboard(w)
    ok, opts = login(w, auth)
    assert ok.status_code == 200 and ok.json()["token"].startswith(f"vq1.{w.entity}.")
    replay = client.post("/v1/auth/passkey/login/finish", headers={"X-Entity": w.entity}, json={"credential": auth.get(opts)})
    assert replay.status_code == 401 and "CHALLENGE_REPLAYED" in replay.json()["detail"]


def test_phishing_origin_and_wrong_rp_rejected():
    w = World(); cid, auth, *_ = onboard(w)
    assert login(w, auth, origin="https://veriq-et.example")[0].status_code == 401
    assert login(w, auth, rp_id="evil.example")[0].status_code == 401


def test_counter_regression_revokes_credential():
    w = World(); cid, auth, *_ = onboard(w)
    assert login(w, auth, counter=10)[0].status_code == 200
    cloned = login(w, auth, counter=5)[0]
    assert cloned.status_code == 401 and "CLONE_SUSPECTED" in cloned.json()["detail"]
    assert login(w, auth, counter=20)[0].status_code == 401  # revoked for good


def test_unknown_credential_rejected():
    w = World(); onboard(w)
    assert login(w, SoftAuthenticator())[0].status_code == 401


def test_duplicate_phone_underage_and_bad_phone():
    w = World(); _, _, _, phone = onboard(w)
    dup = client.post("/v1/auth/customers", headers={"X-Entity": w.entity},
                      json={"phone": phone.replace("+251", "0"), "full_name": "Other", "birth_date": "1990-01-01", "accept_terms": True})
    assert dup.status_code == 409 and dup.json()["code"] == "PHONE_ALREADY_REGISTERED"   # blind index matches normalized forms
    young = client.post("/v1/auth/customers", headers={"X-Entity": w.entity},
                        json={"phone": "+251911223344", "full_name": "Kid", "birth_date": "2012-01-01", "accept_terms": True})
    assert young.json()["code"] == "AGE_REQUIREMENT"
    bad = client.post("/v1/auth/customers", headers={"X-Entity": w.entity},
                      json={"phone": "+15551234567", "full_name": "Xa Yb", "birth_date": "1990-01-01", "accept_terms": True})
    assert bad.json()["code"] == "INVALID_ET_MOBILE"


def test_logout_and_revoke_all():
    w = World(); cid, auth, t1, _ = onboard(w)
    t2 = login(w, auth)[0].json()["token"]
    assert client.post("/v1/auth/logout", headers=bearer(t1)).status_code == 200
    assert client.get("/v1/me", headers=bearer(t1)).status_code == 401
    assert client.get("/v1/me", headers=bearer(t2)).status_code == 200      # other device unaffected
    assert client.post("/v1/me/sessions/revoke-all", headers=bearer(t2)).json()["revoked"] >= 1
    assert client.get("/v1/me", headers=bearer(t2)).status_code == 401


def staff_enroll(w, who, uv=True):
    auth = SoftAuthenticator(uv=uv)
    with tx(w.entity, w.staff["admin"]) as cur:
        opts = identity.begin_registration(cur, w.staff[who], "staff", who)
    return auth, client.post("/v1/auth/passkey/register/finish", headers={"X-Entity": w.entity, "X-Client": "mobile"},
                             json={"credential": auth.create(opts)})


def test_staff_require_user_verification_and_short_sessions():
    w = World()
    _, r = staff_enroll(w, "ops", uv=False)
    assert r.status_code == 401
    auth, r = staff_enroll(w, "ops")
    assert r.status_code == 200 and r.json()["kind"] == "staff"
    with superuser() as c:
        ttl = c.execute("SELECT expires_at - created_at AS t FROM veriq.sessions WHERE principal_id=%s", (w.staff["ops"],)).fetchone()["t"]
    assert ttl.total_seconds() == 1800
    auth.uv = False
    assert login(w, auth, principal=w.staff["ops"], kind="staff")[0].status_code == 401   # UV required at every login


def test_deactivated_staff_lose_access_immediately():
    w = World(); w.activate(); comp, _ = w.competition()
    auth, r = staff_enroll(w, "ops"); token = r.json()["token"]
    with superuser() as c:
        c.execute("UPDATE veriq.staff_users SET active=false WHERE id=%s", (w.staff["ops"],))
    assert client.post(f"/v1/staff/competitions/{comp}/close", headers=bearer(token)).status_code == 401


def test_cookie_sessions_require_csrf_on_writes():
    w = World(); cid, auth, *_ = onboard(w)
    c2 = TestClient(api.app, base_url="https://testserver")
    opts = c2.post("/v1/auth/passkey/login/begin", headers={"X-Entity": w.entity}, json={}).json()
    r = c2.post("/v1/auth/passkey/login/finish", headers={"X-Entity": w.entity}, json={"credential": auth.get(opts)})
    assert "token" not in r.json() and "vq_session" in c2.cookies          # browsers never see the token
    assert c2.get("/v1/me").status_code == 200                               # GET via cookie fine
    assert c2.post("/v1/me/telegram/link-code").json()["code"] == "CSRF_FAILED"
    ok = c2.post("/v1/me/telegram/link-code", headers={"X-CSRF-Token": c2.cookies["vq_csrf"]})
    assert ok.status_code == 200 and len(ok.json()["code"]) == 9


def test_production_rejects_dev_tokens(monkeypatch):
    from veriq_core import security
    monkeypatch.setattr(api, "ENV", "production")
    tok = security.issue(str(uuid.uuid4()), str(uuid.uuid4()), "customer")
    r = client.get("/v1/availability", params={"country": "ET", "product": "x", "channel": "WEB"}, headers=bearer(tok))
    assert r.status_code == 401 and "DEV_TOKENS_DISABLED" in r.json()["detail"]


def test_session_token_from_other_entity_is_useless():
    a, b = World(), World(); _, _, token, _ = onboard(a)
    forged = token.replace(a.entity, b.entity)
    assert client.get("/v1/me", headers=bearer(forged)).status_code == 401


def test_expired_challenge_rejected():
    w = World(); cid, auth, *_ = onboard(w)
    opts = client.post("/v1/auth/passkey/login/begin", headers={"X-Entity": w.entity}, json={}).json()
    with superuser() as c:
        c.execute("UPDATE veriq.auth_challenges SET expires_at = now() - interval '1 second' WHERE legal_entity_id=%s AND consumed_at IS NULL", (w.entity,))
    r = client.post("/v1/auth/passkey/login/finish", headers={"X-Entity": w.entity}, json={"credential": auth.get(opts)})
    assert r.status_code == 401 and "CHALLENGE_EXPIRED" in r.json()["detail"]


def test_auth_endpoints_are_rate_limited():
    w = World()
    codes = [client.post("/v1/auth/passkey/login/begin", headers={"X-Entity": w.entity}, json={}).status_code for _ in range(25)]
    assert codes[:20] == [200] * 20 and set(codes[20:]) == {429}


def test_failed_assertion_still_burns_the_challenge():
    """Regression: a failed login used to roll back, un-consuming the challenge (retryable) and un-revoking clones."""
    w = World(); cid, auth, *_ = onboard(w)
    opts = client.post("/v1/auth/passkey/login/begin", headers={"X-Entity": w.entity}, json={}).json()
    bad = client.post("/v1/auth/passkey/login/finish", headers={"X-Entity": w.entity},
                      json={"credential": auth.get(opts, origin="https://phish.example")})
    assert bad.status_code == 401
    retry = client.post("/v1/auth/passkey/login/finish", headers={"X-Entity": w.entity}, json={"credential": auth.get(opts)})
    assert retry.status_code == 401 and "CHALLENGE_REPLAYED" in retry.json()["detail"]


def test_validation_errors_are_problem_json_without_echo():
    w = World()
    r = client.post("/v1/auth/customers", headers={"X-Entity": w.entity},
                    json={"phone": "+251911000000", "full_name": "<script>x</script>" * 20, "birth_date": "1990-01-01", "accept_terms": True})
    assert r.status_code == 422 and r.headers["content-type"].startswith("application/problem+json") and "<script>" not in r.text
