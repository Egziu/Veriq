"""Tenant isolation: RLS (FORCE + RESTRICTIVE) plus composite constraints. Cross-entity everything fails."""
import uuid
from conftest import World, call
from veriq_core.db import tx


def test_cross_entity_reads_writes_and_commands_fail():
    a, b = World(), World()
    a.activate(); comp, _ = a.competition(); ca = a.customer(); a.enter(comp, ca, 9)
    with tx(b.entity) as cur:
        for t in ("entries", "customers", "competitions", "audit_log", "journals", "staff_users", "outbox"):
            cur.execute(f"SELECT count(*) n FROM veriq.{t} WHERE legal_entity_id=%s", (a.entity,)); assert cur.fetchone()["n"] == 0, t
        cur.execute("SELECT count(*) n FROM veriq.entries e JOIN veriq.competitions c ON c.id=e.competition_id"); assert cur.fetchone()["n"] == 0
        assert call(cur, "accept_entry", comp, ca, 10, "idem-xxxxxxxx", "WEB", None)["code"] == "NOT_FOUND"
    try:  # write a row claiming A's entity while context is B
        with tx(b.entity) as cur:
            cur.execute("INSERT INTO veriq.customers(id,legal_entity_id,country_code) VALUES (%s,%s,'ET')", (str(uuid.uuid4()), a.entity))
        raise AssertionError
    except Exception as e:
        assert "row-level security" in str(e)
    with b.as_staff("ops") as cur:  # B's operator cannot close A's competition
        assert call(cur, "close_competition", comp)["code"] == "NOT_FOUND"
    with tx(b.entity, a.staff["ops"]) as cur:  # A's staff id presented under B context: not a B staff member
        assert call(cur, "close_competition", comp)["code"] == "ROLE_NOT_HELD"


def test_no_context_sees_nothing():
    a = World(); a.customer()
    import psycopg
    from psycopg.rows import dict_row
    from veriq_core.db import APP_DSN
    with psycopg.connect(APP_DSN, row_factory=dict_row) as c:
        assert c.execute("SELECT count(*) n FROM veriq.customers").fetchone()["n"] == 0
        assert c.execute("SELECT count(*) n FROM veriq.staff_users").fetchone()["n"] == 0


def test_app_role_is_not_privileged():
    import psycopg
    from veriq_core.db import APP_DSN
    with psycopg.connect(APP_DSN) as c:
        r = c.execute("SELECT rolsuper, rolbypassrls, rolcreaterole FROM pg_roles WHERE rolname=current_user").fetchone()
        assert r == (False, False, False)
        owner = c.execute("SELECT count(*) FROM pg_tables WHERE schemaname='veriq' AND tableowner=current_user").fetchone()[0]
        assert owner == 0
        for stmt in ("INSERT INTO veriq.entries(id) VALUES (gen_random_uuid())", "DELETE FROM veriq.audit_log",
                     "UPDATE veriq.competitions SET state='OPEN'", "ALTER TABLE veriq.entries DISABLE ROW LEVEL SECURITY"):
            try:
                c.execute(stmt); raise AssertionError(stmt)
            except psycopg.errors.InsufficientPrivilege:
                c.rollback()
