"""Telegram bot through aiogram's real dispatcher + webhook endpoint + Mini App entries."""
import json, os, time, uuid
import pytest
from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from fastapi.testclient import TestClient
from conftest import World, call, tx
from support.tg_session import RecordingSession
from veriq_core import security
from veriq_core.api import app as api
from veriq_core.modules import telegram as tgauth

TOKEN = "123456789:AAH-synthetic-test-token-not-real-xyz"
SECRET = "synthetic-webhook-secret-0123456789"
os.environ["VERIQ_TELEGRAM_BOT_TOKEN"] = TOKEN
os.environ["VERIQ_TELEGRAM_WEBHOOK_SECRET"] = SECRET
client = TestClient(api.app, base_url="https://testserver")
_uid = iter(range(10_000, 10**9))


def setup(w):
    sess = RecordingSession()
    api.bot_for(w.entity, Bot(TOKEN, session=sess, default=DefaultBotProperties(parse_mode="HTML")))
    return sess


def send(w, user, text, chat_type="private", secret=SECRET, update_id=None):
    uid = update_id or next(_uid)
    body = {"update_id": uid, "message": {"message_id": uid, "date": int(time.time()), "text": text,
            "chat": {"id": user if chat_type == "private" else -100123, "type": chat_type},
            "from": {"id": user, "is_bot": False, "first_name": "Synthetic"},
            "entities": [{"type": "bot_command", "offset": 0, "length": len(text.split()[0])}] if text.startswith("/") else []}}
    return client.post(f"/v1/telegram/webhook/{w.entity}", json=body, headers={"X-Telegram-Bot-Api-Secret-Token": secret})


def link_code(w, cust):
    return client.post("/v1/me/telegram/link-code", headers={"Authorization": "Bearer " + security.issue(cust, w.entity, "customer")}).json()["code"]


def test_webhook_secret_and_update_dedupe():
    w = World(); sess = setup(w)
    assert send(w, 1, "/start", secret="wrong").status_code == 401
    assert send(w, 1, "/start", secret="").status_code == 401
    assert send(w, 1, "/start", update_id=777).json() == {"ok": True}
    assert send(w, 1, "/start", update_id=777).json()["duplicate"] is True
    assert len(sess.texts()) == 1 and "VERIQ" in sess.texts()[0]


def test_link_flow_single_use_and_receipts():
    w = World(); w.activate(); sess = setup(w)
    comp, _ = w.competition(title="Synthetic <script>alert(1)</script> giveaway")
    cust = w.customer(); w.enter(comp, cust, 7)
    send(w, 42, "/receipts"); assert "not linked" in sess.texts()[-1]
    send(w, 42, "/link ZZZZ-ZZZZ"); assert "not recognised" in sess.texts()[-1]
    code = link_code(w, cust)
    send(w, 42, f"/link {code}"); assert sess.texts()[-1].startswith("Linked")
    send(w, 43, f"/link {code}"); assert "already used" in sess.texts()[-1]          # single use
    send(w, 42, "/receipts")
    out = sess.texts()[-1]
    assert "number 7" in out and "<script>" not in out and "&lt;script&gt;" in out    # escaped
    send(w, 42, "/unlink"); send(w, 42, "/receipts"); assert "not linked" in sess.texts()[-1]


def test_deep_link_start_payload_links():
    w = World(); sess = setup(w); cust = w.customer()
    code = link_code(w, cust).replace("-", "")
    send(w, 55, f"/start link_{code}"); assert sess.texts()[-1].startswith("Linked")


def test_group_chats_refused_and_link_bruteforce_limited():
    w = World(); sess = setup(w)
    send(w, 60, "/receipts", chat_type="supergroup"); assert "private chat" in sess.texts()[-1]
    for _ in range(5):
        send(w, 61, "/link AAAA-AAAA")
    send(w, 61, "/link BBBB-BBBB"); assert "Too many attempts" in sess.texts()[-1]


def test_prizes_hidden_when_telegram_channel_not_authorized():
    w = World(); w.activate("SPONSOR_FREE", "WEB"); sess = setup(w)
    w.competition(title="Web only campaign")
    send(w, 70, "/prizes"); assert "No campaigns are open on Telegram" in sess.texts()[-1]
    w.activate("SPONSOR_FREE", "TELEGRAM")
    send(w, 70, "/prizes"); assert "Web only campaign" in sess.texts()[-1]


def miniapp(w, user, comp, sel, key=None, tamper=None):
    fields = {"auth_date": str(int(time.time())), "query_id": "AAQ", "user": json.dumps({"id": user, "first_name": "S"})}
    init = tgauth.sign_for_tests(fields, TOKEN)
    if tamper:
        init = tamper(init)
    return client.post("/v1/telegram/miniapp/entry", headers={"X-Entity": w.entity},
                       json={"init_data": init, "competition_id": comp, "selection": sel, "idempotency_key": key or f"tg-{uuid.uuid4()}"})


def test_miniapp_entry_shares_canonical_rules():
    w = World(); w.activate(); w.activate("SPONSOR_FREE", "TELEGRAM"); setup(w)
    comp, _ = w.competition(cap=2); cust = w.customer()
    assert miniapp(w, 90, comp, 3).json()["code"] == "TELEGRAM_NOT_LINKED"
    send(w, 90, f"/link {link_code(w, cust)}")
    ok = miniapp(w, 90, comp, 3, key="tg-key-0001")
    assert ok.status_code == 201
    assert miniapp(w, 90, comp, 3, key="tg-key-0001").status_code == 200           # idempotent replay
    assert miniapp(w, 90, comp, 4, tamper=lambda s: s.replace("%22id%22%3A+90", "%22id%22%3A+91")).json()["code"] == "TELEGRAM_AUTH_FAILED"
    w.enter(comp, cust, 9, channel="WEB")                                           # second entry via web
    assert miniapp(w, 90, comp, 5).json()["code"] == "ENTRY_CAP_REACHED"            # cap shared across channels


def test_web_entry_endpoint_rejects_telegram_channel_spoof():
    w = World(); w.activate(); comp, _ = w.competition(); cust = w.customer()
    r = client.post(f"/v1/competitions/{comp}/entries", json={"selection": 3},
                    headers={"Authorization": "Bearer " + security.issue(cust, w.entity, "customer"), "Idempotency-Key": "spoof-0001", "X-Channel": "TELEGRAM"})
    assert r.status_code == 403
