"""Property-based: the production rule and the independent verifier agree on every input;
the rule is order-independent and matches the mathematical definition."""
from collections import Counter
from hypothesis import given, settings, strategies as st
from veriq_rules import lowest_unique
from veriq_verifier import _winner

sels = st.lists(st.integers(min_value=1, max_value=60), max_size=300)


@settings(max_examples=2000, deadline=None)
@given(sels)
def test_two_implementations_agree(xs):
    assert lowest_unique(list(enumerate(xs, 1))).number == _winner(xs)


@settings(max_examples=500, deadline=None)
@given(sels, st.randoms())
def test_order_independent_and_definitional(xs, rnd):
    ys = xs[:]; rnd.shuffle(ys)
    a, b = lowest_unique(list(enumerate(xs, 1))), lowest_unique(list(enumerate(ys, 1)))
    assert a.number == b.number
    c = Counter(xs); S = {k for k, v in c.items() if v == 1}
    assert a.number == (min(S) if S else None)
    if a.number is not None:
        assert xs[a.seq - 1] == a.number
