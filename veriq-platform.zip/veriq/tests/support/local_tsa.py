"""Local RFC 3161 TSA for tests, backed by `openssl ts -reply`. Generates its own root CA and a TSA certificate
with critical EKU timeStamping. SYNTHETIC — production uses real, independent TSAs."""
import os, subprocess, tempfile, threading
from http.server import BaseHTTPRequestHandler, HTTPServer

CFG = """
[ tsa ]
default_tsa = tsa1
[ tsa1 ]
dir = {d}
serial = $dir/serial
crypto_device = builtin
signer_cert = $dir/tsa.crt
certs = $dir/tsa.crt
signer_key = $dir/tsa.key
signer_digest = sha256
default_policy = 1.3.6.1.4.1.99999.1.1
digests = sha256
accuracy = secs:1
ordering = yes
tsa_name = no
ess_cert_id_chain = no
ess_cert_id_alg = sha256
"""


def run(*a, **kw):
    subprocess.run(a, check=True, capture_output=True, **kw)


class LocalTSA:
    def __init__(self, name="Synthetic Test TSA"):
        self.dir = tempfile.mkdtemp(prefix="tsa-"); d = self.dir
        run("openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "30", "-subj", "/CN=Synthetic TSA Root",
            "-keyout", f"{d}/root.key", "-out", f"{d}/root.crt")
        run("openssl", "req", "-newkey", "rsa:2048", "-nodes", "-subj", f"/CN={name}", "-keyout", f"{d}/tsa.key", "-out", f"{d}/tsa.csr")
        open(f"{d}/ext.cnf", "w").write("extendedKeyUsage=critical,timeStamping\nkeyUsage=critical,digitalSignature\n")
        run("openssl", "x509", "-req", "-in", f"{d}/tsa.csr", "-CA", f"{d}/root.crt", "-CAkey", f"{d}/root.key", "-CAcreateserial",
            "-days", "30", "-extfile", f"{d}/ext.cnf", "-out", f"{d}/tsa.crt")
        open(f"{d}/serial", "w").write("01\n"); open(f"{d}/tsa.cnf", "w").write(CFG.format(d=d))
        self.root_pem = open(f"{d}/root.crt", "rb").read()
        tsa = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_POST(self):
                q = self.rfile.read(int(self.headers["Content-Length"]))
                with tempfile.NamedTemporaryFile(dir=tsa.dir, delete=False) as f:
                    f.write(q)
                out = f.name + ".tsr"
                try:
                    run("openssl", "ts", "-reply", "-config", f"{tsa.dir}/tsa.cnf", "-queryfile", f.name, "-out", out)
                    body = open(out, "rb").read(); self.send_response(200)
                except subprocess.CalledProcessError:
                    body = b""; self.send_response(500)
                self.send_header("Content-Type", "application/timestamp-reply"); self.end_headers(); self.wfile.write(body)

        self.server = HTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.server.server_port}/tsa"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def stop(self):
        self.server.shutdown()
