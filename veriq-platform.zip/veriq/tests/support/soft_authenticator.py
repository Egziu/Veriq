"""Software WebAuthn authenticator for tests: real CBOR/COSE encoding and ECDSA P-256 signatures, so the
production verifier (py_webauthn) checks it exactly as it would a phone or security key. SYNTHETIC."""
import base64, hashlib, json, os, struct
import cbor2
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec

b64u = lambda b: base64.urlsafe_b64encode(b).rstrip(b"=").decode()
unb64u = lambda s: base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


class SoftAuthenticator:
    def __init__(self, rp_id="veriq.et", origin="https://veriq.et", uv=True):
        self.rp_id, self.origin, self.uv = rp_id, origin, uv
        self.key = ec.generate_private_key(ec.SECP256R1())
        self.cred_id = os.urandom(32)
        self.count = 0

    def _cose(self):
        n = self.key.public_key().public_numbers()
        return cbor2.dumps({1: 2, 3: -7, -1: 1, -2: n.x.to_bytes(32, "big"), -3: n.y.to_bytes(32, "big")})

    def _flags(self, attested=False):
        f = 0x01 | (0x04 if self.uv else 0)  # UP, UV
        return f | (0x40 if attested else 0)

    def create(self, options: dict, origin=None, rp_id=None) -> dict:
        cd = json.dumps({"type": "webauthn.create", "challenge": options["challenge"], "origin": origin or self.origin,
                         "crossOrigin": False}).encode()
        auth = (hashlib.sha256((rp_id or self.rp_id).encode()).digest() + bytes([self._flags(True)]) + struct.pack(">I", self.count)
                + b"\x00" * 16 + struct.pack(">H", len(self.cred_id)) + self.cred_id + self._cose())
        att = cbor2.dumps({"fmt": "none", "attStmt": {}, "authData": auth})
        return {"id": b64u(self.cred_id), "rawId": b64u(self.cred_id), "type": "public-key",
                "response": {"clientDataJSON": b64u(cd), "attestationObject": b64u(att), "transports": ["internal"]},
                "clientExtensionResults": {}}

    def get(self, options: dict, origin=None, counter=None, rp_id=None) -> dict:
        self.count = self.count + 1 if counter is None else counter
        cd = json.dumps({"type": "webauthn.get", "challenge": options["challenge"], "origin": origin or self.origin,
                         "crossOrigin": False}).encode()
        auth = hashlib.sha256((rp_id or self.rp_id).encode()).digest() + bytes([self._flags()]) + struct.pack(">I", self.count)
        sig = self.key.sign(auth + hashlib.sha256(cd).digest(), ec.ECDSA(hashes.SHA256()))
        return {"id": b64u(self.cred_id), "rawId": b64u(self.cred_id), "type": "public-key",
                "response": {"clientDataJSON": b64u(cd), "authenticatorData": b64u(auth), "signature": b64u(sig), "userHandle": None},
                "clientExtensionResults": {}}
