"""aiogram session that records outgoing Bot API calls instead of contacting Telegram (tests only)."""
from datetime import datetime
from aiogram.client.session.base import BaseSession
from aiogram.methods import AnswerCallbackQuery, SendMessage
from aiogram.types import Chat, Message


class RecordingSession(BaseSession):
    def __init__(self):
        super().__init__(); self.sent = []

    async def close(self): pass

    async def stream_content(self, *a, **kw):
        if False:
            yield b""

    async def make_request(self, bot, method, timeout=None):
        self.sent.append(method)
        if isinstance(method, SendMessage):
            return Message(message_id=len(self.sent), date=datetime.now(), chat=Chat(id=method.chat_id, type="private"), text=method.text)
        if isinstance(method, AnswerCallbackQuery):
            return True
        return True

    def texts(self):
        return [m.text for m in self.sent if isinstance(m, SendMessage)]
